package main;

import java.util.Comparator;

public class QueueUtils {

  /**
   * Moves every element in the given queue which is "less than or equal to" a given cutoff element
   * and using a given comparator to the back of the queue. If there is more than one such item,
   * they are all moved to the back and their relative order is maintained.
   *
   * <p>Put another way, every element in the queue with comparator.compare(element, cutoffElement)
   * <= 0 is moved to the back of the queue.
   *
   * @param <T> the type of the elements in the queue
   * @param queue the queue to act upon
   * @param cutoffElement the object to compare to in order to determine whether a move to the back
   *     happens
   * @throws IllegalArgumentException when either the cutoffElement or comparator is null
   */
  public static <T> void moveToTheBack(
      SimpleQueue<T> queue, T cutoffElement, Comparator<T> comparator) {
    // TODO: complete this method so that it follows the spec in the
    //       method docs and so that it passes all tests.
    //
    //       REMEMBER: The only collections you can use to build your
    //       solution are those in the prereqs!
  }
}
