package main;

public class StackUtils {

  /**
   * Removes all elements from a given Stack that equal the given filter. To be clear, this means
   * that any object obj in the Stack where obj.equals(filter) is true will be removed. The relative
   * order of the remaining elements is not changed.
   *
   * @param <T> the type of the elements in stack
   * @param stack the stack to filter
   * @param filter the object used to determine whether an element is filtered out of the stack
   * @throws IllegalArgumentException when filter is null
   */
  public static <T> void filter(SimpleStack<T> stack, T filter) {
    // TODO: complete this method so that it follows the spec in the
    //       method docs and so that it passes all tests.
    //
    //       REMEMBER: The only collections you can use to build your
    //       solution are those in the prereqs!
  }
}
