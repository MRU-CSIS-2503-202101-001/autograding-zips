package main;

import java.util.Collections;
import java.util.List;

/**
 * This *currently* represents a waiter serving patrons, using a String for the waiter's name and a
 * List of Patrons currently being served...but it could represent ANY kind of server: a web server
 * serving http requests, or a printer serving (i.e. printing) print jobs, or a receptionist serving
 * (attending to) people waiting in an office... you get the idea.
 *
 * <p>Make this class a parameterized class that uses generics for both the id and the the type of
 * thing being served. THE TYPE OF THING BEING SERVED MUST IMPLEMENT Comparable!
 *
 * @author jpratt
 * @param <T> the type of the id for this server
 * @param <R> the type of thing this server serves
 */
public class Server {

  private String id;
  private List<Patron> currentlyBeingServed;

  /**
   * Creates a Server with a given id and a list of things it is already serving.
   *
   * @param id the identifier associated with this Server
   * @param currentlyBeingServed a List of things already being served by this server
   */
  public Server(String id, List<Patron> currentlyBeingServed) {
    this.id = id;
    this.currentlyBeingServed = currentlyBeingServed;
  }

  /**
   * Creates a Server with a given id that is not currently serving anything.
   *
   * @param id the identifier associated with this Server
   */
  public Server(String id) {
    this(id, List.of());
  }

  /**
   * Adds an additional thing to serve - it will be at "the end of the line".
   *
   * @param toServe a thing to serve
   */
  public void add(Patron toServe) {
    currentlyBeingServed.add(toServe);
  }

  /**
   * Sorts the things currently being served by their natural order.
   *
   * <p>This modifies currentlyBeingServed.
   */
  public void sortThingsBeingServed() {
    // TODO: uncomment the following line once you've completed the parameterization
    // Collections.sort(currentlyBeingServed);
  }

  /**
   * Returns true if there are currently no things to serve.
   *
   * @return true iff there are no things currently to serve
   */
  public boolean idle() {
    return currentlyBeingServed.isEmpty();
  }

  /**
   * Returns the id of this Server.
   *
   * @return the id of this Server
   */
  public String serverId() {
    return id;
  }

  /**
   * Returns the next thing that needs to be served. If there are no things waiting, returns null
   * instead.
   *
   * @return the next thing to server, or null
   */
  public Patron nextServed() {
    return idle() ? null : currentlyBeingServed.remove(0);
  }

  /**
   * Returns a String version of this Server. It looks like this:
   *
   * <pre>
   * [id of this Server] is serving:
   * [list of things being served, one per line]
   * </pre>
   */
  @Override
  public String toString() {
    return String.format("%s is serving:%n%s", id, multiline(currentlyBeingServed));
  }

  private String multiline(List<Patron> things) {
    String result = "";
    for (Patron thing : things) {
      result += thing + "\n";
    }

    return result.trim();
  }
}
