package main;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Main {

  public static void main(String[] args) {

    // TODO: create a Scanner to get keyboard input

    // TODO: create an array of Customers called customersInLine that holds the following two
    //       customers:
    //       1) name: Iani, drinkOrder: espresso, price: 12
    //       2) name: Bob, drinkOrder: double-double, price: 5

    // this turns the array of Customers you made into a List - this code works fine, so please
    // don't touch it!
    List<Customer> customersAsList = new ArrayList<>(Arrays.asList(customersInLine));

    System.out.print("Barista name? ");

    // TODO: get the barista name via your Scanner

    System.out.print("New customer's name? ");
    // TODO: get the customer's name via your Scanner

    System.out.print("New customer's order? ");
    // TODO: get the customer's order via your Scanner

    System.out.print("New customer's order price? ");
    // TODO: get the customer's order price via your Scanner

    // TODO: create a new customer with the given name and order and price

    // TODO: create a Server object using the barista name and customersAsList

    // TODO: add the new customer to the Server object...there's a method for that....

    System.out.println();

    // TODO: output the Server object to console

    // TODO: sort the things in the Server object...there's a method for that....

    System.out.println();
    System.out.println("After sorting by natural order...");
    System.out.println();

    // TODO: output the Server object to the console
  }
}
