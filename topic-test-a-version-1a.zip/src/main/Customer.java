package main;

/**
 * Represents a Customer at a coffee shop.
 *
 * @author jpratt
 */
public class Customer {

  private String customerName;
  private String drinkOrder;
  private int drinkPrice;

  /**
   * Creates a Customer with a given name, drink order, and price of drink.
   *
   * @param customerName name of this Customer
   * @param drinkOrder name of the drink order for this Customer
   * @param drinkPrice price of the drink for this Customer
   */
  public Customer(String customerName, String drinkOrder, int drinkPrice) {
    this.customerName = customerName;
    this.drinkOrder = drinkOrder;
    this.drinkPrice = drinkPrice;
  }

  public String getCustomerName() {
    return customerName;
  }

  public String getCustomerOrder() {
    return drinkOrder;
  }

  public int getDrinkPrice() {
    return drinkPrice;
  }

  /**
   * Returns a "[name] (who ordered a/an [drink]" kinda String.
   *
   * @return a String in the above format
   */
  @Override
  public String toString() {
    String preposition = startsWithVowel(drinkOrder) ? "an" : "a";

    return String.format("%s (who ordered %s %s)", customerName, preposition, drinkOrder);
  }

  private boolean startsWithVowel(String word) {
    String firstLetter = word.substring(0, 1);
    return firstLetter.matches("[AEIOUaeiou]");
  }
}
