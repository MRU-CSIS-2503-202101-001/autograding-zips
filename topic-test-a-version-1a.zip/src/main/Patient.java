package main;

public class Patient implements Comparable<Patient> {

  @Override
  public int compareTo(Patient o) {
    return 0;
  }
}
