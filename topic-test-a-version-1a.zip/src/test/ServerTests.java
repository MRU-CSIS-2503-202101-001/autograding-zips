package test;

import java.util.ArrayList;
import java.util.List;

import static org.assertj.core.api.Assertions.*;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import main.Server;

public class ServerTests {

  @Test
  @DisplayName("can make a printer serving print jobs")
  void can_make_a_printer() {
    Server<String, PrintJob> printServer = new Server<>("HP-1413");

    assertThat(printServer).isInstanceOf(Server.class);
  }

  @Test
  @DisplayName("can make a medical receptionist serving patients")
  void can_make_a_medical_receptionist() {
    List<Patient> alreadyWaitingPatients = List.of(new Patient(), new Patient());
    Server<String, Patient> medicalReceptionist = new Server<>("David Lee", alreadyWaitingPatients);

    assertThat(medicalReceptionist).isInstanceOf(Server.class);
  }

  @Test
  @DisplayName("can make a fighter accepting challenges")
  void can_make_a_fighter() {
    int fighterId = 123;
    List<Fighter> challengersWaiting = List.of(new Fighter(), new Fighter());
    Server<Integer, Fighter> videoGameFighter = new Server<>(fighterId, challengersWaiting);

    assertThat(videoGameFighter).isInstanceOf(Server.class);
  }

  @Test
  @DisplayName("sortThingsBeingServed was implemented")
  void sortThingsBeingServed_was_implemented() {
    int id = 2;
    List<Integer> ints = new ArrayList<>(List.of(3, 2, 1, 0));
    Server<Integer, Integer> server = new Server<>(id, ints);

    server.sortThingsBeingServed();

    int nextServed = server.nextServed();

    assertThat(nextServed).isEqualTo(0);
  }
}

class Fighter implements Comparable<Fighter> {
  @Override
  public int compareTo(Fighter o) {
    return 0;
  }
}

class PrintJob implements Comparable<PrintJob> {

  @Override
  public int compareTo(PrintJob o) {
    return 0;
  }
}

class Patient implements Comparable<Patient> {

  @Override
  public int compareTo(Patient o) {
    return 0;
  }
}
