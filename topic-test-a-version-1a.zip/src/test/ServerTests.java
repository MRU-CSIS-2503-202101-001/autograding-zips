package test;

import java.util.List;
import java.time.LocalDateTime;

import static org.assertj.core.api.Assertions.*;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import org.junit.jupiter.api.Test;

import main.Server;
import main.PrintJob;
import main.Patient;
import main.Fighter;

class ServerTests {

  @Test
  @DisplayName("can make a printer serving print jobs")
  void can_make_a_printer() {
    Server<String, PrintJob> printServer = new Server<>("HP-1413");

    assertThat(printServer).isInstanceOf(Server.class);
  }

  @Test
  @DisplayName("can make a medical receptionist serving patients")
  void can_make_a_medical_receptionist() {
    List<Patient> alreadyWaitingPatients = List.of(new Patient(), new Patient());
    Server<String, Patient> medicalReceptionist = new Server<>("David Lee", alreadyWaitingPatients);

    assertThat(medicalReceptionist).isInstanceOf(Server.class);
  }

  @Test
  @DisplayName("can make a fighter accepting challenges")
  void can_make_a_fighter() {
    int fighterId = 123;
    List<Fighter> challengersWaiting = List.of(new Fighter(), new Fighter());
    Server<Integer, Fighter> videoGameFighter = new Server<>(fighterId, challengersWaiting);

    assertThat(videoGameFighter).isInstanceOf(Server.class);
  }
}
