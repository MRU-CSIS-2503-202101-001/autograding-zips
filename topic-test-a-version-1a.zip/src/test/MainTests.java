package test;

import static com.github.stefanbirkner.systemlambda.SystemLambda.*;
import static org.assertj.core.api.Assertions.assertThat;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import main.Main;

public class MainTests {

  private List<String> clean(String rawConsoleOutput) {
    String[] split = rawConsoleOutput.split("\n");
    return Arrays.stream(split)
        .filter(s -> !s.isEmpty())
        .map(s -> s.trim())
        .collect(Collectors.toList());
  }

  @Test
  @DisplayName("Lucia serves Yuko")
  void lucia_serves_yuko() throws Exception {

    withTextFromSystemIn("Lucia the Barista", "Yuko", "super-hot half-shot", "18")
        .execute(
            () -> {
              List<String> expectedOutputParts =
                  List.of(
                      "Barista name?",
                      "New customer's name?",
                      "New customer's order?",
                      "New customer's order price?",
                      "Lucia the Barista is serving:",
                      "Iani (who ordered an espresso)",
                      "Bob (who ordered a double-double)",
                      "Yuko (who ordered a super-hot half-shot)",
                      "After sorting by natural order...",
                      "Lucia the Barista is serving:",
                      "Bob (who ordered a double-double)",
                      "Iani (who ordered an espresso)",
                      "Yuko (who ordered a super-hot half-shot)");

              String rawConsoleOutput =
                  tapSystemOutNormalized(() -> Main.main(new String[0])).trim();
              List<String> cleanedOutput = clean(rawConsoleOutput);

              assertThat(cleanedOutput).isEqualTo(expectedOutputParts);
            });
  }

  @Test
  @DisplayName("Piero serves Asli")
  void piero_serves_asli() throws Exception {

    withTextFromSystemIn("Piero the Barista", "Asli", "skinny blackeye", "15")
        .execute(
            () -> {
              List<String> expectedOutputParts =
                  List.of(
                      "Barista name?",
                      "New customer's name?",
                      "New customer's order?",
                      "New customer's order price?",
                      "Piero the Barista is serving:",
                      "Iani (who ordered an espresso)",
                      "Bob (who ordered a double-double)",
                      "Asli (who ordered a skinny blackeye)",
                      "After sorting by natural order...",
                      "Piero the Barista is serving:",
                      "Asli (who ordered a skinny blackeye)",
                      "Bob (who ordered a double-double)",
                      "Iani (who ordered an espresso)");

              String rawConsoleOutput =
                  tapSystemOutNormalized(() -> Main.main(new String[0])).trim();
              List<String> cleanedOutput = clean(rawConsoleOutput);

              assertThat(cleanedOutput).isEqualTo(expectedOutputParts);
            });
  }
}
