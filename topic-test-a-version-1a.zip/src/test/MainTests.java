package test;

import static com.github.stefanbirkner.systemlambda.SystemLambda.*;
import static org.assertj.core.api.Assertions.assertThat;

import java.util.List;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import main.Main;

class MainTests {

  @Test
  @DisplayName("Lucia serves Yuko")
  void lucia_serves_yuko() throws Exception {

    withTextFromSystemIn("Lucia the Barista", "Yuko", "super-hot half-shot", "18")
        .execute(
            () -> {
              List<String> expectedOutputParts =
                  List.of(
                      "Lucia the Barista is serving:",
                      "Bob (who ordered a double-double)",
                      "Iani (who ordered an espresso",
                      "Yuko (who ordered a super-hot half-shot)",
                      "After sorting by natural order...",
                      "Lucia the Barista is serving:",
                      "Bob (who ordered a double-double)",
                      "Iani (who ordered an espresso",
                      "Yuko (who ordered a super-hot half-shot)");

              String whatIsOutput = tapSystemOutNormalized(() -> Main.main(new String[0])).trim();

              assertThat(whatIsOutput).containsSubsequence(expectedOutputParts);
            });
  }

  @Test
  @DisplayName("Piero serves Asli")
  void piero_serves_asli() throws Exception {

    withTextFromSystemIn("Piero the Barista", "Asli", "skinny blackeye", "15")
        .execute(
            () -> {
              List<String> expectedOutputParts =
                  List.of(
                      "Piero the Barista is serving:",
                      "Bob (who ordered a double-double)",
                      "Iani (who ordered an espresso",
                      "Asli (who ordered a skinny blackeye)",
                      "After sorting by natural order...",
                      "Piero the Barista is serving:",
                      "Asli (who ordered a skinny blackeye)",
                      "Bob (who ordered a double-double)",
                      "Iani (who ordered an espresso");

              String whatIsOutput = tapSystemOutNormalized(() -> Main.main(new String[0])).trim();

              assertThat(whatIsOutput).containsSubsequence(expectedOutputParts);
            });
  }
}
