package test;

import java.util.Comparator;

import static org.assertj.core.api.Assertions.*;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import main.Customer;
import main.CustomerDrinkPriceComparator;

public class CustomerDrinkPriceComparatorTests {

  @Test
  @DisplayName("same price and drink name returns 0")
  void same_price_and_drink_name_returns_0() {
    Customer customerOne = new Customer("A", "B", 1);
    Customer customerTwo = new Customer("B", "B", 1);

    Comparator<Customer> drinkPriceComparator = new CustomerDrinkPriceComparator();

    int compareResult = drinkPriceComparator.compare(customerOne, customerTwo);
    assertThat(compareResult).isEqualTo(0);

    compareResult = drinkPriceComparator.compare(customerTwo, customerOne);
    assertThat(compareResult).isEqualTo(0);
  }

  @Test
  @DisplayName("same price and drink name, case insensitive, returns 0")
  void same_price_and_drink_name_case_insensitive_returns_0() {
    Customer customerOne = new Customer("A", "c", 1);
    Customer customerTwo = new Customer("B", "C", 1);

    Comparator<Customer> drinkPriceComparator = new CustomerDrinkPriceComparator();

    int compareResult = drinkPriceComparator.compare(customerOne, customerTwo);
    assertThat(compareResult).isEqualTo(0);

    compareResult = drinkPriceComparator.compare(customerTwo, customerOne);
    assertThat(compareResult).isEqualTo(0);
  }

  @Test
  @DisplayName("same price, different drink name, orders by drink name, case insensitive")
  void same_price_different_drink_name_orders_by_drink_name_case_insensitive() {
    Customer customerOne = new Customer("A", "x", 1);
    Customer customerTwo = new Customer("B", "C", 1);

    Comparator<Customer> drinkPriceComparator = new CustomerDrinkPriceComparator();

    int compareResult = drinkPriceComparator.compare(customerOne, customerTwo);
    assertThat(compareResult).isGreaterThan(0);

    compareResult = drinkPriceComparator.compare(customerTwo, customerOne);
    assertThat(compareResult).isLessThan(0);
  }

  @Test
  @DisplayName("smaller prices come before big ones even if drink name comes earlier")
  void smaller_prices_come_before_big_ones_even_if_drink_name_comes_earlier() {
    Customer customerOne = new Customer("A", "Z", 4);
    Customer customerTwo = new Customer("B", "F", 12);

    Comparator<Customer> drinkPriceComparator = new CustomerDrinkPriceComparator();

    int compareResult = drinkPriceComparator.compare(customerOne, customerTwo);
    assertThat(compareResult).isLessThan(0);

    compareResult = drinkPriceComparator.compare(customerTwo, customerOne);
    assertThat(compareResult).isGreaterThan(0);
  }
}
