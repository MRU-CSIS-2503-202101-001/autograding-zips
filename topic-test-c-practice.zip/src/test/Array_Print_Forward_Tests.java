package test;

import static com.github.stefanbirkner.systemlambda.SystemLambda.*;
import static org.assertj.core.api.Assertions.assertThat;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import main.ArrayPrintUtil;

@DisplayName("Print Forward Tests")
public class Array_Print_Forward_Tests {

  @Test
  @DisplayName("an empty array")
  void an_empty_array() throws Exception {

    String[] theArray = {};

    String rawConsoleOutput = tapSystemOutNormalized(() -> ArrayPrintUtil.printForward(theArray));

    List<String> cleanedOutput = clean(rawConsoleOutput);

    List<String> expectedOutputParts = List.of();

    assertThat(cleanedOutput).isEqualTo(expectedOutputParts);
  }

  @Test
  @DisplayName("an array with one string")
  void an_array_with_one_string() throws Exception {

    String[] theArray = {"fleas"};

    String rawConsoleOutput = tapSystemOutNormalized(() -> ArrayPrintUtil.printForward(theArray));

    List<String> cleanedOutput = clean(rawConsoleOutput);

    List<String> expectedOutputParts = List.of("fleas");

    assertThat(cleanedOutput).isEqualTo(expectedOutputParts);
  }

  @Test
  @DisplayName("an array with two strings")
  void an_array_with_two_strings() throws Exception {

    String[] theArray = {"Googly", "Moogly"};

    String rawConsoleOutput = tapSystemOutNormalized(() -> ArrayPrintUtil.printForward(theArray));

    List<String> cleanedOutput = clean(rawConsoleOutput);

    List<String> expectedOutputParts = List.of("Googly", "Moogly");

    assertThat(cleanedOutput).isEqualTo(expectedOutputParts);
  }

  @Test
  @DisplayName("an array with multiple strings")
  void an_array_with_multiple_strings() throws Exception {

    String[] theArray = {"I", "can", "feel", "my", "lifetime", "piling", "up"};

    String rawConsoleOutput = tapSystemOutNormalized(() -> ArrayPrintUtil.printForward(theArray));

    List<String> cleanedOutput = clean(rawConsoleOutput);

    List<String> expectedOutputParts =
        List.of("I", "can", "feel", "my", "lifetime", "piling", "up");

    assertThat(cleanedOutput).isEqualTo(expectedOutputParts);
  }

  private List<String> clean(String rawConsoleOutput) {
    String[] split = rawConsoleOutput.split("\n");
    return Arrays.stream(split)
        .filter(s -> !s.isEmpty())
        .map(String::trim)
        .collect(Collectors.toList());
  }
}
