package test;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import main.StringUtil;

@DisplayName("String Has UpperCase Tests")
public class String_Has_UpperCase_Tests {

  private static final String EOL = System.lineSeparator();

  @Test
  @DisplayName("an empty String returns false")
  void an_empty_string() {

    assertThat(StringUtil.hasUpperCase("")).isFalse();
  }

  @Test
  @DisplayName("a String that's blank returns false")
  void a_String_that_s_blank_returns_false() {

    assertThat(StringUtil.hasUpperCase(" \t " + EOL)).isFalse();
  }

  @Test
  @DisplayName("a single character string with no uppercase")
  void a_single_character_string_with_no_uppercase() {

    assertThat(StringUtil.hasUpperCase("i")).isFalse();
  }

  @Test
  @DisplayName("a single character string with an uppercase")
  void a_single_character_string_with_an_uppercase() {

    assertThat(StringUtil.hasUpperCase("I")).isTrue();
  }

  @Test
  @DisplayName("a string with no uppercaseables")
  void a_string_with_no_uppercaseables() {

    assertThat(StringUtil.hasUpperCase("98!#$")).isFalse();
  }

  @Test
  @DisplayName("two character, no uppercase")
  void two_character_no_uppercase() {

    assertThat(StringUtil.hasUpperCase("f)")).isFalse();
  }

  @Test
  @DisplayName("two character, first is uppercase")
  void two_character_first_is_uppercase() {

    assertThat(StringUtil.hasUpperCase("F-")).isTrue();
  }

  @Test
  @DisplayName("two character, last is uppercase")
  void two_character_last_is_uppercase() {

    assertThat(StringUtil.hasUpperCase("rR")).isTrue();
  }

  @Test
  @DisplayName("two character, both uppercase")
  void two_character_both_are_uppercase() {

    assertThat(StringUtil.hasUpperCase("PU")).isTrue();
  }

  @Test
  @DisplayName("three character cases")
  void three_character_cases() {

    // 0 uppercase cases
    assertThat(StringUtil.hasUpperCase("uia")).isFalse();

    // 1 uppercase cases
    assertThat(StringUtil.hasUpperCase("xAe")).isTrue();
    assertThat(StringUtil.hasUpperCase("Afe")).isTrue();
    assertThat(StringUtil.hasUpperCase("iUr")).isTrue();

    // 2 uppercase cases
    assertThat(StringUtil.hasUpperCase("fbA")).isTrue();
    assertThat(StringUtil.hasUpperCase("Eqm")).isTrue();
    assertThat(StringUtil.hasUpperCase("cRx")).isTrue();

    // 3 uppercase cases
    assertThat(StringUtil.hasUpperCase("GBL")).isTrue();
  }

  @Test
  @DisplayName("four character cases")
  void four_character_cases() {

    // 0 uppercase cases
    assertThat(StringUtil.hasUpperCase("iieo")).isFalse();

    // 1 uppercase cases
    assertThat(StringUtil.hasUpperCase("Aeoo")).isTrue();
    assertThat(StringUtil.hasUpperCase("eXii")).isTrue();
    assertThat(StringUtil.hasUpperCase("irA9")).isTrue();
    assertThat(StringUtil.hasUpperCase("iweO")).isTrue();

    // 2 uppercase cases
    assertThat(StringUtil.hasUpperCase("FBae")).isTrue();
    assertThat(StringUtil.hasUpperCase("eNMi")).isTrue();
    assertThat(StringUtil.hasUpperCase("aiRX")).isTrue();
    assertThat(StringUtil.hasUpperCase("FoBa")).isTrue();
    assertThat(StringUtil.hasUpperCase("eNuM")).isTrue();
    assertThat(StringUtil.hasUpperCase("RiiR")).isTrue();

    // 3 uppercase cases
    assertThat(StringUtil.hasUpperCase("TGHi")).isTrue();
    assertThat(StringUtil.hasUpperCase("uFYR")).isTrue();
    assertThat(StringUtil.hasUpperCase("WaXN")).isTrue();
    assertThat(StringUtil.hasUpperCase("VZiP")).isTrue();

    // 4 uppercase cases
    assertThat(StringUtil.hasUpperCase("FELR")).isTrue();
  }
}
