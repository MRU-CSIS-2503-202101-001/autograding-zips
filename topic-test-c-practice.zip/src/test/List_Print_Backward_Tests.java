package test;

import static com.github.stefanbirkner.systemlambda.SystemLambda.*;
import static org.assertj.core.api.Assertions.assertThat;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import main.SuperSimpleLinkedList;

@DisplayName("List Print Backward Tests")
public class List_Print_Backward_Tests {

  @Test
  @DisplayName("an empty list")
  void an_empty_list() throws Exception {

    SuperSimpleLinkedList<String> list = new SuperSimpleLinkedList<>();

    String rawConsoleOutput = tapSystemOutNormalized(() -> list.printBackward());

    List<String> cleanedOutput = clean(rawConsoleOutput);

    List<String> expectedOutputParts = List.of();

    assertThat(cleanedOutput).isEqualTo(expectedOutputParts);
  }

  @Test
  @DisplayName("an list with one string")
  void an_list_with_one_string() throws Exception {

    SuperSimpleLinkedList<String> list = new SuperSimpleLinkedList<>();
    List.of("fleas").forEach(list::append);

    String rawConsoleOutput = tapSystemOutNormalized(() -> list.printBackward());

    List<String> cleanedOutput = clean(rawConsoleOutput);

    List<String> expectedOutputParts = List.of("fleas");

    assertThat(cleanedOutput).isEqualTo(expectedOutputParts);
  }

  @Test
  @DisplayName("an list with two strings")
  void an_list_with_two_strings() throws Exception {

    SuperSimpleLinkedList<String> list = new SuperSimpleLinkedList<>();
    List.of("Googly", "Moogly").forEach(list::append);

    String rawConsoleOutput = tapSystemOutNormalized(() -> list.printBackward());

    List<String> cleanedOutput = clean(rawConsoleOutput);

    List<String> expectedOutputParts = List.of("Moogly", "Googly");

    assertThat(cleanedOutput).isEqualTo(expectedOutputParts);
  }

  @Test
  @DisplayName("an list with multiple strings")
  void an_list_with_multiple_strings() throws Exception {

    SuperSimpleLinkedList<String> list = new SuperSimpleLinkedList<>();
    List.of("I", "can", "feel", "my", "lifetime", "piling", "up").forEach(list::append);

    String rawConsoleOutput = tapSystemOutNormalized(() -> list.printBackward());

    List<String> cleanedOutput = clean(rawConsoleOutput);

    List<String> expectedOutputParts =
        List.of("up", "piling", "lifetime", "my", "feel", "can", "I");

    assertThat(cleanedOutput).isEqualTo(expectedOutputParts);
  }

  private List<String> clean(String rawConsoleOutput) {
    String[] split = rawConsoleOutput.split("\n");
    return Arrays.stream(split)
        .filter(s -> !s.isEmpty())
        .map(String::trim)
        .collect(Collectors.toList());
  }
}
