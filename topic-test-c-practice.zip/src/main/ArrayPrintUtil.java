package main;

public class ArrayPrintUtil {

  /**
   * Prints the contents of the given array to the console in the order that they appear in the
   * array; each element should be printed to its own line.
   *
   * @param <T> the type of elements in the array
   * @param arr the array being printed to console
   */
  public static <T> void printForward(T[] arr) {
    // TODO: this is the recursive wrapper; when you create
    // the recursive helper, it should be private static <T> void as well
  }

  /**
   * Prints the contents of the given array to the console in the reverse order that they appear in
   * the array; each element should be printed to its own line.
   *
   * @param <T> the type of elements in the array
   * @param arr the array being printed to console
   */
  public static <T> void printBackward(T[] arr) {
    // TODO: this is the recursive wrapper; when you create
    // the recursive helper, it should be private static <T> void as well
  }
}
