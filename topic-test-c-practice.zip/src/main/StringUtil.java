package main;

public class StringUtil {

  /**
   * Returns true if there is at least one uppercase letter in the given string.
   *
   * <p>You might find it usefule to know that the Character class has an isUpperCase method.
   *
   * @param s the string to examine for uppercase letters
   * @return true if there is 1 or more uppcase letters in s
   */
  public static boolean hasUpperCase(String s) {
    // TODO: this is the recursive wrapper; when you create
    // the recursive helper, it should be private static boolean as well
    return false;
  }
}
