package main;

public class SuperSimpleLinkedList<T extends Comparable<T>> {

  private Node<T> head;
  private Node<T> tail;
  private int size;

  public SuperSimpleLinkedList() {
    head = null;
    tail = null;
    size = 0;
  }

  // TODO: add your printForward and printBackward methods in here

  // printForward should print to console the elements in this linked list in head -> tail order,
  // one element per line.
  //
  // printBackward should print in tail->head order. By the way, YOU DO NOT NEED TO
  // MAKE THIS LIST INTO A DOUBLY-LINKED LIST TO DO THIS. Recursion is magical!

  public void prepend(T data) {

    Node<T> newGuy = new Node<T>(data);
    if (isEmpty()) {
      tail = newGuy;
    } else {
      newGuy.next = head.next;
    }
    head = newGuy;
    size++;
  }

  public void append(T data) {

    Node<T> newGuy = new Node<T>(data);

    if (isEmpty()) {
      head = newGuy;
    } else {
      tail.next = newGuy;
    }
    tail = newGuy;
    size++;
  }

  public int size() {
    return size;
  }

  public boolean isEmpty() {
    return head == null;
  }

  private static class Node<T> {

    private T data;
    private Node<T> next;

    public Node(T data) {
      this.data = data;
      this.next = null;
    }

    @Override
    public String toString() {
      return String.format("%s", data.toString());
    }
  }
}
