package main;

public class OscillatingResizableList<T> {

  private static final int DEFAULT_CAPACITY = 7;

  private T[] listContents;

  /**
   * Creates a new OscillatingResizableList that is empty.
   *
   * <p>I've provided the initialization of the backing array because it's goofy.
   */
  public OscillatingResizableList() {

    listContents = (T[]) new Object[DEFAULT_CAPACITY];
  }

  /**
   * Returns a List of the contents of the backing array listContents.
   *
   * <p>For the record, documentation in public methods should RARELY - if EVER - talk about the
   * internal guts of the class. :)
   *
   * @return a List of the backing array contents
   */
  public List<T> contents() {

    return new ArrayList<T>(Arrays.asList(listContents));
  }
}
