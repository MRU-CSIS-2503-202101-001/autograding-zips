package main;

/**
 * Entry point class for our App. That's all it's meant to do.
 *
 * @author jpratt
 */
public class Main {

  public static void main(String[] args) {

    App app = new App();
    app.run();
  }
}
