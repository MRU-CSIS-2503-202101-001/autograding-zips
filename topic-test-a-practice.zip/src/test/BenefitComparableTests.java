package test;

import static org.assertj.core.api.Assertions.*;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import main.Benefit;

public class BenefitComparableTests {

  @Test
  @DisplayName("identical valuation, rarity, and description case insensitve returns 0")
  void identical_valuation_rarity_and_description_case_insensitve_returns_0() {
    Benefit benefitOne = new Benefit("A", 3, 1);
    Benefit benefitTwo = new Benefit("a", 3, 1);

    int compareToResult = benefitOne.compareTo(benefitTwo);
    assertThat(compareToResult).isEqualTo(0);

    compareToResult = benefitTwo.compareTo(benefitOne);
    assertThat(compareToResult).isEqualTo(0);
  }

  @Test
  @DisplayName(
      "identical valuation and rarity but different description orders by alphabetic case insensitve")
  void
      identical_valuation_and_rarity_but_different_description_orders_by_alphabetic_case_insensitive() {
    Benefit benefitOne = new Benefit("B", 4, 2);
    Benefit benefitTwo = new Benefit("x", 4, 2);

    int compareToResult = benefitOne.compareTo(benefitTwo);
    assertThat(compareToResult).isLessThan(0);

    compareToResult = benefitTwo.compareTo(benefitOne);
    assertThat(compareToResult).isGreaterThan(0);
  }

  @Test
  @DisplayName(
      "identical valuation and description but different rarity orders by rarity ascending")
  void identical_valuation_and_description_but_different_rarity_orders_by_rarity_ascending() {
    Benefit benefitOne = new Benefit("X", 3, 0);
    Benefit benefitTwo = new Benefit("X", 3, 10);

    assertThat(benefitOne.compareTo(benefitTwo)).isLessThan(0);
    assertThat(benefitTwo.compareTo(benefitOne)).isGreaterThan(0);
  }

  @Test
  @DisplayName(
      "identical rarity and description but different valuation orders by valuation descending")
  void identical_rarity_and_description_but_different_valuation_orders_by_valuation_descending() {
    Benefit benefitOne = new Benefit("V", 13, 8);
    Benefit benefitTwo = new Benefit("v", 12, 8);

    assertThat(benefitOne.compareTo(benefitTwo)).isLessThan(0);
    assertThat(benefitTwo.compareTo(benefitOne)).isGreaterThan(0);
  }
}
