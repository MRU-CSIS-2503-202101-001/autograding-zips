package test;

import java.util.Comparator;

import static org.assertj.core.api.Assertions.*;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import main.Benefit;
import main.BenefitRarityProductComparator;

public class BenefitRarityProductComparatorTests {

  @Test
  @DisplayName(
      "same product of rarity and valuation and same description, case sensitive, returns 0")
  void same_product_of_rarity_and_valuation_and_same_description_case_sensitive_returns_0() {
    Benefit customerOne = new Benefit("A", 4, 3);
    Benefit customerTwo = new Benefit("A", 2, 6);

    Comparator<Benefit> benefitRarityProductComparator = new BenefitRarityProductComparator();

    int compareResult = benefitRarityProductComparator.compare(customerOne, customerTwo);
    assertThat(compareResult).isEqualTo(0);

    compareResult = benefitRarityProductComparator.compare(customerTwo, customerOne);
    assertThat(compareResult).isEqualTo(0);
  }

  @Test
  @DisplayName(
      "same product of rarity and valuation and different description orders lexicographically")
  void same_product_of_rarity_and_valuation_and_different_description_orders_lexicographically() {
    Benefit customerOne = new Benefit("F", 4, 3);
    Benefit customerTwo = new Benefit("f", 2, 6);

    Comparator<Benefit> benefitRarityProductComparator = new BenefitRarityProductComparator();

    int compareResult = benefitRarityProductComparator.compare(customerOne, customerTwo);
    assertThat(compareResult).isLessThan(0);

    compareResult = benefitRarityProductComparator.compare(customerTwo, customerOne);
    assertThat(compareResult).isGreaterThan(0);
  }

  @Test
  @DisplayName(
      "different product of rarity and valuation and same description case sensitive orders ascending order of product")
  void
      different_product_of_rarity_and_valuation_and_same_description_case_sensitve_orders_ascending_order_of_product() {
    Benefit customerOne = new Benefit("R", 2, 3);
    Benefit customerTwo = new Benefit("R", 1, 7);

    Comparator<Benefit> benefitRarityProductComparator = new BenefitRarityProductComparator();

    int compareResult = benefitRarityProductComparator.compare(customerOne, customerTwo);
    assertThat(compareResult).isLessThan(0);

    compareResult = benefitRarityProductComparator.compare(customerTwo, customerOne);
    assertThat(compareResult).isGreaterThan(0);
  }

  @Test
  @DisplayName(
      "different product of rarity and valuation and different description case sensitive orders ascending order of product")
  void
      different_product_of_rarity_and_valuation_and_different_description_case_sensitve_orders_ascending_order_of_product() {
    Benefit customerOne = new Benefit("x", 2, 3);
    Benefit customerTwo = new Benefit("X", 1, 7);

    Comparator<Benefit> benefitRarityProductComparator = new BenefitRarityProductComparator();

    int compareResult = benefitRarityProductComparator.compare(customerOne, customerTwo);
    assertThat(compareResult).isLessThan(0);

    compareResult = benefitRarityProductComparator.compare(customerTwo, customerOne);
    assertThat(compareResult).isGreaterThan(0);
  }
}
