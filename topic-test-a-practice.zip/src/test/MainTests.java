package test;

import static com.github.stefanbirkner.systemlambda.SystemLambda.*;
import static org.assertj.core.api.Assertions.assertThat;

import java.util.List;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import main.Main;

public class MainTests {

  @Test
  @DisplayName("The Dude")
  void benefits_of_the_dude() throws Exception {

    withTextFromSystemIn("The Dude", "47", "a rug", "1", "0")
        .execute(
            () -> {
              List<String> expectedOutputParts =
                  List.of(
                      "The Dude has these useful things:",
                      "humour (2:4)",
                      "a car (3:10)",
                      "a rug (1:0)",
                      "After sorting by natural order...",
                      "The Dude has these useful things:",
                      "a car (3:10)",
                      "humour (2:4)",
                      "a rug (1:0)",
                      "After sorting by rarity product...",
                      "The Dude has these useful things:",
                      "a rug (1:0)",
                      "humour (2:4)",
                      "a car (3:10)");

              String whatIsOutput = tapSystemOutNormalized(() -> Main.main(new String[0])).trim();

              assertThat(whatIsOutput).containsSubsequence(expectedOutputParts);
            });
  }

  @Test
  @DisplayName("Piero serves Asli")
  void piero_serves_asli() throws Exception {

    withTextFromSystemIn("Narta", "24", "a shoulder to cry on", "15", "3")
        .execute(
            () -> {
              List<String> expectedOutputParts =
                  List.of(
                      "Narta has these useful things:",
                      "humour (2:4)",
                      "a car (3:10)",
                      "a shoulder to cry on (15:3)",
                      "After sorting by natural order...",
                      "Narta has these useful things:",
                      "a shoulder to cry on (15:3)",
                      "a car (3:10)",
                      "humour (2:4)",
                      "After sorting by rarity product...",
                      "Narta has these useful things:",
                      "humour (2:4)",
                      "a car (3:10)",
                      "a shoulder to cry on (15:3)");

              String whatIsOutput = tapSystemOutNormalized(() -> Main.main(new String[0])).trim();

              assertThat(whatIsOutput).containsSubsequence(expectedOutputParts);
            });
  }
}
