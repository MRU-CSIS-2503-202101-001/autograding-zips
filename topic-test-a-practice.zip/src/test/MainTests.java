package test;

import static com.github.stefanbirkner.systemlambda.SystemLambda.*;
import static org.assertj.core.api.Assertions.assertThat;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import main.Main;

public class MainTests {

  private List<String> clean(String rawConsoleOutput) {
    String[] split = rawConsoleOutput.split("\n");
    return Arrays.stream(split)
        .filter(s -> !s.isEmpty())
        .map(s -> s.trim())
        .collect(Collectors.toList());
  }

  @Test
  @DisplayName("The Dude")
  void benefits_of_the_dude() throws Exception {

    withTextFromSystemIn("The Dude", "47", "a rug", "1", "0")
        .execute(
            () -> {
              List<String> expectedOutputParts =
                  List.of(
                      "Friend name?",
                      "Friend age?",
                      "Benefit name?",
                      "Benefit value?",
                      "Benefit rarity?",
                      "The Dude has these useful things:",
                      "humour (2:4)",
                      "a car (3:10)",
                      "a rug (1:0)",
                      "After sorting by natural order...",
                      "The Dude has these useful things:",
                      "a car (3:10)",
                      "humour (2:4)",
                      "a rug (1:0)",
                      "After sorting by rarity product...",
                      "The Dude has these useful things:",
                      "a rug (1:0)",
                      "humour (2:4)",
                      "a car (3:10)");

              String rawConsoleOutput =
                  tapSystemOutNormalized(() -> Main.main(new String[0])).trim();
              List<String> cleanedOutput = clean(rawConsoleOutput);

              assertThat(cleanedOutput).isEqualTo(expectedOutputParts);
            });
  }

  @Test
  @DisplayName("Narta")
  void narta() throws Exception {

    withTextFromSystemIn("Narta", "24", "a shoulder to cry on", "15", "3")
        .execute(
            () -> {
              List<String> expectedOutputParts =
                  List.of(
                      "Friend name?",
                      "Friend age?",
                      "Benefit name?",
                      "Benefit value?",
                      "Benefit rarity?",
                      "Narta has these useful things:",
                      "humour (2:4)",
                      "a car (3:10)",
                      "a shoulder to cry on (15:3)",
                      "After sorting by natural order...",
                      "Narta has these useful things:",
                      "a shoulder to cry on (15:3)",
                      "a car (3:10)",
                      "humour (2:4)",
                      "After sorting by rarity product...",
                      "Narta has these useful things:",
                      "humour (2:4)",
                      "a car (3:10)",
                      "a shoulder to cry on (15:3)");

              String rawConsoleOutput =
                  tapSystemOutNormalized(() -> Main.main(new String[0])).trim();
              List<String> cleanedOutput = clean(rawConsoleOutput);

              assertThat(cleanedOutput).isEqualTo(expectedOutputParts);
            });
  }
}
