package test;

import static org.assertj.core.api.Assertions.*;

import java.util.List;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import main.UsefulnessEvaluator;

public class UsefulnessEvaluatorTests {

  @Test
  @DisplayName("can track side effects associated with a drug treatment")
  void can_make_a_printer() {
    Treatment treatment = new Treatment("Baldross-11");

    UsefulnessEvaluator<Treatment, SideEffect> drugEvaluator =
        new UsefulnessEvaluator<Treatment, SideEffect>(treatment);

    assertThat(drugEvaluator).isInstanceOf(UsefulnessEvaluator.class);
  }

  @Test
  @DisplayName("can track contractors bidding on a construction project")
  void can_make_a_medical_receptionist() {
    ConstructionProject project = new ConstructionProject("skate park");
    List<Contractor> contractorsBidding =
        List.of(new Contractor("RUCO"), new Contractor("Danbo Enterprises"));

    UsefulnessEvaluator<ConstructionProject, Contractor> bidEvaluator =
        new UsefulnessEvaluator<>(project, contractorsBidding);

    assertThat(bidEvaluator).isInstanceOf(UsefulnessEvaluator.class);
  }

  @Test
  @DisplayName("can track exercises associated with a muscle group")
  void can_make_a_fighter() {
    String muscleGroup = "traps";

    List<Exercise> effectiveExercises =
        List.of(new Exercise("rack pull"), new Exercise("upright row"));

    UsefulnessEvaluator<String, Exercise> exerciseEvaluator =
        new UsefulnessEvaluator<>(muscleGroup, effectiveExercises);

    assertThat(exerciseEvaluator).isInstanceOf(UsefulnessEvaluator.class);
  }
}

class Treatment {
  public Treatment(String name) {}
}

class SideEffect implements Comparable<SideEffect> {

  @Override
  public int compareTo(SideEffect o) {
    // TODO Auto-generated method stub
    return 0;
  }
}

class Contractor implements Comparable<Contractor> {

  public Contractor(String name) {}

  @Override
  public int compareTo(Contractor o) {
    // TODO Auto-generated method stub
    return 0;
  }
}

class ConstructionProject {

  public ConstructionProject(String name) {}
}

class Exercise implements Comparable<Exercise> {

  public Exercise(String name) {}

  @Override
  public int compareTo(Exercise o) { // TODO Auto-generated method stub
    return 0;
  }
}
