package main;

import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/**
 * This **currently** represents a character in a video game and the equipment that they carry,
 * using a String for the character and a List of Equipment...but it could represent ANYthing and
 * the usefulnesses (my word!) associated with that thing. What is considered a "usefulness" is
 * intentionally left vague. You could have a superhero and the special powers associated with them.
 * Or a hockey card collection and the cards in that collection. Or a study technique and the
 * benefits that technique provides.
 *
 * <p>Make this class a parameterized class that uses generics for both the thing and the the type
 * of usefulnesses it has. THE TYPE OF USEFULNESSES MUST IMPLEMENT Comparable!
 *
 * @author jpratt
 * @param <T1> the type of the thing that has usefulnesses
 * @param <T2> the type of the usefulnesses
 */
public class UsefulnessEvaluator {

  private String thing;
  private List<Equipment> currentUsefulnesses;

  /**
   * Creates a UsefulnessEvaluator with a given thing that has usefulnesses and the usefulnesses it
   * currently has.
   *
   * @param thing the thing with usefulnesses
   * @param currentUsefulnesses a List of usefulnesses already associated with the thing
   */
  public UsefulnessEvaluator(String thing, List<Equipment> currentUsefulnesses) {
    this.thing = thing;
    this.currentUsefulnesses = currentUsefulnesses;
  }

  /**
   * Creates a UsefulnessEvaluator with a given thing and no current usefulnesses.
   *
   * @param thing the thing that may eventually have usefulnesses
   */
  public UsefulnessEvaluator(String thing) {
    this(thing, List.of());
  }

  /**
   * Add a usefulness to the current usefulnesses - it goes to the "end of the line".
   *
   * @param usefulness the usefulness to add
   */
  public void add(Equipment usefulness) {
    currentUsefulnesses.add(usefulness);
  }

  /**
   * Sorts currentUsefulnesses by their natural order.
   *
   * <p>This modifies currentUsefulnesses.
   */
  public void sort() {
    // TODO: use Collections.sort to sort currentUsefulnesses by T2's natural order
  }

  /**
   * Sorts currentUsefulnesses using the given comparator.
   *
   * @param comparator the comparator to use to sort
   */
  public void sortBy(Comparator<Equipment> comparator) {
    // TODO: use Collections.sort to sort currentUsefulnesses by the given comparator
  }

  /**
   * Returns the usefulness currently at the "top" of the List of currentUsefulnesses.
   *
   * @return the first element in the List; null if the List is empty
   */
  public Equipment chooseFirst() {
    return currentUsefulnesses.isEmpty() ? null : currentUsefulnesses.remove(0);
  }

  /**
   * Returns a String version of this UsefulnessEvaluator. It looks like this:
   *
   * <pre>
   * [thing that has usefulnesses] has these useful things:
   * [list of usefulnesses, one per line]
   * </pre>
   */
  @Override
  public String toString() {
    return String.format("%s has these useful things:%n%s", thing, multiline(currentUsefulnesses));
  }

  private String multiline(List<Equipment> usefulnesses) {
    String result = "";
    for (Equipment usefulness : usefulnesses) {
      result += usefulness + "\n";
    }

    return result.trim();
  }
}
