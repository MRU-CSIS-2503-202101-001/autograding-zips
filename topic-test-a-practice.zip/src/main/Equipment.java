package main;

public class Equipment {}
