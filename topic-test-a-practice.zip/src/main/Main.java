package main;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Main {

  public static void main(String[] args) {

    // TODO: create a Scanner to get keyboard input

    // TODO: create an array of Benefits called benefits that holds the following two
    //       benefits:
    //       1) desc: humour, valuation: 2, rarity: 4
    //       2) desc: a car, valuation: 3, rarity: 10

    // this turns the array of Benefits you made into a List - this code works fine, so please
    // don't touch it!
    final List<Benefit> benefitsAsList = new ArrayList<>(Arrays.asList(benefits));

    System.out.print("Friend name? ");
    // TODO: get the friend's name via your Scanner

    System.out.println();

    System.out.print("Friend age? ");
    // TODO: get the friend's age via your Scanner

    // TODO: create a new Friend with the given name and age

    System.out.println();

    System.out.print("Benefit name? ");
    // TODO: get the friend's benefit name via your Scanner

    System.out.println();

    System.out.print("Benefit value? ");
    // TODO: get the friend's benefit value via your Scanner

    System.out.println();

    System.out.print("Benefit rarity? ");
    // TODO: get the friend's benefit rarity via your Scanner

    System.out.println();

    // TODO: create a new Benefit with the given name, value, and rarity

    // TODO: create a new UsefulnessEvaluator using the friend object and benefitsAsList

    // TODO: add the new benefit to the evaluator...there's a method for that....

    System.out.println();

    // TODO: print out the evaluator

    System.out.println();
    System.out.println("After sorting by natural order...");
    System.out.println();

    // TODO: sort the benefits in the evaluator by their natural order...there's a method for
    // that...

    // TODO: print out the evaluator

    System.out.println();
    System.out.println("After sorting by rarity product...");
    System.out.println();

    // TODO: sort the benefits in the evaluator by the BenefitRarityProductComparator you
    // made...there's a method for that...

    // TODO: print out the evaluator
  }
}
