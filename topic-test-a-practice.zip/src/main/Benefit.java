package main;

/**
 * Represents a Benefit that a friend provides.
 *
 * @author jpratt
 */
public class Benefit {

  private String desc;
  private int valuation;
  private int rarity;

  /**
   * Creates a Benefit with a given description, valuation, and rarity.
   *
   * @param desc a brief description of this Benefit
   * @param valuation the perceived value of this Benefit; higher numbers are better
   * @param rarity the perceived rarity of this Benefit; lower numbers are better
   */
  public Benefit(String desc, int valuation, int rarity) {
    this.desc = desc;
    this.valuation = valuation;
    this.rarity = rarity;
  }

  public String getDescription() {
    return desc;
  }

  public int getValuation() {
    return valuation;
  }

  public int getRarity() {
    return rarity;
  }

  /**
   * Returns a "[desc] ([valuation]:[rarity])" kinda String.
   *
   * @return a String in the above format
   */
  @Override
  public String toString() {
    return String.format("%s (%d:%d)", desc, valuation, rarity);
  }
}
