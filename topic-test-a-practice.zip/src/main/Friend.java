package main;

public class Friend {

  private String friendName;
  private int friendAge;

  public Friend(String friendName, int friendAge) {
    this.friendName = friendName;
    this.friendAge = friendAge;
  }

  @Override
  public String toString() {
    return friendName;
  }
}
