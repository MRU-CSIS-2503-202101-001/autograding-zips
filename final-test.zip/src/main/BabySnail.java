package main;

import java.util.Comparator;
import java.util.Objects;

/**
 * Represents a cute, slimy BabySnail. Isn't it just _adorable_?!?
 *
 * @author jpratt
 */
public class BabySnail {

  private int ageInDays;
  private double slimeosity;

  public BabySnail(int ageInDays, double slimeosity) {
    this.ageInDays = ageInDays;
    this.slimeosity = slimeosity;
  }

  public BabySnail(int ageInDays) {
    this(ageInDays, 0);
  }

  public BabySnail(double slimeosity) {
    this(0, slimeosity);
  }

  public void setAgeInDays(int numDays) {
    this.ageInDays = numDays;
  }

  public void setSlimeosity(double slimeosity) {
    this.slimeosity = slimeosity;
  }

  @Override
  public String toString() {
    return String.format("[age: %d, slime: %.2f]", ageInDays, slimeosity);
  }
}
