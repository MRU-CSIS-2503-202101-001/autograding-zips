package main;

import java.util.Iterator;

public interface NotEvilBiotechCorpBFLInterface<E extends Comparable<E>> {

  /**
   * Returns true if there are no elements in this BFL.
   *
   * @return true if no elements exist in this BFL
   */
  boolean isEmpty();

  /**
   * Returns the number of elements that come before the lower bound cutoff and above the upper
   * bound cutoff.
   *
   * @return the number of elements out of range
   */
  int numElementsOutOfRange();

  /**
   * Returns the number of elements that are in the range bounded by the lower bound cutoff and
   * upper bound cutoff, inclusive on both ends.
   *
   * @return the number of elements in range
   */
  int numElementsInRange();

  /**
   * Returns the total number of elements in this BFL, both in and out of range.
   *
   * @return the number of elements in this BFL
   */
  int size();

  /**
   * Adds an element to this BFL, following the rules outlined in the spec.
   *
   * @param e the element being added
   */
  void add(E e);

  /**
   * Returns the number of elements in range that equal (yes, using equals()) the given element. If
   * the element is not in range, or no such element can be found in range in this BFL, 0 is
   * returned.
   *
   * @param e the element whose frequency is being found
   * @return the number of e's in this BFL
   */
  int frequency(E e);

  /**
   * Returns an iterator that iterates over the elements out of range, behaving as outlined in the
   * spec.
   *
   * @return an iterator that iterates over the elements out of range
   */
  Iterator<E> iterator();
}
