package test;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import main.BoundedFrequencyList;

@DisplayName("BFL Basic Iterator Tests")
public class BFL_Basic_Iterator_Tests {

  private static final int SOME_INCLUSIVE_LOWER_BOUND = 10;
  private static final int SOME_INCLUSIVE_UPPER_BOUND = 10;

  private BoundedFrequencyList<Integer> BFL;

  @BeforeEach
  void setUp() {
    BFL = new BoundedFrequencyList<>(SOME_INCLUSIVE_LOWER_BOUND, SOME_INCLUSIVE_UPPER_BOUND);
  }

  @Test
  @DisplayName("iterating when everything is under the lower bound")
  void iterating_when_everything_is_under_the_lower_bound() {

    BFL.add(3);
    BFL.add(8);
    BFL.add(1);

    // because BFL implements Iterable<E>, we can test it
    // as if it were a List<E>!
    assertThat(BFL).containsExactly(1, 8, 3);
  }

  @Test
  @DisplayName("iterating when everything is over the upper bound")
  void iterating_when_everything_is_over_the_upper_bound() {

    BFL.add(43);
    BFL.add(11);
    BFL.add(910);

    // because BFL implements Iterable<E>, we can test it
    // as if it were a List<E>!
    assertThat(BFL).containsExactly(43, 11, 910);
  }

  @Test
  @DisplayName("iterating when everything is in range")
  void iterating_when_everything_is_in_range() {

    BFL.add(10);
    BFL.add(10);

    // because BFL implements Iterable<E>, we can test it
    // as if it were a List<E>!
    assertThat(BFL).isEmpty();
  }

  @Test
  @DisplayName("iterating when things are all over the place")
  void iterating_when_things_are_all_over_the_place() {

    List.of(1, 2, 10, 11, 9, 4, 910, 10, 910, 1, 10).forEach(BFL::add);

    // because BFL implements Iterable<E>, we can test it
    // as if it were a List<E>!
    assertThat(BFL).containsExactly(1, 4, 9, 2, 1, 11, 910, 910);
  }
}
