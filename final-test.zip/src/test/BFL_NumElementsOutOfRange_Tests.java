package test;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import main.BoundedFrequencyList;
import main.NotEvilBiotechCorpBFLInterface;

@DisplayName("BFL NumElementsOutOfRange Tests")
public class BFL_NumElementsOutOfRange_Tests {

  private static final int SOME_INCLUSIVE_LOWER_BOUND = 4;
  private static final int SOME_INCLUSIVE_UPPER_BOUND = 8;

  private NotEvilBiotechCorpBFLInterface<Integer> BFL;

  @BeforeEach
  void setUp() {
    BFL = new BoundedFrequencyList<>(SOME_INCLUSIVE_LOWER_BOUND, SOME_INCLUSIVE_UPPER_BOUND);
  }

  @Test
  @DisplayName("an empty BFL has 0 out of range")
  void an_empty_BFL_has_0_out_of_range() {

    assertThat(BFL.numElementsOutOfRange()).isZero();
  }

  @Test
  @DisplayName("a BFL with everything in range has 0 out of range")
  void a_BFL_with_everything_in_range_has_0_out_of_range() {

    List.of(4, 4, 5, 7, 8, 8).forEach(BFL::add);

    assertThat(BFL.numElementsOutOfRange()).isZero();
  }

  @Test
  @DisplayName("a BFL with everything under lower limit has that many things out of range")
  void a_BFL_with_everything_under_lower_limit_has_that_many_things_out_of_range() {

    List<Integer> numsUnderLowerLimit = List.of(-1, 3, 3, 2, 1, 0);

    numsUnderLowerLimit.forEach(BFL::add);

    assertThat(BFL.numElementsOutOfRange()).isEqualTo(numsUnderLowerLimit.size());
  }

  @Test
  @DisplayName("a BFL with everything over upper limit has that many things out of range")
  void a_BFL_with_everything_over_upper_limit_has_that_many_things_out_of_range() {

    List<Integer> numsOverUpperLimit = List.of(11, 9, 10);

    numsOverUpperLimit.forEach(BFL::add);

    assertThat(BFL.numElementsOutOfRange()).isEqualTo(numsOverUpperLimit.size());
  }

  @Test
  @DisplayName("a BFL with things over and under has all those things out of range")
  void a_BFL_with_things_over_and_under_has_all_those_things_out_of_range() {

    List<Integer> numsOutOfRange = List.of(11, 1, 9, 3);

    numsOutOfRange.forEach(BFL::add);

    assertThat(BFL.numElementsOutOfRange()).isEqualTo(numsOutOfRange.size());
  }

  @Test
  @DisplayName("a bunch of things on either side of the boundaries")
  void a_bunch_of_things_on_either_side_of_the_boundaries() {

    List<Integer> nums = List.of(3, 3, 4, 4, 5, 5, 5, 7, 7, 7, 8, 8, 8, 8, 9, 9, 9);

    nums.forEach(BFL::add);

    assertThat(BFL.numElementsOutOfRange()).isEqualTo(5);
  }
}
