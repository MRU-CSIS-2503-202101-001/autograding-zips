package test;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import main.BoundedFrequencyList;
import main.NotEvilBiotechCorpBFLInterface;

@DisplayName("BFL Size Tests")
public class BFL_Size_Tests {

  private static final int SOME_INCLUSIVE_LOWER_BOUND = 7;
  private static final int SOME_INCLUSIVE_UPPER_BOUND = 10;

  private NotEvilBiotechCorpBFLInterface<Integer> BFL;

  @BeforeEach
  void setUp() {
    BFL = new BoundedFrequencyList<>(SOME_INCLUSIVE_LOWER_BOUND, SOME_INCLUSIVE_UPPER_BOUND);
  }

  @Test
  @DisplayName("a new BFL has size 0")
  void a_new_BFL_has_size_0() {

    assertThat(BFL.size()).isZero();
  }

  @Test
  @DisplayName("a BFL with one element and it's under the lower bound has size 1")
  void a_BFL_with_one_element_and_it_s_under_the_lower_bound_has_size_1() {

    BFL.add(3);

    assertThat(BFL.size()).isEqualTo(1);
  }

  @Test
  @DisplayName("a BFL with one element and it's over the upper bound has size 1")
  void a_BFL_with_one_element_and_it_s_over_the_upper_bound_has_size_1() {

    BFL.add(33);

    assertThat(BFL.size()).isEqualTo(1);
  }

  @Test
  @DisplayName("a BFL with one element and it's in bounds has size 1")
  void a_BFL_with_one_element_and_it_s_in_bounds_has_size_1() {

    BFL.add(9);

    assertThat(BFL.size()).isEqualTo(1);
  }

  @Test
  @DisplayName("let's rock")
  void lets_rock() {
    List<Integer> inBounds = List.of(7, 8, 9, 10, 9, 8, 7);
    List<Integer> outOfBounds =
        List.of(1, 2, 3, 4, 5, 6, 11, 12, 13, 14, 13, 12, 11, 6, 5, 4, 3, 2, 1);

    inBounds.forEach(BFL::add);
    outOfBounds.forEach(BFL::add);

    assertThat(BFL.size()).isEqualTo(inBounds.size() + outOfBounds.size());
  }
}
