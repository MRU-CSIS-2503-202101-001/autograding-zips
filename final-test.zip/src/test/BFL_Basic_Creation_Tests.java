package test;

import static org.assertj.core.api.Assertions.*;

import java.util.Comparator;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import main.BabySnail;
import main.BoundedFrequencyList;

@DisplayName("BFL Basic Creation Tests")
public class BFL_Basic_Creation_Tests {

  private static final int SOME_INCLUSIVE_LOWER_BOUND = 7;
  private static final int SOME_INCLUSIVE_UPPER_BOUND = 10;

  private BoundedFrequencyList<Integer> BFL;

  @BeforeEach
  void setUp() {
    BFL = new BoundedFrequencyList<>(SOME_INCLUSIVE_LOWER_BOUND, SOME_INCLUSIVE_UPPER_BOUND);
  }

  @Test
  @DisplayName(
      "attempting to create a new BFL where the lower bound is greater than the higher bound throws an IllegalArgumentException")
  void
      attempting_to_create_a_new_BFL_where_the_lower_bound_is_greater_than_the_higher_bound_throws_an_IllegalArgumentException() {

    assertThatIllegalArgumentException()
        .isThrownBy(
            () -> {
              new BoundedFrequencyList<Integer>(20, 10);
            });
  }

  @Test
  @DisplayName(
      "attempting to create a new BFL where the lower bound is eqaul to the higher bound doesn't throw an IllegalArgumentException")
  void
      attempting_to_create_a_new_BFL_where_the_lower_bound_is_eqaul_to_the_higher_bound_doesn_t_throw_an_IllegalArgumentException() {

    assertThatCode(
            () -> {
              new BoundedFrequencyList<Integer>(10, 10);
            })
        .doesNotThrowAnyException();
  }
  
  @Test
  @DisplayName("you can create a BF that uses a given Comparator")
  void you_can_create_a_BF_that_uses_a_given_Comparator() {

    Comparator<BabySnail> descendingAgeComparator =
        Comparator.comparing(BabySnail::ageInDays).reversed();

    assertThatCode(
            () -> {
              int lowerBoundAge = 10;
              int upperBoundAge = 15;

              // if you're confused why the upper bound age is
              // being used in the first argument to the constructor,
              // remember that the comparator is DESCENDING, so
              // higher numbers come before lower ones
              new BoundedFrequencyList<>(
                  new BabySnail(upperBoundAge),
                  new BabySnail(lowerBoundAge),
                  descendingAgeComparator);
            })
        .doesNotThrowAnyException();
  }

  @Test
  @DisplayName("a new BFL is empty")
  void a_new_BFL_is_empty() {

    assertThat(BFL.isEmpty()).isTrue();
  }

  @Test
  @DisplayName("a new BFL has size 0")
  void a_new_BFL_has_size_0() {

    assertThat(BFL.size()).isZero();
  }

  @Test
  @DisplayName("a new BFL has no elements out of range")
  void a_new_BFL_has_no_elements_out_of_range() {

    assertThat(BFL.numElementsOutOfRange()).isZero();
  }

  @Test
  @DisplayName("a new BFL has no elements in range")
  void a_new_BFL_has_no_elements_in_range() {

    assertThat(BFL.numElementsInRange()).isZero();
  }

  @Test
  @DisplayName("a new BFL has nothing to iterate over")
  void a_new_BFL_has_nothing_to_iterate_over() {

    assertThat(BFL.iterator().hasNext()).isFalse();
  }
}
