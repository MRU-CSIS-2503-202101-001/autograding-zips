package test;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import main.BabySnail;

@DisplayName("BabySnail Equality Tests")
public class BabySnail_Equality_Tests {

  @Test
  @DisplayName("two BabySnails are equal if they are the same object in memory")
  void two_BabySnails_are_equal_if_they_are_the_same_object_in_memory() {

    BabySnail bsOne = new BabySnail(3, 1.0);

    assertThat(bsOne).isEqualTo(bsOne);
  }

  @Test
  @DisplayName("two BabySnails are equal if the age and slime are the same")
  void two_BabySnails_are_equal_if_the_age_and_slime_are_the_same() {

    BabySnail bsOne = new BabySnail(3, 1.0);
    BabySnail bsTwo = new BabySnail(3, 1.0);

    assertThat(bsOne).isEqualTo(bsTwo);
  }

  @Test
  @DisplayName("two BabySnails are not equal if the age is same but slime is different")
  void two_BabySnails_are_not_equal_if_the_age_is_same_but_slime_is_different() {

    BabySnail bsOne = new BabySnail(3, 1.0);
    BabySnail bsThree = new BabySnail(3, 2.0);

    assertThat(bsOne).isNotEqualTo(bsThree);
  }

  @Test
  @DisplayName("two BabySnails are not equal if the slime is same but the age is different")
  void two_BabySnails_are_not_equal_if_the_slime_is_same_but_the_age_is_different() {

    BabySnail bsThree = new BabySnail(3, 2.0);
    BabySnail bsFour = new BabySnail(4, 2.0);

    assertThat(bsThree).isNotEqualTo(bsFour);
  }

  @Test
  @DisplayName("two BabySnails are not equal if everything is different")
  void two_BabySnails_are_not_equal_if_everything_is_different() {

    BabySnail bsOne = new BabySnail(3, 1.0);
    BabySnail bsFour = new BabySnail(4, 2.0);

    assertThat(bsOne).isNotEqualTo(bsFour);
  }
}
