package test;

import java.util.Comparator;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import main.BabySnail;

@DisplayName("BabySnail Comparator Creation Tests")
public class BabySnail_Comparator_Creation_Tests {

  @SuppressWarnings("unused")
  @Test
  @DisplayName("you can create a comparator that compares ages")
  void you_can_create_a_comparator_that_compares_ages() {

    // normally you're not going to make "tests" like this that
    // don't assert anything...these are just here to make sure
    // that folks are making BabySnail fields accessible through
    // accessor methods

    // using Comparator class methods
    Comparator<BabySnail> compWithMethod = Comparator.comparing(BabySnail::ageInDays);

    // using lambdas
    Comparator<BabySnail> compWithLambda =
        (bs1, bs2) -> Integer.compare(bs1.ageInDays(), bs2.ageInDays());
  }

  @SuppressWarnings("unused")
  @Test
  @DisplayName("you can create a comparator that compares slimeosity")
  void you_can_create_a_comparator_that_compares_slimeosity() {

    // using Comparator class methods
    Comparator<BabySnail> compWithMethod = Comparator.comparing(BabySnail::slimeosity).reversed();

    // using lambdas
    Comparator<BabySnail> compWithLambda =
        (bs1, bs2) -> Double.compare(bs2.ageInDays(), bs1.ageInDays());
  }
}
