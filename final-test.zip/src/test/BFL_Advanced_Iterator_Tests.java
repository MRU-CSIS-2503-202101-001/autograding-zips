package test;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.Comparator;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import main.BabySnail;
import main.BoundedFrequencyList;

@DisplayName("BFL Advanced Iterator Tests")
public class BFL_Advanced_Iterator_Tests {

  private static final BabySnail SOME_INCLUSIVE_LOWER_BOUND_BS = new BabySnail(1.2);
  private static final BabySnail SOME_INCLUSIVE_UPPER_BOUND_BS = new BabySnail(8.5);

  private static final BabySnail MADAME_SLIME = new BabySnail(321.123);
  private static final BabySnail SLIPPERY_SUE = new BabySnail(9.8);
  private static final BabySnail GREASY_GUS = new BabySnail(8.5);
  private static final BabySnail ABRASIVE_ARNA = new BabySnail(1.0);
  private static final BabySnail DUSTY_RHODES = new BabySnail(0.3);

  private static final Comparator<BabySnail> ascSlimeosityComparator =
      (bs1, bs2) -> Double.compare(bs1.slimeosity(), bs2.slimeosity());

  private BoundedFrequencyList<BabySnail> BFL;

  @BeforeEach
  void setUp() {
    BFL =
        new BoundedFrequencyList<>(
            SOME_INCLUSIVE_LOWER_BOUND_BS, SOME_INCLUSIVE_UPPER_BOUND_BS, ascSlimeosityComparator);
  }

  @Test
  @DisplayName("iterating when everything is under the lower bound")
  void iterating_when_everything_is_under_the_lower_bound() {

    BFL.add(DUSTY_RHODES);
    BFL.add(ABRASIVE_ARNA);

    // because BFL implements Iterable<E>, we can test it
    // as if it were a List<E>!
    assertThat(BFL).containsExactly(ABRASIVE_ARNA, DUSTY_RHODES);
  }

  @Test
  @DisplayName("iterating when everything is over the upper bound")
  void iterating_when_everything_is_over_the_upper_bound() {

    BFL.add(SLIPPERY_SUE);
    BFL.add(MADAME_SLIME);

    // because BFL implements Iterable<E>, we can test it
    // as if it were a List<E>!
    assertThat(BFL).containsExactly(SLIPPERY_SUE, MADAME_SLIME);
  }

  @Test
  @DisplayName("iterating when everything is in range")
  void iterating_when_everything_is_in_range() {

    BFL.add(GREASY_GUS);

    // because BFL implements Iterable<E>, we can test it
    // as if it were a List<E>!
    assertThat(BFL).isEmpty();
  }

  @Test
  @DisplayName("iterating when things are all over the place")
  void iterating_when_things_are_all_over_the_place() {

    List.of(GREASY_GUS, ABRASIVE_ARNA, SLIPPERY_SUE, MADAME_SLIME, DUSTY_RHODES).forEach(BFL::add);

    // because BFL implements Iterable<E>, we can test it
    // as if it were a List<E>!
    assertThat(BFL).containsExactly(DUSTY_RHODES, ABRASIVE_ARNA, SLIPPERY_SUE, MADAME_SLIME);
  }
}
