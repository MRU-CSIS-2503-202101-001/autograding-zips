package test;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import main.BabySnail;

@DisplayName("BabySnail Natural Ordering Tests")
public class BabySnail_Natural_Ordering_Tests {

  @Test
  @DisplayName(
      "two BabySnails are equal from an ordering point of view if they are the same object in memory")
  void
      two_BabySnails_are_equal_from_an_ordering_point_of_view_if_they_are_the_same_object_in_memory() {

    BabySnail bsOne = new BabySnail(3, 1.0);

    assertThat(bsOne).isEqualByComparingTo(bsOne);
  }

  @Test
  @DisplayName(
      "two BabySnails are equal from an ordering point of view if their age and slime is the same")
  void
      two_BabySnails_are_equal_from_an_ordering_point_of_view_if_their_age_and_slime_is_the_same() {

    BabySnail bsOne = new BabySnail(3, 1.0);
    BabySnail bsTwo = new BabySnail(3, 1.0);

    assertThat(bsOne).isEqualByComparingTo(bsTwo);
  }

  @Test
  @DisplayName("if two BabySnails have the same age, then they are ordered by their slime's order")
  void if_two_BabySnails_have_the_same_age_then_they_are_ordered_by_their_slimes_order() {

    BabySnail bsOne = new BabySnail(3, 1.0);
    BabySnail bsThree = new BabySnail(3, 2.0);

    // confused why 1.0 is greater than 2.0? remember: the natural
    // ordering has slimeosity in descending order!
    assertThat(bsOne).isGreaterThan(bsThree);
  }

  @Test
  @DisplayName(
      "if two BabySnails don't have the same age, then they are ordered by their age's order")
  void if_two_BabySnails_don_t_have_the_same_age_then_they_are_ordered_by_their_age_s_order() {

    BabySnail bsThree = new BabySnail(3, 2.0);
    BabySnail bsFour = new BabySnail(4, 2.0);

    assertThat(bsThree).isLessThan(bsFour);
  }
}
