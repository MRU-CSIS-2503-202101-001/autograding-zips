package test;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import main.BoundedFrequencyList;
import main.NotEvilBiotechCorpBFLInterface;

@DisplayName("BFL NumElementsInRange Tests")
public class BFL_NumElementsInRange_Tests {

  private static final int SOME_INCLUSIVE_LOWER_BOUND = 10;
  private static final int SOME_INCLUSIVE_UPPER_BOUND = 11;

  private NotEvilBiotechCorpBFLInterface<Integer> BFL;

  @BeforeEach
  void setUp() {
    BFL = new BoundedFrequencyList<>(SOME_INCLUSIVE_LOWER_BOUND, SOME_INCLUSIVE_UPPER_BOUND);
  }

  @Test
  @DisplayName("an empty BFL has 0 in range")
  void an_empty_BFL_has_0_in_range() {

    assertThat(BFL.numElementsInRange()).isZero();
  }

  @Test
  @DisplayName("a BFL with everything out of range has 0 in range")
  void a_BFL_with_everything_out_of_range_has_0_in_range() {

    List.of(8, 1, 12, 321).forEach(BFL::add);

    assertThat(BFL.numElementsInRange()).isZero();
  }

  @Test
  @DisplayName("a BFL with everything in range reports the number of things in range")
  void a_BFL_with_things_over_and_under_has_all_those_things_out_of_range() {

    List<Integer> numsInRange = List.of(10, 10, 10, 11, 11, 11, 11);

    numsInRange.forEach(BFL::add);

    assertThat(BFL.numElementsInRange()).isEqualTo(numsInRange.size());
  }
}
