package test;

import static org.junit.jupiter.api.Assertions.assertTimeoutPreemptively;

import java.time.Duration;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.Timeout;

import main.BoundedFrequencyList;
import main.NotEvilBiotechCorpBFLInterface;

@DisplayName("BFL Speed Tests")
@Timeout(1) // fail tests if they take longer than 1 second
public class BFL_Speed_Tests {

  private static final int SOME_INCLUSIVE_LOWER_BOUND = 7;
  private static final int SOME_INCLUSIVE_UPPER_BOUND = 10;

  private NotEvilBiotechCorpBFLInterface<Integer> BFL;

  @BeforeEach
  void setUp() {
    BFL = new BoundedFrequencyList<>(SOME_INCLUSIVE_LOWER_BOUND, SOME_INCLUSIVE_UPPER_BOUND);
  }

  @Test
  @DisplayName("adding elements to the BFL should happen in constant time")
  void adding_elements_to_the_BFL_should_happen_in_constant_time() {

    assertTimeoutPreemptively(
        Duration.ofSeconds(1),
        () -> {
          for (int i = 0; i < 1_000_000; i++) {
            BFL.add(i % 20);
          }
        });
  }

  @Test
  @DisplayName("getting frequencies from the BFL should happen in constant time")
  void getting_frequencies_from_the_BFL_should_happen_in_constant_time() {

    for (int i = 0; i < 1_000_000; i++) {
      BFL.add(i % 20);
    }

    assertTimeoutPreemptively(
        Duration.ofSeconds(1),
        () -> {
          for (int i = 0; i < 1_000_000; i++) {
            BFL.frequency(i);
          }
        });
  }

  @Test
  @DisplayName("getting the size of a BFL should happen in constant time")
  void getting_the_size_of_a_BFL_should_happen_in_constant_time() {

    for (int i = 0; i < 1_000_000; i++) {
      BFL.add(i % 20);
    }

    assertTimeoutPreemptively(
        Duration.ofSeconds(1),
        () -> {
          for (int i = 0; i < 1_000_000; i++) {
            BFL.size();
          }
        });
  }

  @Test
  @DisplayName("getting the number of elements in range in a BFL should happen in constant time")
  void getting_the_number_of_elements_in_range_in_a_BFL_should_happen_in_constant_time() {

    for (int i = 0; i < 1_000_000; i++) {
      BFL.add(i % 20);
    }

    assertTimeoutPreemptively(
        Duration.ofSeconds(1),
        () -> {
          for (int i = 0; i < 1_000_000; i++) {
            BFL.numElementsInRange();
          }
        });
  }

  @Test
  @DisplayName(
      "getting the number of elements out of range in a BFL should happen in constant time")
  void getting_the_number_of_elements_out_of_range_in_a_BFL_should_happen_in_constant_time() {

    for (int i = 0; i < 1_000_000; i++) {
      BFL.add(i % 20);
    }

    assertTimeoutPreemptively(
        Duration.ofSeconds(1),
        () -> {
          for (int i = 0; i < 1_000_000; i++) {
            BFL.numElementsOutOfRange();
          }
        });
  }
}
