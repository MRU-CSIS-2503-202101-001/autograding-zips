package test;

import static org.assertj.core.api.Assertions.*;

import java.util.Comparator;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import main.BabySnail;
import main.BoundedFrequencyList;

@DisplayName("BFL Advanced Creation Tests")
public class BFL_Advanced_Creation_Tests {

  @Test
  @DisplayName("you can create a BF that uses a given Comparator")
  void you_can_create_a_BF_that_uses_a_given_Comparator() {

    Comparator<BabySnail> descendingAgeComparator =
        Comparator.comparing(BabySnail::ageInDays).reversed();

    assertThatCode(
            () -> {
              int lowerBoundAge = 10;
              int upperBoundAge = 15;

              // if you're confused why the upper bound age is
              // being used in the first argument to the constructor,
              // remember that the comparator is DESCENDING, so
              // higher numbers come before lower ones
              new BoundedFrequencyList<>(
                  new BabySnail(upperBoundAge),
                  new BabySnail(lowerBoundAge),
                  descendingAgeComparator);
            })
        .doesNotThrowAnyException();
  }
}
