package test;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import main.BoundedFrequencyList;
import main.NotEvilBiotechCorpBFLInterface;

@DisplayName("BFL Frequency Tests")
public class BFL_Frequency_Tests {

  private static final int SOME_INCLUSIVE_LOWER_BOUND = 10;
  private static final int SOME_INCLUSIVE_UPPER_BOUND = 20;

  private NotEvilBiotechCorpBFLInterface<Integer> BFL;

  @BeforeEach
  void setUp() {
    BFL = new BoundedFrequencyList<>(SOME_INCLUSIVE_LOWER_BOUND, SOME_INCLUSIVE_UPPER_BOUND);
  }

  @Test
  @DisplayName("the frequency of anything in an empty table is 0")
  void the_frequency_of_anything_in_an_empty_table_is_0() {

    assertThat(BFL.frequency(0)).isZero();
    assertThat(BFL.frequency(9)).isZero();
    assertThat(BFL.frequency(10)).isZero();
    assertThat(BFL.frequency(11)).isZero();
    assertThat(BFL.frequency(19)).isZero();
    assertThat(BFL.frequency(20)).isZero();
    assertThat(BFL.frequency(21)).isZero();
  }

  @Test
  @DisplayName("the frequency of something under the lower limit is 0 even if it was added")
  void the_frequency_of_something_under_the_lower_limit_is_0_even_if_it_was_added() {
    BFL.add(5);

    assertThat(BFL.frequency(5)).isZero();
  }

  @Test
  @DisplayName("the frequency of something over the upper limit is 0 even if it was added")
  void the_frequency_of_something_over_the_upper_limit_is_0_even_if_it_was_added() {
    BFL.add(21);

    assertThat(BFL.frequency(21)).isZero();
  }

  @Test
  @DisplayName("the frequency of something in range is equal to the number of such things added")
  void the_frequency_of_something_in_range_is_equal_to_the_number_of_such_things_added() {
    BFL.add(10);

    assertThat(BFL.frequency(10)).isEqualTo(1);

    BFL.add(20);
    BFL.add(20);

    assertThat(BFL.frequency(20)).isEqualTo(2);
  }
}
