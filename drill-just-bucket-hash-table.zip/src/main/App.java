package main;

public class App {

  public void run() {

    // TODO: code this run so that it works as shown in the example
    //       output in the instructions - and so that all the tests in MainTests pass as well

  }

  private void displayInstructions() {
    System.out.println("Hi! I'm a simple Hashtable app!");
    System.out.println("Enter in a 2-or-more letter word that is a palindrome.");
    System.out.println("(I'm not actually gonna check if the word *is* a palindrome!)");
    System.out.println("I will add it to the hashtable, using the number of letters as a key.");
    System.out.println(
        "The value for the key will be a list of palindromes with that many letters.");
    System.out.println();

    System.out.println("When you enter an empty line, I will then ask you to enter a number.");
    System.out.println(
        "I will then show you a list of palindromes that have that number of letters.");

    System.out.println("Ready? Start entering palindromes!");
  }
}
