package main;

import java.util.ArrayList;
import java.util.List;

/**
 * Methods that make reporting on what's going on inside our hash table a lot easier.
 *
 * @author jpratt
 */
public interface Reportable {

  /**
   * Returns a List of Strings that detail the collisions that were made in the hash table over the
   * course of a test. As the format will depend on the type of hash table being used, look at the
   * tests that use this method to determine that format.
   *
   * @return a List of Strings in the necessary format
   */
  List<String> collisionLog();

  /**
   * Returns a List of Strings representing the contents of the backing array. The format will
   * depend on the type of hash table being used; look at the tests that use this method to
   * determine that specific format.
   *
   * @return a List of Strings in the necessary format
   */
  default List<String> backingArrayContents() {
    Object[] array = backingArray();
    int length = array.length;
    List<String> results = new ArrayList<>();
    for (int i = 0; i < length; i++) {
      if (array[i] == null) {
        results.add(String.format("[%d][EMPTY]", i));
      } else {
        results.add(String.format("[%d][%s]", i, array[i].toString()));
      }
    }
    return results;
  }

  /**
   * Returns the backing array used in the hash table.
   *
   * <p>LIKE NORMALLY DON'T DO THIS, OK?!? I JUST AM USING THIS TO BUILD THE TESTS AND ONLY IN AN
   * EDUCATIONAL SETTING!
   *
   * @return the backing array used in the hash table
   */
  Object[] backingArray();

  /**
   * Returns the load factor for the hash table. The load factor is defined as the number of items
   * in the hash table divided by its capacity.
   *
   * <p>So, for example, if you have a hash table with a capacity of 10 and there are 4 things in
   * it, its load factor is 0.4.
   *
   * <p>For a chained hash table, the load factor could definitely be over 1.0!
   *
   * @return the load factor of the hash table
   */
  double loadFactor();

  /**
   * Returns the capacity for the given hash table. We'll define the capacity of a hash table as
   * being the number of "slots" in the backing array.
   *
   * @return the capacity of the hash table
   */
  default int capacity() {
    return backingArray().length;
  }
}
