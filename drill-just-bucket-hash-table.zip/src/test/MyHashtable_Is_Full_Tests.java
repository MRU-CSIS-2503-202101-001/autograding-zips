package test;

import static org.assertj.core.api.Assertions.*;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import main.MyHashtable;

@DisplayName("MyHashtable Is Full Tests")
public class MyHashtable_Is_Full_Tests {

  @Test
  @DisplayName("you can't fill up this MHT")
  void you_cant_fill_up_this_MHT() {
    int someCapacity = 2;
    MyHashtable<String, Integer> hashtable = new MyHashtable<>(someCapacity);

    assertThat(hashtable.isFull()).isFalse();

    hashtable.put("foo", 11);

    assertThat(hashtable.isFull()).isFalse();

    hashtable.put("bar", 11);

    assertThat(hashtable.isFull()).isFalse();
  }

  @Test
  @DisplayName("if you try and add to an MHT already at capacity, it's cool with that")
  void if_you_try_and_add_to_an_MHT_already_at_capacity_it_cool_with_that() {
    int someCapacity = 2;
    MyHashtable<String, Integer> hashtable = new MyHashtable<>(someCapacity);

    hashtable.put("foo", 11);
    hashtable.put("bar", 11);

    assertThatCode(() -> hashtable.put("baz", 13)).doesNotThrowAnyException();
  }
}
