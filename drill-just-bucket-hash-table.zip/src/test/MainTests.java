package test;

import static com.github.stefanbirkner.systemlambda.SystemLambda.*;
import static org.assertj.core.api.Assertions.assertThat;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import main.Main;

public class MainTests {

  private List<String> clean(String rawConsoleOutput) {
    String[] split = rawConsoleOutput.split("\n");
    return Arrays.stream(split)
        .filter(s -> !s.isEmpty())
        .map(String::trim)
        .collect(Collectors.toList());
  }

  @Test
  @DisplayName("no entries case")
  void no_entries_case() throws Exception {

    withTextFromSystemIn("", "3")
        .execute(
            () -> {
              List<String> expectedOutputParts =
                  List.of(
                      "Hi! I'm a simple Hashtable app!",
                      "Enter in a 2-or-more letter word that is a palindrome.",
                      "(I'm not actually gonna check if the word *is* a palindrome!)",
                      "I will add it to the hashtable, using the number of letters as a key.",
                      "The value for the key will be a list of palindromes with that many letters.",
                      "When you enter an empty line, I will then ask you to enter a number.",
                      "I will then show you a list of palindromes that have that number of letters.",
                      "Ready? Start entering palindromes!",
                      "palindrome?",
                      "num letters?",
                      "Here are the palindromes I have with 3 letters:",
                      "No palindromes found with that length!");

              String rawConsoleOutput =
                  tapSystemOutNormalized(() -> Main.main(new String[0])).trim();
              List<String> cleanedOutput = clean(rawConsoleOutput);

              assertThat(cleanedOutput).isEqualTo(expectedOutputParts);
            });
  }

  @Test
  @DisplayName("all 3-letter words")
  void all_3_letter_words() throws Exception {

    withTextFromSystemIn("wow", "pop", "gig", "", "3")
        .execute(
            () -> {
              List<String> expectedOutputParts =
                  List.of(
                      "Hi! I'm a simple Hashtable app!",
                      "Enter in a 2-or-more letter word that is a palindrome.",
                      "(I'm not actually gonna check if the word *is* a palindrome!)",
                      "I will add it to the hashtable, using the number of letters as a key.",
                      "The value for the key will be a list of palindromes with that many letters.",
                      "When you enter an empty line, I will then ask you to enter a number.",
                      "I will then show you a list of palindromes that have that number of letters.",
                      "Ready? Start entering palindromes!",
                      "palindrome?",
                      "palindrome?",
                      "palindrome?",
                      "palindrome?",
                      "num letters?",
                      "Here are the palindromes I have with 3 letters:",
                      "- wow",
                      "- pop",
                      "- gig");

              String rawConsoleOutput =
                  tapSystemOutNormalized(() -> Main.main(new String[0])).trim();
              List<String> cleanedOutput = clean(rawConsoleOutput);

              assertThat(cleanedOutput).isEqualTo(expectedOutputParts);
            });
  }

  @Test
  @DisplayName("multiple pali's...but ask for size not there")
  void multiple_palis_but_ask_for_size_not_there() throws Exception {

    withTextFromSystemIn("radar", "level", "abba", "poop", "redder", "", "2")
        .execute(
            () -> {
              List<String> expectedOutputParts =
                  List.of(
                      "Hi! I'm a simple Hashtable app!",
                      "Enter in a 2-or-more letter word that is a palindrome.",
                      "(I'm not actually gonna check if the word *is* a palindrome!)",
                      "I will add it to the hashtable, using the number of letters as a key.",
                      "The value for the key will be a list of palindromes with that many letters.",
                      "When you enter an empty line, I will then ask you to enter a number.",
                      "I will then show you a list of palindromes that have that number of letters.",
                      "Ready? Start entering palindromes!",
                      "palindrome?",
                      "palindrome?",
                      "palindrome?",
                      "palindrome?",
                      "palindrome?",
                      "palindrome?",
                      "num letters?",
                      "Here are the palindromes I have with 2 letters:",
                      "No palindromes found with that length!");

              String rawConsoleOutput =
                  tapSystemOutNormalized(() -> Main.main(new String[0])).trim();
              List<String> cleanedOutput = clean(rawConsoleOutput);

              assertThat(cleanedOutput).isEqualTo(expectedOutputParts);
            });
  }
}
