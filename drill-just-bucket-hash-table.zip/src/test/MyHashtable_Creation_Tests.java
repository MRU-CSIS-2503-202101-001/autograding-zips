package test;

import static org.assertj.core.api.Assertions.*;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import main.MyHashtable;

@DisplayName("MyHashtable Creation Tests")
public class MyHashtable_Creation_Tests {

  @Test
  @DisplayName("you can create a MHT with a given capacity")
  void you_can_create_a_MHT_with_a_given_capacity() {
    int someCapacity = 13;
    MyHashtable<String, Integer> hashtable = new MyHashtable<>(someCapacity);

    assertThat(hashtable.isEmpty()).isTrue();
    assertThat(hashtable.isFull()).isFalse();
    assertThat(hashtable.size()).isZero();
    assertThat(hashtable.loadFactor()).isCloseTo(0, within(0.01));
    assertThat(hashtable.capacity()).isEqualTo(someCapacity);
  }

  @Test
  @DisplayName("you can create a MHT with the default capacity")
  void you_can_create_a_MHT_with_the_default_capacity() {
    MyHashtable<String, Integer> hashtable = new MyHashtable<>();

    assertThat(hashtable.isEmpty()).isTrue();
    assertThat(hashtable.isFull()).isFalse();
    assertThat(hashtable.size()).isZero();
    assertThat(hashtable.loadFactor()).isCloseTo(0, within(0.01));
    assertThat(hashtable.capacity()).isEqualTo(MyHashtable.DEFAULT_CAPACITY);
  }
}
