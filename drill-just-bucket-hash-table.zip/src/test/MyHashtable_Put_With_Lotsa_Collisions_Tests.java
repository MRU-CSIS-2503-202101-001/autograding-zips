package test;

import static org.assertj.core.api.Assertions.*;

import java.util.List;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import main.MyHashtable;

@DisplayName("MyHashtable Put With Lotsa Collisions Tests")
public class MyHashtable_Put_With_Lotsa_Collisions_Tests {

  @Test
  @DisplayName("let's go boom-boom")
  void lets_go_boom_boom() {

    MyHashtable<ReallyBadString, String> hashtable = new MyHashtable<>();

    List<String> words =
        List.of("the", "quick", "blue", "mink", "wedgied", "my", "freaking", "dog", "yo!");

    for (String word : words) {
      hashtable.put(new ReallyBadString(word), word);
    }

    List<String> expectedCollisions =
        List.of(
            "collision for quick",
            "collision for mink",
            "collision for wedgied",
            "collision for my",
            "collision for freaking",
            "collision for dog",
            "collision for yo!");

    List<String> expectedContents =
        List.of(
            "[0][EMPTY]",
            "[1][EMPTY]",
            "[2][EMPTY]",
            "[3][[the:the]=>[quick:quick]=>[wedgied:wedgied]=>[dog:dog]=>[yo!:yo!]]",
            "[4][EMPTY]",
            "[5][EMPTY]",
            "[6][EMPTY]",
            "[7][[blue:blue]=>[mink:mink]=>[my:my]=>[freaking:freaking]]",
            "[8][EMPTY]",
            "[9][EMPTY]",
            "[10][EMPTY]");

    assertThat(hashtable.collisionLog()).isEqualTo(expectedCollisions);
    assertThat(hashtable.backingArrayContents()).isEqualTo(expectedContents);
    assertThat(hashtable.size()).isEqualTo(9);
    assertThat(hashtable.loadFactor())
        .isCloseTo((9.0 / MyHashtable.DEFAULT_CAPACITY), within(0.01));
  }

  @Test
  @DisplayName("son_of_lets go boom-boom")
  void son_of_lets_go_boom_boom() {

    MyHashtable<ReallyBadInt, Integer> hashtable = new MyHashtable<>();

    List<Integer> nums = List.of(1, 3, 5, 7, 9, 1, 2, 4, 3);

    for (Integer num : nums) {
      hashtable.put(new ReallyBadInt(num), num);
    }

    List<String> expectedCollisions = List.of("collision for 1", "collision for 3");

    List<String> expectedContents =
        List.of(
            "[0][EMPTY]",
            "[1][[1:1]=>[1:1]]",
            "[2][[2:2]]",
            "[3][[3:3]=>[3:3]]",
            "[4][[4:4]]",
            "[5][[5:5]]",
            "[6][EMPTY]",
            "[7][[7:7]]",
            "[8][EMPTY]",
            "[9][[9:9]]",
            "[10][EMPTY]");

    assertThat(hashtable.collisionLog()).isEqualTo(expectedCollisions);
    assertThat(hashtable.backingArrayContents()).isEqualTo(expectedContents);
    assertThat(hashtable.loadFactor())
        .isCloseTo((9.0 / MyHashtable.DEFAULT_CAPACITY), within(0.01));
  }

  private static class ReallyBadInt {
    private int i;

    public ReallyBadInt(int i) {
      this.i = i;
    }

    @Override
    public String toString() {
      return "" + i;
    }

    @Override
    public boolean equals(Object o) {
      return false; // that's right! no equality! madness!
    }

    @Override
    public int hashCode() {
      return i;
    }
  }

  private static class ReallyBadString {
    private String s;

    public ReallyBadString(String s) {
      this.s = s;
    }

    @Override
    public String toString() {
      return s;
    }

    @Override
    public boolean equals(Object o) {
      return s.equals(o);
    }

    @Override
    // what? the hash code depends on the length of the string. ARE YOU MAD?!?!? (yes)
    public int hashCode() {
      if (s.length() % 2 == 0) {
        return 7;
      } else {
        return 3;
      }
    }
  }
}
