package test;

import static org.assertj.core.api.Assertions.*;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import main.MyHashtable;
import main.PlainOldMap;

@DisplayName("MyHashtable No Null Key Arguments Tests")
public class MyHashtable_No_Null_Key_Arguments_Tests {

  @Test
  @DisplayName("trying to put something in with a null key throws an IllegalArgumentException")
  void trying_to_put_something_in_with_a_null_key_throws_an_IllegalArgumentException() {

    PlainOldMap<Integer, String> hashtable = new MyHashtable<>();

    assertThatExceptionOfType(IllegalArgumentException.class)
        .isThrownBy(() -> hashtable.put(null, "baboomba!"))
        .withMessage("Null keys are not allowed.");
  }

  @Test
  @DisplayName("trying to get something with a null key throws an IllegalArgumentException")
  void trying_to_get_something_with_a_null_key_throws_an_IllegalArgumentException() {

    PlainOldMap<Integer, String> hashtable = new MyHashtable<>();

    assertThatExceptionOfType(IllegalArgumentException.class)
        .isThrownBy(() -> hashtable.get(null))
        .withMessage("Null keys are not allowed.");
  }

  @Test
  @DisplayName("trying to remove something via a null key throws an IllegalArgumentException")
  void trying_to_remove_something_via_a_null_key_throws_an_IllegalArgumentException() {

    PlainOldMap<Integer, String> hashtable = new MyHashtable<>();

    assertThatExceptionOfType(IllegalArgumentException.class)
        .isThrownBy(() -> hashtable.remove(null))
        .withMessage("Null keys are not allowed.");
  }

  @Test
  @DisplayName(
      "trying to see if the hashtable contains a null key throws an IllegalArgumentException")
  void trying_to_see_if_the_hashtable_contains_a_null_key_throws_an_IllegalArgumentException() {

    PlainOldMap<Integer, String> hashtable = new MyHashtable<>();

    assertThatExceptionOfType(IllegalArgumentException.class)
        .isThrownBy(() -> hashtable.contains(null))
        .withMessage("Null keys are not allowed.");
  }
}
