package test;

import static org.assertj.core.api.Assertions.*;

import java.util.List;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import main.MyHashtable;

@DisplayName("MyHashtable Put With Replacements No Collisions Tests")
public class MyHashtable_Put_With_Replacements_No_Collisions_Tests {

  @Test
  @DisplayName("let's replace the stuffs")
  void let_s_replace_the_stuffs() {

    MyHashtable<Integer, String> hashtable = new MyHashtable<>();

    List<Integer> firstSetOfKeys = List.of(1, 3, 5, 7, 9, 1, 1, 9, 9);

    for (Integer num : firstSetOfKeys) {
      hashtable.put(Integer.valueOf(num), String.valueOf(num).repeat(num));
    }

    String[] expectedContentsBeforeReplacement = {
      "[0][EMPTY]",
      "[1][[1:1]]",
      "[2][EMPTY]",
      "[3][[3:333]]",
      "[4][EMPTY]",
      "[5][[5:55555]]",
      "[6][EMPTY]",
      "[7][[7:7777777]]",
      "[8][EMPTY]",
      "[9][[9:999999999]]",
      "[10][EMPTY]"
    };
    List<String> expectedContents = List.of(expectedContentsBeforeReplacement);

    assertThat(hashtable.backingArrayContents()).isEqualTo(expectedContents);
    assertThat(hashtable.size()).isEqualTo(5);
    assertThat(hashtable.loadFactor()).isCloseTo(5.0 / MyHashtable.DEFAULT_CAPACITY, within(0.01));

    // Now let's do some replacin'! (just on the 1's and 3's)

    int multiplier = 2;
    List<Integer> secondSetOfKeys = List.of(1, 1, 1, 3);
    for (Integer num : secondSetOfKeys) {
      hashtable.put(Integer.valueOf(num), "x".repeat(num * multiplier));
      multiplier++;
    }

    String[] expectedContentsAfterReplacement = {
      "[0][EMPTY]",
      "[1][[1:xxxx]]",
      "[2][EMPTY]",
      "[3][[3:xxxxxxxxxxxxxxx]]",
      "[4][EMPTY]",
      "[5][[5:55555]]",
      "[6][EMPTY]",
      "[7][[7:7777777]]",
      "[8][EMPTY]",
      "[9][[9:999999999]]",
      "[10][EMPTY]"
    };

    expectedContents = List.of(expectedContentsAfterReplacement);

    assertThat(hashtable.backingArrayContents()).isEqualTo(expectedContents);
    assertThat(hashtable.size()).isEqualTo(5);
    assertThat(hashtable.loadFactor()).isCloseTo(5.0 / MyHashtable.DEFAULT_CAPACITY, within(0.01));
  }
}
