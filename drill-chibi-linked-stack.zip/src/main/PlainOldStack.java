package main;

/**
 * A generic Stack interface. Ho hum.
 *
 * @author jpratt
 * @param <T> the type of things in the Stack
 */
public interface PlainOldStack<T> {

  /**
   * Returns true iff there is nothing in this PlainOldStack.
   *
   * @return true iff there is nothing in this PlainOldStack
   */
  boolean isEmpty();

  /**
   * Returns true iff the number of items in this PlainOldStack equals its capacity.
   *
   * @return true iff this PlainOldStack holds a number of items equal to its capacity
   */
  boolean isFull();

  /**
   * Pushes t onto the top of this PlainOldStack.
   *
   * @param t the thing to push onto the top of this PlainOldStack
   */
  void push(T t);

  /**
   * Removes the top element from this PlainOldStack. If the PlainOldStack is empty, a
   * NoSuchElementException is thrown.
   *
   * @return the element at the top of this PlainOldStack
   * @throws NoSuchElementException if this PlainOldStack is empty
   */
  T pop();

  /**
   * Returns the top element of this PlainOldStack. If the PlainOldStack is empty, a
   * NoSuchElementException is thrown.
   *
   * @return the top element of this PlainOldStack
   * @throws NoSuchElementException if this PlainOldStack is empty
   */
  T top();
}
