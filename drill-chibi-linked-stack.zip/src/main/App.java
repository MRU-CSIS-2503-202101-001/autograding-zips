package main;

import java.util.ArrayList;
import java.util.List;

public class App {

  private List<String> displayedWords = new ArrayList<>();

  public void run() {

    // TODO: code this run so that it works as shown in the example
    //       output in the instructions - and so that all the tests in MainTests pass as well

  }

  /**
   * Use this when you want to add a word to the textual display of the stack and display it to
   * console.
   *
   * @param word the word going on top of the stack
   */
  private void addAndDisplay(String word) {
    System.out.println();
    displayedWords.add(0, String.format("| %s%n----------", word));
    System.out.println(String.join("\n", displayedWords));
  }

  /**
   * Use this when you want to remove the top word from the stack and display the result to console.
   */
  private void removeAndDisplay() {
    System.out.println();
    displayedWords.remove(0);
    System.out.println(String.join("\n", displayedWords));
  }

  private void displayInstructions() {
    System.out.println("Hi! I'm the Chibi Linked Stack app!");
    System.out.println("Every word you enter on a line will be added to me.");
    System.out.println("I will turn each word to uppercase before it is added.");

    System.out.println();

    System.out.println("After every two words pushed onto me, I'll pop one.");
    System.out.println("I will stop when you enter an empty line.");

    System.out.println("Ready? Start entering words!");
  }
}
