package test;

import static org.assertj.core.api.Assertions.*;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import main.ChibiLinkedStack;
import main.PlainOldStack;

@DisplayName("ChibiLinkedStack Push When Almost Full Tests")
public class ChibiLinkedStack_Push_When_Almost_Full_Tests {

  @Test
  @DisplayName("attempting to push to a nearly full CLS fills the stack")
  void attempting_to_push_to_a_nearly_full_CLS_fills_the_stack() {

    PlainOldStack<String> stack = new ChibiLinkedStack<>();

    stack.push("almost");
    stack.push("full");

    stack.push("safe - barely");

    assertThat(stack.isFull());
    assertThat(stack.top()).isEqualTo("safe - barely");
  }
}
