package test;

import static org.assertj.core.api.Assertions.*;

import java.util.NoSuchElementException;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import main.ChibiLinkedStack;

@DisplayName("ChibiLinkedStack Pop And Pop When Empty Tests")
public class ChibiLinkedStack_Pop_And_Top_When_Empty_Tests {

  @Test
  @DisplayName("attempting to pop from an empty CLS throws a NoSuchElementException")
  void attempting_to_pop_from_an_empty_CLS_throws_a_NoSuchElementException() {

    ChibiLinkedStack<String> stack = new ChibiLinkedStack<>();

    assertThatExceptionOfType(NoSuchElementException.class)
        .isThrownBy(() -> stack.pop())
        .withMessage("No element to pop - the stack is empty.");
  }

  @Test
  @DisplayName("attempting to top from an empty CLS throws a NoSuchElementException")
  void attempting_to_top_from_an_empty_CLS_throws_a_NoSuchElementException() {

    ChibiLinkedStack<String> stack = new ChibiLinkedStack<>();

    assertThatExceptionOfType(NoSuchElementException.class)
        .isThrownBy(() -> stack.top())
        .withMessage("No element on top - the stack is empty.");
  }

  @Test
  @DisplayName(
      "when you pop the last thing from the CLS, and then do it again, you get a NoSuchElementException")
  void
      when_you_pop_the_last_thing_from_the_CLS_and_then_do_it_again_you_get_a_NoSuchElementException() {

    ChibiLinkedStack<Integer> stack = new ChibiLinkedStack<>();

    stack.push(43);

    stack.pop(); // OK here...

    assertThatExceptionOfType(NoSuchElementException.class)
        .isThrownBy(() -> stack.pop()) // ...but not here!
        .withMessage("No element to pop - the stack is empty.");
  }
}
