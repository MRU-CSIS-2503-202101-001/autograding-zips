package test;

import static org.assertj.core.api.Assertions.*;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import main.ChibiLinkedStack;

@DisplayName("ChibiLinkedStack Pop When Not Empty Tests")
public class ChibiLinkedStack_Pop_When_Not_Empty_Tests {

  @Test
  @DisplayName("popping from a one-item stack gives you the thing and now you have an empty stack")
  void popping_from_a_one_item_stack_gives_you_the_thing_and_now_you_have_an_empty_stack() {

    ChibiLinkedStack<String> stack = new ChibiLinkedStack<>();

    stack.push("mort!");

    String popped = stack.pop();

    assertThat(popped).isEqualTo("mort!");
    assertThat(stack.isEmpty()).isTrue();
    assertThat(stack.isFull()).isFalse();
  }

  @Test
  @DisplayName(
      "popping from a two-item stack gives you the thing and now you have a one-item stack")
  void popping_from_a_two_item_stack_gives_you_the_thing_and_now_you_have_a_one_item_stack() {

    ChibiLinkedStack<String> stack = new ChibiLinkedStack<>();

    stack.push("mort!");
    stack.push("bort?");

    String popped = stack.pop();
    String onTopAfterPop = stack.top();

    assertThat(popped).isEqualTo("bort?");
    assertThat(onTopAfterPop).isEqualTo("mort!");
    assertThat(stack.isEmpty()).isFalse();
    assertThat(stack.isFull()).isFalse();
  }
}
