package test;

import static org.assertj.core.api.Assertions.*;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import main.ChibiLinkedStack;

@DisplayName("ChibiLinkedStack Top When Not Empty Tests")
public class ChibiLinkedStack_Top_When_Not_Empty_Tests {

  @Test
  @DisplayName(
      "looking at the top of a one-item stack gives you the thing and the stack hasn't changed")
  void looking_at_the_top_of_a_one_item_stack_gives_you_the_thing_and_the_stack_hasn_t_changed() {

    ChibiLinkedStack<String> stack = new ChibiLinkedStack<>();

    stack.push("mort!");

    String topped = stack.top();

    assertThat(topped).isEqualTo("mort!");
    assertThat(stack.isEmpty()).isFalse();
    assertThat(stack.isFull()).isFalse();
  }

  @Test
  @DisplayName(
      "looking at the top of a two-item stack gives you the thing and the stack hasn't changed")
  void looking_at_the_top_of_a_two_item_stack_gives_you_the_thing_and_the_stack_hasn_t_changed() {

    ChibiLinkedStack<String> stack = new ChibiLinkedStack<>();

    stack.push("mort!");
    stack.push("bort?");

    String topped = stack.top();

    assertThat(topped).isEqualTo("bort?");
    assertThat(stack.isEmpty()).isFalse();
    assertThat(stack.isFull()).isFalse();
  }
}
