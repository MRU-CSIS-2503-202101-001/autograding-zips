package test;

import static org.assertj.core.api.Assertions.*;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import main.ChibiLinkedStack;
import main.FullStackException;

@DisplayName("ChibiLinkedStack Push When Full Tests")
public class ChibiLinkedStack_Push_When_Full_Tests {

  @Test
  @DisplayName("attempting to push to a full CLS throws a FullStackException")
  void attempting_to_push_to_a_full_CLS_throws_a_FullStackException() {

    ChibiLinkedStack<String> stack = new ChibiLinkedStack<>();

    stack.push("almost");
    stack.push("full");
    stack.push("!");

    assertThatExceptionOfType(FullStackException.class)
        .isThrownBy(() -> stack.push("boom!"))
        .withMessage("Cannot push to stack - it is full.");
  }

  @Test
  @DisplayName("attempting to push twice to a full CLS throws a FullStackException")
  void attempting_to_push_twice_to_a_full_CLS_throws_a_FullStackException() {

    ChibiLinkedStack<String> stack = new ChibiLinkedStack<>();

    stack.push("almost");
    stack.push("full");
    stack.push("!");

    assertThatExceptionOfType(FullStackException.class)
        .isThrownBy(() -> stack.push("boom!"))
        .withMessage("Cannot push to stack - it is full.");

    assertThatExceptionOfType(FullStackException.class)
        .isThrownBy(() -> stack.push("boom, already!"))
        .withMessage("Cannot push to stack - it is full.");
  }
}
