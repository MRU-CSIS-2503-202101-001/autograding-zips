package test;

import static org.assertj.core.api.Assertions.*;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import main.PlainOldStack;
import main.ChibiLinkedStack;

@DisplayName("ChibiLinkedStack Creation Tests")
public class ChibiLinkedStack_Creation_Tests {

  @Test
  @DisplayName("a new CLS is empty")
  void a_new_CLS_is_empty() {

    PlainOldStack<String> list = new ChibiLinkedStack<>();

    assertThat(list.isEmpty()).isTrue();
    assertThat(list.isFull()).isFalse();
  }
}
