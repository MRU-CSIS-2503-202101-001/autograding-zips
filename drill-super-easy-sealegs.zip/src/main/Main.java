package main;

public class Main {

  public static void main(String[] args) {

    // TODO: write the number of our course to the console.
    // Hint: it's not 1502.

  }
}
