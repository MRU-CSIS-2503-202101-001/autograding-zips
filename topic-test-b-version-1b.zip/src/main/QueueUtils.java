package main;

public class QueueUtils {

  /**
   * Moves every element in the given queue matching a given lucky element to the front of the
   * queue. If there are more than one such item, their order is maintained.
   *
   * @param <T> the type of the elements in the queue
   * @param queue the queue to act upon
   * @param luckyElement the object to match in order to move to the front of the queue
   * @throws IllegalArgumentException when lucky element is null
   */
  public static <T> void moveToTheFront(SimpleQueue<T> queue, T luckyElement) {
    // TODO: complete this method so that it follows the spec in the
    //       method docs and so that it passes all tests.
    //
    //       REMEMBER: The only collections you can use to build your
    //       solution are those in the prereqs!
  }
}
