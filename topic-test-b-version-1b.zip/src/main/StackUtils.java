package main;

import java.util.Comparator;

public class StackUtils {

  /**
   * Removes all elements from a given Stack using a given comparator; each element such that
   * comparator.compare(filter, element) <= 0 is removed, while keeping the relative order of the
   * remaining elements.
   *
   * <p>Put another way, this method alters the given stack so that every element "less than or
   * equal to" the filter is taken away without changing the order of elements in the stack.
   *
   * @param <T> the type of the elements in stack
   * @param stack the stack to filter
   * @param filter the object used to determine whether an element is filtered out of the stack
   * @param comparator the comparator to use for filtering
   * @throws IllegalArgumentException when filter or comparator is null
   */
  public static <T> void filter(SimpleStack<T> stack, T filter, Comparator<T> comparator) {
    // TODO: complete this method so that it follows the spec in the
    //       method docs and so that it passes all tests.
    //
    //       REMEMBER: The only collections you can use to build your
    //       solution are those in the prereqs!
  }
}
