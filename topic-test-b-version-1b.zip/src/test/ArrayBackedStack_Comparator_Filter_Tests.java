package test;

import static org.assertj.core.api.Assertions.*;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import main.ArrayBackedStack;
import main.SimpleStack;
import main.StackUtils;

@DisplayName("ArrayBackedStack Comparator Filter Tests")
public class ArrayBackedStack_Comparator_Filter_Tests {

  private <T> List<T> emptyTheStack(SimpleStack<T> stackToEmpty) {
    List<T> contents = new ArrayList<>();
    while (!stackToEmpty.isEmpty()) {
      contents.add(stackToEmpty.pop());
    }
    return contents;
  }

  @Test
  @DisplayName("filtering a stack with a null filter throws an IllegalArgumentException")
  void filtering_a_stack_with_a_null_filter_throws_an_IllegalArgumentException() {

    SimpleStack<String> stack = new ArrayBackedStack<>();

    assertThatExceptionOfType(IllegalArgumentException.class)
        .isThrownBy(
            () -> {
              StackUtils.filter(stack, null, Comparator.naturalOrder());
            })
        .withMessage("Filter can't be null.");
  }

  @Test
  @DisplayName("filtering a stack with a null comparator throws an IllegalArgumentException")
  void filtering_a_stack_with_a_null_comparator_throws_an_IllegalArgumentException() {

    SimpleStack<String> stack = new ArrayBackedStack<>();

    assertThatExceptionOfType(IllegalArgumentException.class)
        .isThrownBy(
            () -> {
              StackUtils.filter(stack, "foo", null);
            })
        .withMessage("Filter comparator can't be null.");
  }

  @Test
  @DisplayName("filtering an empty stack gives you an empty stack")
  void filtering_an_empty_stack_gives_you_an_empty_stack() {

    SimpleStack<String> stack = new ArrayBackedStack<>();
    StackUtils.filter(stack, "foo", Comparator.naturalOrder());

    assertThat(stack.isEmpty()).isTrue();
  }

  @Test
  @DisplayName(
      "filtering a stack with all items greater than or equal to filter doesn't change the stack")
  void filtering_a_stack_with_all_items_greater_than_or_equal_to_filter_doesnt_change_the_stack() {

    SimpleStack<Integer> stack = new ArrayBackedStack<>();
    stack.push(3);
    stack.push(5);
    stack.push(9);

    StackUtils.filter(stack, 2, Comparator.naturalOrder());

    List<Integer> expectedStackContents = List.of(9, 5, 3);
    List<Integer> actualStackContents = emptyTheStack(stack);

    assertThat(actualStackContents).containsExactlyElementsOf(expectedStackContents);
  }

  @Test
  @DisplayName("filtering a single item and that item is on the top")
  void filtering_a_single_item_and_that_item_is_on_the_top() {

    SimpleStack<String> stack = new ArrayBackedStack<>();
    stack.push("my");
    stack.push("gog");
    stack.push("has");
    stack.push("fleas");

    StackUtils.filter(stack, "gleas", Comparator.naturalOrder());

    List<String> expectedStackContents = List.of("has", "gog", "my");
    List<String> actualStackContents = emptyTheStack(stack);

    assertThat(actualStackContents).containsExactlyElementsOf(expectedStackContents);
  }

  @Test
  @DisplayName("filtering a single item and that item is on the bottom")
  void filtering_a_single_item_and_that_item_is_on_the_bottom() {

    SimpleStack<Blorb> stack = new ArrayBackedStack<>();
    stack.push(new Blorb(14));
    stack.push(new Blorb(45));
    stack.push(new Blorb(16));
    stack.push(new Blorb(91));
    stack.push(new Blorb(100));

    StackUtils.filter(stack, new Blorb(15), Comparator.comparing(Blorb::getBlorbosity));

    List<Blorb> expectedStackContents =
        List.of(new Blorb(100), new Blorb(91), new Blorb(16), new Blorb(45));
    List<Blorb> actualStackContents = emptyTheStack(stack);

    assertThat(actualStackContents).containsExactlyElementsOf(expectedStackContents);
  }

  @Test
  @DisplayName("filtering a single item and that item is in the middle")
  void filtering_a_single_item_and_that_item_is_in_the_middle() {

    SimpleStack<Blorb> stack = new ArrayBackedStack<>();
    stack.push(new Blorb(15));
    stack.push(new Blorb(45));
    stack.push(new Blorb(0));
    stack.push(new Blorb(91));
    stack.push(new Blorb(100));

    StackUtils.filter(stack, new Blorb(1), Comparator.comparing(Blorb::getBlorbosity));

    List<Blorb> expectedStackContents =
        List.of(new Blorb(100), new Blorb(91), new Blorb(45), new Blorb(15));
    List<Blorb> actualStackContents = emptyTheStack(stack);

    assertThat(actualStackContents).containsExactlyElementsOf(expectedStackContents);
  }

  @Test
  @DisplayName("filtering out everything in a stack when there's just one thing")
  void filtering_out_everything_in_a_stack_when_theres_just_one_thing() {

    SimpleStack<Integer> stack = new ArrayBackedStack<>();
    stack.push(3);

    StackUtils.filter(stack, 3, Comparator.naturalOrder());

    List<Integer> expectedStackContents = List.of();
    List<Integer> actualStackContents = emptyTheStack(stack);

    assertThat(actualStackContents).containsExactlyElementsOf(expectedStackContents);
  }

  @Test
  @DisplayName("filtering out everything in a stack when there's multiple things")
  void filtering_out_everything_in_a_stack_when_theres_multiple_things() {

    SimpleStack<Integer> stack = new ArrayBackedStack<>();
    stack.push(98);
    stack.push(98);
    stack.push(98);
    stack.push(98);
    stack.push(98);

    StackUtils.filter(stack, 99, Comparator.naturalOrder());

    List<Integer> expectedStackContents = List.of();
    List<Integer> actualStackContents = emptyTheStack(stack);

    assertThat(actualStackContents).containsExactlyElementsOf(expectedStackContents);
  }

  private static class Blorb {
    private int blorbosity;

    Blorb(int blorbosity) {
      this.blorbosity = blorbosity;
    }

    int getBlorbosity() {
      return blorbosity;
    }

    @Override
    public String toString() {
      return String.format("b%d", blorbosity);
    }

    @Override
    public int hashCode() {
      final int prime = 31;
      int result = 1;
      result = prime * result + blorbosity;
      return result;
    }

    @Override
    public boolean equals(Object obj) {
      if (this == obj) {
        return true;
      }
      if (obj == null) {
        return false;
      }
      if (getClass() != obj.getClass()) {
        return false;
      }
      Blorb other = (Blorb) obj;
      if (blorbosity != other.blorbosity) {
        return false;
      }
      return true;
    }
  }
}
