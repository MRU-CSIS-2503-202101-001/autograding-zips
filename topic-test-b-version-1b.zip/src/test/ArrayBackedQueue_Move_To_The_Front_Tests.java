package test;

import static org.assertj.core.api.Assertions.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import main.ArrayBackedQueue;
import main.SimpleQueue;
import main.QueueUtils;

@DisplayName("ArrayBackedQueue Move To The Front Tests")
public class ArrayBackedQueue_Move_To_The_Front_Tests {

  private <T> List<T> emptyTheQueue(SimpleQueue<T> queueToEmpty) {
    List<T> contents = new ArrayList<>();
    while (!queueToEmpty.isEmpty()) {
      contents.add(queueToEmpty.dequeue());
    }
    return contents;
  }

  @Test
  @DisplayName("moving a null to the front throws an IllegalArgumentException")
  void moving_a_null_to_the_front_throws_an_IllegalArgumentException() {

    SimpleQueue<String> queue = new ArrayBackedQueue<>();

    assertThatExceptionOfType(IllegalArgumentException.class)
        .isThrownBy(
            () -> {
              QueueUtils.moveToTheFront(queue, null);
            })
        .withMessage("Can't use a null lucky element.");
  }

  @Test
  @DisplayName("when the queue is empty, nothing happens")
  void when_the_queue_is_empty_nothing_happens() {

    SimpleQueue<String> queue = new ArrayBackedQueue<>();
    QueueUtils.moveToTheFront(queue, "foo");

    assertThat(queue.isEmpty()).isTrue();
  }

  @Test
  @DisplayName("moving something that's not there doesn't change the queue")
  void moving_something_that_s_not_there_doesn_t_change_the_queue() {

    SimpleQueue<Integer> queue = new ArrayBackedQueue<>();
    queue.enqueue(3);
    queue.enqueue(5);
    queue.enqueue(9);

    QueueUtils.moveToTheFront(queue, 15);

    List<Integer> expectedQueueContents = List.of(3, 5, 9);
    List<Integer> actualQueueContents = emptyTheQueue(queue);

    assertThat(actualQueueContents).containsExactlyElementsOf(expectedQueueContents);
  }

  @Test
  @DisplayName("moving a single item and that item is already at the front")
  void moving_a_single_item_and_that_item_is_already_at_the_front() {

    SimpleQueue<String> queue = new ArrayBackedQueue<>();
    queue.enqueue("my");
    queue.enqueue("dog");
    queue.enqueue("has");
    queue.enqueue("fleas");

    QueueUtils.moveToTheFront(queue, "my");

    List<String> expectedQueueContents = List.of("my", "dog", "has", "fleas");
    List<String> actualQueueContents = emptyTheQueue(queue);

    assertThat(actualQueueContents).containsExactlyElementsOf(expectedQueueContents);
  }

  @Test
  @DisplayName("moving a single item and that item is at the tail")
  void moving_a_single_item_and_that_item_is_at_the_tail() {

    SimpleQueue<Blorb> queue = new ArrayBackedQueue<>();
    queue.enqueue(new Blorb(15));
    queue.enqueue(new Blorb(45));
    queue.enqueue(new Blorb(0));
    queue.enqueue(new Blorb(91));
    queue.enqueue(new Blorb(100));

    QueueUtils.moveToTheFront(queue, new Blorb(100));

    List<Blorb> expectedQueueContents =
        List.of(new Blorb(100), new Blorb(15), new Blorb(45), new Blorb(0), new Blorb(91));
    List<Blorb> actualQueueContents = emptyTheQueue(queue);

    assertThat(actualQueueContents).containsExactlyElementsOf(expectedQueueContents);
  }

  @Test
  @DisplayName("moving a single item and that item is in the middle")
  void moving_a_single_item_and_that_item_is_in_the_middle() {

    SimpleQueue<Blorb> queue = new ArrayBackedQueue<>();
    queue.enqueue(new Blorb(15));
    queue.enqueue(new Blorb(45));
    queue.enqueue(new Blorb(0));
    queue.enqueue(new Blorb(91));
    queue.enqueue(new Blorb(100));

    QueueUtils.moveToTheFront(queue, new Blorb(0));

    List<Blorb> expectedQueueContents =
        List.of(new Blorb(0), new Blorb(15), new Blorb(45), new Blorb(91), new Blorb(100));
    List<Blorb> actualQueueContents = emptyTheQueue(queue);

    assertThat(actualQueueContents).containsExactlyElementsOf(expectedQueueContents);
  }

  @Test
  @DisplayName("moving everything in a queue when there's just one thing")
  void filtering_out_everything_in_a_queue_when_theres_just_one_thing() {

    SimpleQueue<Integer> queue = new ArrayBackedQueue<>();
    queue.enqueue(3);

    QueueUtils.moveToTheFront(queue, 3);

    List<Integer> expectedQueueContents = List.of(3);
    List<Integer> actualQueueContents = emptyTheQueue(queue);

    assertThat(actualQueueContents).containsExactlyElementsOf(expectedQueueContents);
  }

  @Test
  @DisplayName("moving everything in a queue when there's multiple things")
  void filtering_out_everything_in_a_queue_when_theres_multiple_things() {

    Blorb blorbC1 = new Blorb(91);
    Blorb blorbC2 = new Blorb(91);
    Blorb blorbC3 = new Blorb(91);

    SimpleQueue<Blorb> queue = new ArrayBackedQueue<>();
    queue.enqueue(blorbC3);
    queue.enqueue(blorbC2);
    queue.enqueue(blorbC1);

    QueueUtils.moveToTheFront(queue, new Blorb(98));

    List<Blorb> expectedQueueContents = List.of(blorbC3, blorbC2, blorbC1);
    List<Blorb> actualQueueContents = emptyTheQueue(queue);

    assertThat(actualQueueContents).containsExactlyElementsOf(expectedQueueContents);
  }

  @Test
  @DisplayName("moving multiple items when there are multiple things")
  void moving_multiple_items_when_there_are_multiple_things() {

    Blorb blorbA = new Blorb(17);
    Blorb blorbB = new Blorb(2);
    Blorb blorbC1 = new Blorb(91);
    Blorb blorbC2 = new Blorb(91);
    Blorb blorbC3 = new Blorb(91);
    Blorb blorbD = new Blorb(-4);

    SimpleQueue<Blorb> queue = new ArrayBackedQueue<>();
    queue.enqueue(blorbA);
    queue.enqueue(blorbC1);
    queue.enqueue(blorbC2);
    queue.enqueue(blorbB);
    queue.enqueue(blorbD);
    queue.enqueue(blorbC3);

    QueueUtils.moveToTheFront(queue, new Blorb(91));

    List<Blorb> expectedQueueContents = List.of(blorbC1, blorbC2, blorbC3, blorbA, blorbB, blorbD);
    List<Blorb> actualQueueContents = emptyTheQueue(queue);

    assertThat(actualQueueContents).containsExactlyElementsOf(expectedQueueContents);
  }

  private static class Blorb {
    private int blorbosity;

    Blorb(int blorbosity) {
      this.blorbosity = blorbosity;
    }

    @Override
    public String toString() {
      return String.format("b%d", blorbosity);
    }

    @Override
    public int hashCode() {
      final int prime = 31;
      int result = 1;
      result = prime * result + blorbosity;
      return result;
    }

    @Override
    public boolean equals(Object obj) {
      if (this == obj) {
        return true;
      }
      if (obj == null) {
        return false;
      }
      if (getClass() != obj.getClass()) {
        return false;
      }
      Blorb other = (Blorb) obj;
      if (blorbosity != other.blorbosity) {
        return false;
      }
      return true;
    }
  }
}
