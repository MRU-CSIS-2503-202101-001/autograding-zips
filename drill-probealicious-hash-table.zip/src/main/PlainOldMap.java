package main;

public interface PlainOldMap<K, V> {

  /**
   * Puts the given k/v pair in the map. If the key already existed, it is replaced and the value
   * that's being replaced is returned. If this is a new key, then the k/v pair is added and null is
   * returned.
   *
   * <p>If this is being used with the open addressing hash table, an attempt to put when the hash
   * table is full will result in a FullHashtableException.
   *
   * @param k the key to add to the map
   * @param v the value associated with the key
   * @return either the value being replaced, or null if this is a new k/v entry
   * @throws FullHashtableException if this is the open addressing hashtable and it's full
   */
  V put(K k, V v);

  /**
   * Gets the value associated with the given key from this map.
   *
   * <p>If no such key is present, then null is returned.
   *
   * @param k the key being searched for
   * @return the value associated with the given key
   */
  V get(K k);

  /**
   * Removes the k/v pair for the given k in the map. If the pair exists, then the value is
   * returned; otherwise, null is returned.
   *
   * @param k the key of the entry to be removed
   * @return the value associated with the removed entry; null if no such entry present
   */
  V remove(K k);

  /**
   * Returns true if the given k is in the map.
   *
   * @param k the key being looked for
   * @return true iff the given key is in the map
   */
  boolean contains(K k);

  /**
   * Returns true if there are no elements in this map.
   *
   * @return true if there are no elements in this map
   */
  boolean isEmpty();

  /**
   * Returns true if this map is full. (This will only happen if you are doing the open addressing
   * hash table. If you are doing the chained table, then this should return false.)
   *
   * @return as per the above description
   */
  boolean isFull();

  /**
   * Returns the number of elements currently in this map.
   *
   * @return the number of elements currently in this map
   */
  int size();
}
