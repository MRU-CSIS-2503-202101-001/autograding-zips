package main;

import java.util.List;

/**
 * Methods that make reporting on what's going on inside our hash table a lot easier.
 *
 * @author jpratt
 */
public interface Reportable {

  /**
   * Returns a List of Strings that detail the collisions that were made in the hash table over the
   * course of a test. As the format will depend on the type of hash table being used, look at the
   * tests that use this method to determine that format.
   *
   * @return a List of Strings in the necessary format
   */
  List<String> collisionLog();

  /**
   * Returns a List of Strings representing the contents of the backing array. The format will
   * depend on the type of hash table being used; look at the tests that use this method to
   * determine that specific format.
   *
   * @return a List of Strings in the necessary format
   */
  List<String> backingArrayContents();

  /**
   * Returns a List of Strings that detail the replacements that were made in the hash table over
   * the course of a test. As the format will depend on the type of hash table being used, look at
   * the tests that use this method to determine that format.
   *
   * @return a List of Strings in the necessary format
   */
  List<String> replacementLog();

  /**
   * Returns the load factor for the hash table. The load factor is defined as the number of items
   * in the hash table divided by its capacity.
   *
   * <p>So, for example, if you have a hash table with a capacity of 10 and there are 4 things in
   * it, its load factor is 0.4.
   *
   * <p>For a chained hash table, the load factor could definitely be over 1.0!
   *
   * @return the load factor of the hash table
   */
  double loadFactor();

  /**
   * Returns the capacity for the given hash table. We'll define the capacity of a hash table as
   * being the number of "slots" in the backing array.
   *
   * @return the capacity of the hash table
   */
  int capacity();
}
