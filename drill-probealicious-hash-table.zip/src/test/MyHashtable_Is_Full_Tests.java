package test;

import static org.assertj.core.api.Assertions.*;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import main.FullHashtableException;
import main.MyHashtable;

@DisplayName("MyHashtable Is Full Tests")
public class MyHashtable_Is_Full_Tests {

  @Test
  @DisplayName("you can fill up a MHT")
  void you_can_fill_up_a_MHT() {
    int someCapacity = 2;
    MyHashtable<String, Integer> hashtable = new MyHashtable<>(someCapacity);

    assertThat(hashtable.isFull()).isFalse();

    hashtable.put("foo", 11);

    assertThat(hashtable.isFull()).isFalse();

    hashtable.put("bar", 11);

    assertThat(hashtable.isFull()).isTrue();
  }

  @Test
  @DisplayName("if you try and add to an already-full MHT, it throws a FullHashtableException")
  void if_you_try_and_add_to_an_already_full_MHT_it_throws_a_FullHashtableException() {
    int someCapacity = 2;
    MyHashtable<String, Integer> hashtable = new MyHashtable<>(someCapacity);

    hashtable.put("foo", 11);
    hashtable.put("bar", 11);

    assertThatExceptionOfType(FullHashtableException.class)
        .isThrownBy(() -> hashtable.put("baz", 13))
        .withMessage("Hashtable is full.");
  }
}
