package test;

import static org.assertj.core.api.Assertions.*;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import main.MyHashtable;

@DisplayName("MyHashtable Just Removing Tests")
public class MyHashtable_Just_Removing_Tests {

  @Test
  @DisplayName("removing something not there returns a null")
  void removing_something_not_there_returns_a_null() {
    int thingNotThere = 18;
    MyHashtable<Integer, String> hashtable = new MyHashtable<>();

    String removeResult = hashtable.remove(thingNotThere);
    assertThat(removeResult).isNull();

    hashtable.put(11, "bloop");

    removeResult = hashtable.remove(thingNotThere);
    assertThat(removeResult).isNull();
  }

  @Test
  @DisplayName("removing something when the hashtable just returns null - nothing explodes")
  void removing_something_when_the_hashtable_just_returns_null___nothing_explodes() {
    int thingNotThere = 18;
    MyHashtable<Integer, String> hashtable = new MyHashtable<>();

    String removeResult = hashtable.remove(thingNotThere);
    assertThat(removeResult).isNull();
  }

  @Test
  @DisplayName("removing something that is there returns that thing and reduces the size by one")
  void removing_something_that_is_there_returns_that_thing_and_reduces_the_size_by_one() {
    int someNumber = 9;
    Integer thingThatsThere = 18;
    String valueOfThingThatsThere = "yup, I'm there";
    MyHashtable<Integer, String> hashtable = new MyHashtable<>();

    hashtable.put(someNumber, "9");
    hashtable.put(thingThatsThere, valueOfThingThatsThere);

    int sizeBeforeRemove = hashtable.size();

    String removeResult = hashtable.remove(thingThatsThere);
    assertThat(removeResult).isEqualTo(valueOfThingThatsThere);
    assertThat(hashtable.size()).isEqualTo(sizeBeforeRemove - 1);
  }
}
