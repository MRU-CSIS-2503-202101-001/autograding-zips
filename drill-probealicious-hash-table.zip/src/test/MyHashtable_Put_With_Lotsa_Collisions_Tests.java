package test;

import static org.assertj.core.api.Assertions.*;

import java.util.List;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import main.MyHashtable;

@DisplayName("MyHashtable Put With Lotsa Collisions Tests")
public class MyHashtable_Put_With_Lotsa_Collisions_Tests {

  @Test
  @DisplayName("lets go boom-boom")
  void lets_go_boom_boom() {

    MyHashtable<ReallyBadString, String> hashtable = new MyHashtable<>();

    List<String> words =
        List.of("the", "quick", "blue", "mink", "wedgied", "my", "freaking", "dog", "yo!");

    for (String word : words) {
      hashtable.put(new ReallyBadString(word), word);
    }

    String[] collisions = {
      "Yay! the found a home at [3]!",
      "quick collided with the[3]",
      "Yay! quick found a home at [4]!",
      "Yay! blue found a home at [7]!",
      "mink collided with blue[7]",
      "Yay! mink found a home at [8]!",
      "wedgied collided with the[3]",
      "wedgied looking for a home at [4]",
      "Yay! wedgied found a home at [5]!",
      "my collided with blue[7]",
      "my looking for a home at [8]",
      "Yay! my found a home at [9]!",
      "freaking collided with blue[7]",
      "freaking looking for a home at [8]",
      "freaking looking for a home at [9]",
      "Yay! freaking found a home at [10]!",
      "dog collided with the[3]",
      "dog looking for a home at [4]",
      "dog looking for a home at [5]",
      "Yay! dog found a home at [6]!",
      "yo! collided with the[3]",
      "yo! looking for a home at [4]",
      "yo! looking for a home at [5]",
      "yo! looking for a home at [6]",
      "yo! looking for a home at [7]",
      "yo! looking for a home at [8]",
      "yo! looking for a home at [9]",
      "yo! looking for a home at [10]",
      "Yay! yo! found a home at [0]!"
    };
    List<String> expectedCollisions = List.of(collisions);

    String[] contents = {
      "[0]: yo! => yo!",
      "[1]: EMPTY",
      "[2]: EMPTY",
      "[3]: the => the",
      "[4]: quick => quick",
      "[5]: wedgied => wedgied",
      "[6]: dog => dog",
      "[7]: blue => blue",
      "[8]: mink => mink",
      "[9]: my => my",
      "[10]: freaking => freaking"
    };
    List<String> expectedContents = List.of(contents);

    assertThat(hashtable.collisionLog()).isEqualTo(expectedCollisions);
    assertThat(hashtable.backingArrayContents()).isEqualTo(expectedContents);
    assertThat(hashtable.replacementLog()).isEqualTo(List.of());
    assertThat(hashtable.size()).isEqualTo(9);
    assertThat(hashtable.loadFactor())
        .isCloseTo((9.0 / MyHashtable.DEFAULT_CAPACITY), within(0.01));
  }

  @Test
  @DisplayName("son_of_lets go boom-boom")
  void son_of_lets_go_boom_boom() {

    MyHashtable<ReallyBadInt, Integer> hashtable = new MyHashtable<>();

    List<Integer> nums = List.of(1, 3, 5, 7, 9, 1, 2, 4, 3);

    for (Integer num : nums) {
      hashtable.put(new ReallyBadInt(num), num);
    }

    String[] collisions = {
      "Yay! 1 found a home at [1]!",
      "Yay! 3 found a home at [3]!",
      "Yay! 5 found a home at [5]!",
      "Yay! 7 found a home at [7]!",
      "Yay! 9 found a home at [9]!",
      "1 collided with 1[1]",
      "Yay! 1 found a home at [2]!",
      "2 collided with 1[2]",
      "2 looking for a home at [3]",
      "Yay! 2 found a home at [4]!",
      "4 collided with 2[4]",
      "4 looking for a home at [5]",
      "Yay! 4 found a home at [6]!",
      "3 collided with 3[3]",
      "3 looking for a home at [4]",
      "3 looking for a home at [5]",
      "3 looking for a home at [6]",
      "3 looking for a home at [7]",
      "Yay! 3 found a home at [8]!"
    };
    List<String> expectedCollisions = List.of(collisions);

    String[] contents = {
      "[0]: EMPTY",
      "[1]: 1 => 1",
      "[2]: 1 => 1",
      "[3]: 3 => 3",
      "[4]: 2 => 2",
      "[5]: 5 => 5",
      "[6]: 4 => 4",
      "[7]: 7 => 7",
      "[8]: 3 => 3",
      "[9]: 9 => 9",
      "[10]: EMPTY"
    };
    List<String> expectedContents = List.of(contents);

    assertThat(hashtable.collisionLog()).isEqualTo(expectedCollisions);
    assertThat(hashtable.backingArrayContents()).isEqualTo(expectedContents);
    assertThat(hashtable.replacementLog()).isEqualTo(List.of());
    assertThat(hashtable.loadFactor())
        .isCloseTo((9.0 / MyHashtable.DEFAULT_CAPACITY), within(0.01));
  }

  static class ReallyBadInt {
    private int i;

    public ReallyBadInt(int i) {
      this.i = i;
    }

    @Override
    public String toString() {
      return "" + i;
    }

    @Override
    public boolean equals(Object o) {
      return false; // that's right! no equality! madness!
    }

    @Override
    public int hashCode() {
      return i;
    }
  }

  static class ReallyBadString {
    private String s;

    public ReallyBadString(String s) {
      this.s = s;
    }

    @Override
    public String toString() {
      return s;
    }

    @Override
    public boolean equals(Object o) {
      return s.equals(o);
    }

    @Override
    public int hashCode() {
      if (s.length() % 2 == 0) {
        return 7;
      } else {
        return 3;
      }
    }
  }
}
