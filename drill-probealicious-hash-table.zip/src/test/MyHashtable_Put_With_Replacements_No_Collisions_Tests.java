package test;

import static org.assertj.core.api.Assertions.*;

import java.util.List;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import main.MyHashtable;

@DisplayName("MyHashtable Put With Replacements No Collisions Tests")
public class MyHashtable_Put_With_Replacements_No_Collisions_Tests {

  @Test
  @DisplayName("let's replace the stuffs")
  void let_s_replace_the_stuffs() {

    MyHashtable<WonkyInt, Integer> hashtable = new MyHashtable<>();

    List<Integer> nums = List.of(1, 3, 5, 7, 9, 1, 1, 9, 9);

    for (Integer num : nums) {
      hashtable.put(new WonkyInt(num), num);
    }

    String[] contents = {
      "[0]: EMPTY",
      "[1]: 1 => 1",
      "[2]: EMPTY",
      "[3]: 3 => 3",
      "[4]: EMPTY",
      "[5]: 5 => 5",
      "[6]: EMPTY",
      "[7]: 7 => 7",
      "[8]: EMPTY",
      "[9]: 9 => 9",
      "[10]: EMPTY"
    };
    List<String> expectedContents = List.of(contents);

    String[] replacements = {
      "replacing 1[1] with 1",
      "replacing 1[1] with 1",
      "replacing 9[9] with 9",
      "replacing 9[9] with 9"
    };
    List<String> expectedReplacements = List.of(replacements);

    assertThat(hashtable.backingArrayContents()).isEqualTo(expectedContents);
    assertThat(hashtable.replacementLog()).isEqualTo(expectedReplacements);
    assertThat(hashtable.size()).isEqualTo(5);
    assertThat(hashtable.loadFactor()).isCloseTo(5.0 / MyHashtable.DEFAULT_CAPACITY, within(0.01));
  }

  private static class WonkyInt {
    private int i;

    public WonkyInt(int i) {
      this.i = i;
    }

    @Override
    public String toString() {
      return "" + i;
    }

    @Override
    public int hashCode() {
      return i;
    }

    @Override
    public boolean equals(Object obj) {
      if (this == obj) {
        return true;
      }
      if (obj == null) {
        return false;
      }
      if (getClass() != obj.getClass()) {
        return false;
      }
      WonkyInt other = (WonkyInt) obj;
      return i == other.i;
    }
  }
}
