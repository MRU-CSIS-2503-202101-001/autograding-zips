package test;

import static org.assertj.core.api.Assertions.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import main.MyHashtable;

@DisplayName("MyHashtable Put And Contains Tests")
public class MyHashtable_Put_And_Contains_Tests {

  @Test
  @DisplayName("if you don't put something into the table, the table doesn't contain it")
  void if_you_dont_put_something_into_the_table_the_table_doesnt_contain_it() {
    int someCapacity = 3;
    String someString = "arglebargle";

    MyHashtable<String, String> hashtable = new MyHashtable<>(someCapacity);

    assertThat(hashtable.contains(someString)).isFalse();
  }

  @Test
  @DisplayName("if you put something into the table, the table should contain it")
  void if_you_put_something_into_the_table_the_table_should_contain_it() {
    String someString = "arglebargle";
    MyHashtable<String, String> hashtable = new MyHashtable<>();

    hashtable.put(someString, someString);

    assertThat(hashtable.contains(someString)).isTrue();
  }

  @Test
  @DisplayName(
      "if you put something into the table, then put the same thing again, the table should still contain it")
  void
      if_you_put_something_into_the_table_then_put_the_same_thing_again_the_table_should_still_contain_it() {
    String someString = "wortwortwort";
    MyHashtable<String, String> hashtable = new MyHashtable<>();

    hashtable.put(someString, someString);
    hashtable.put(someString, someString);

    assertThat(hashtable.contains(someString)).isTrue();
  }
}
