package test;

import static org.assertj.core.api.Assertions.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import main.MyHashtable;

@DisplayName("MyHashtable Putting and Removing Tests")
public class MyHashtable_Putting_And_Removing_Tests {

  @Test
  @DisplayName("a removed spot should be used for insertion")
  void a_removed_spot_should_be_used_for_insertion_one_case() {
    int someCapacity = 2;
    MyHashtable<Integer, String> hashtable = new MyHashtable<>(someCapacity);

    hashtable.put(0, "zero");
    hashtable.put(1, "one");

    String[] contentsBeforeRemove = {"[0][[0:zero]]", "[1][[1:one]]"};
    List<String> expectedContents = List.of(contentsBeforeRemove);

    assertThat(hashtable.backingArrayContents()).isEqualTo(expectedContents);

    hashtable.remove(0);

    String[] contentsAfterRemove = {"[0][[DELETED]]", "[1][[1:one]]"};
    expectedContents = List.of(contentsAfterRemove);

    assertThat(hashtable.backingArrayContents()).isEqualTo(expectedContents);

    hashtable.put(0, "zero");

    String[] contentsAfterPut = {"[0][[0:zero]]", "[1][[1:one]]"};
    expectedContents = List.of(contentsAfterPut);

    assertThat(hashtable.backingArrayContents()).isEqualTo(expectedContents);
  }
}
