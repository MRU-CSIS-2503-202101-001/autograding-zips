package test;

import static org.assertj.core.api.Assertions.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import main.MyHashtable;

@DisplayName("MyHashtable Put Return Value Tests")
public class MyHashtable_Put_Return_Value_Tests {

  @Test
  @DisplayName("putting when that key doesn't currently exist returns null")
  void putting_when_that_key_doesn_t_currently_exist_returns_null() {

    MyHashtable<Integer, String> hashtable = new MyHashtable<>();

    List<Integer> nums = List.of(15, 3, 0);

    List<String> putResults = new ArrayList<>();

    for (Integer num : nums) {
      String putResult = hashtable.put(Integer.valueOf(num), Integer.toHexString(num));
      putResults.add(putResult);
    }

    assertThat(putResults).containsExactly(null, null, null);
    assertThat(hashtable.isEmpty()).isFalse();
    assertThat(hashtable.isFull()).isFalse();
    assertThat(hashtable.size()).isEqualTo(3);
    assertThat(hashtable.loadFactor())
        .isCloseTo((3.0 / MyHashtable.DEFAULT_CAPACITY), within(0.01));
  }

  @Test
  @DisplayName("putting when that key currently exists returns the previous value")
  void putting_when_that_key_currently_exists_returns_the_previous_value() {

    MyHashtable<Integer, String> hashtable = new MyHashtable<>();

    List<Integer> nums = List.of(8, 10, 2);

    List<String> putResults = new ArrayList<>();

    for (Integer num : nums) {
      hashtable.put(Integer.valueOf(num), Integer.toHexString(num));
    }

    String putResult = hashtable.put(Integer.valueOf(10), "woot!");
    putResults.add(putResult);

    putResult = hashtable.put(Integer.valueOf(8), "8");
    putResults.add(putResult);

    putResult = hashtable.put(Integer.valueOf(2), Integer.toHexString(2));
    putResults.add(putResult);

    putResult = hashtable.put(Integer.valueOf(10), "again?!?");
    putResults.add(putResult);

    assertThat(putResults).containsExactly("a", "8", "2", "woot!");
    assertThat(hashtable.isEmpty()).isFalse();
    assertThat(hashtable.isFull()).isFalse();
    assertThat(hashtable.size()).isEqualTo(3);
    assertThat(hashtable.loadFactor())
        .isCloseTo((3.0 / MyHashtable.DEFAULT_CAPACITY), within(0.01));
  }
}
