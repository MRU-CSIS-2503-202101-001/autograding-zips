package test;

import static org.assertj.core.api.Assertions.*;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import main.MyHashtable;

@DisplayName("MyHashtable Remove And Contains Tests")
public class MyHashtable_Remove_And_Contains_Tests {

  @Test
  @DisplayName("if you remove something from the table, the table no longer contains it")
  void if_you_remove_something_from_the_table_the_table_no_longer_contains_it() {
    int someCapacity = 15;
    String someString = "arglebargle";
    int someNumber = 5;

    MyHashtable<String, Integer> hashtable = new MyHashtable<>(someCapacity);

    hashtable.put(someString, someNumber);

    assertThat(hashtable.size()).isEqualTo(1);
    assertThat(hashtable.isEmpty()).isFalse();
    assertThat(hashtable.contains(someString)).isTrue();
    assertThat(hashtable.get(someString)).isEqualTo(someNumber);

    hashtable.remove(someString);

    assertThat(hashtable.size()).isZero();
    assertThat(hashtable.isEmpty()).isTrue();
    assertThat(hashtable.get(someString)).isNull();
    assertThat(hashtable.contains(someString)).isFalse();
  }
}
