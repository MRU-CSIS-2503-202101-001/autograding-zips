package test;

import static org.assertj.core.api.Assertions.*;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import main.TwoEndedSll;

@DisplayName("TwoEndedSLL Add Tests")
public class TwoEndedSLL_Add_Head_Tests {

  @Test
  @DisplayName("adding to an empty TESLL at the head gives you one with that thing in it")
  void dding_to_an_empty_TESLL_at_the_head_gives_you_one_with_that_thing_in_it() {

    TwoEndedSll<String> list = new TwoEndedSll<>();

    list.addHead("woot");

    assertThat(list.size()).isEqualTo(1);
    assertThat(list.isEmpty()).isFalse();
    assertThat(list.toString()).isEqualTo("H->[woot]<-T");
    assertThat(list.contents()).containsExactly("woot");
  }

  @Test
  @DisplayName(
      "adding to a non-empty TESLL at the head gives you one that's got the new thing in it at the head")
  void
      adding_to_a_non_empty_TESLL_at_the_head_gives_you_one_thats_got_the_new_thing_in_it_at_the_head() {

    TwoEndedSll<String> list = new TwoEndedSll<>();

    list.addHead("woot");

    list.addHead("fizz");
    assertThat(list.size()).isEqualTo(2);
    assertThat(list.isEmpty()).isFalse();
    assertThat(list.toString()).isEqualTo("H->[fizz, woot]<-T");
    assertThat(list.contents()).containsExactly("fizz", "woot");

    list.addHead("blarg");
    assertThat(list.size()).isEqualTo(3);
    assertThat(list.isEmpty()).isFalse();
    assertThat(list.toString()).isEqualTo("H->[blarg, fizz, woot]<-T");
    assertThat(list.contents()).containsExactly("blarg", "fizz", "woot");
  }
}
