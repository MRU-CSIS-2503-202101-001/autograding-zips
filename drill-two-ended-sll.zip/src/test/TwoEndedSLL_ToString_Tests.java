package test;

import static org.assertj.core.api.Assertions.*;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import main.TwoEndedSll;

@DisplayName("TwoEndedSLL toString Tests")
public class TwoEndedSLL_ToString_Tests {

  private static final Blorble B1 = new Blorble(1);
  private static final Blorble B2 = new Blorble(2);
  private static final Blorble B3 = new Blorble(3);

  @Test
  @DisplayName("an empty list")
  void an_empty_list() {

    TwoEndedSll<Blorble> list = new TwoEndedSll<>();

    assertThat(list.toString()).isEqualTo("H->[]<-T");
  }

  @Test
  @DisplayName("a one-element list")
  void a_one_element_list() {

    TwoEndedSll<Blorble> list = new TwoEndedSll<>();

    list.addHead(B2);

    assertThat(list.toString()).isEqualTo("H->[b2]<-T");
  }

  @Test
  @DisplayName("a two-element list")
  void a_two_element_list() {

    TwoEndedSll<Blorble> list = new TwoEndedSll<>();

    list.addHead(B2);
    list.addHead(B1);

    assertThat(list.toString()).isEqualTo("H->[b1, b2]<-T");
  }

  @Test
  @DisplayName("a three-element list")
  void a_three_element_list() {

    TwoEndedSll<Blorble> list = new TwoEndedSll<>();

    list.addHead(B2);
    list.addHead(B1);
    list.addTail(B3);

    assertThat(list.toString()).isEqualTo("H->[b1, b2, b3]<-T");
  }
}

class Blorble {
  private int num;

  public Blorble(int num) {
    this.num = num;
  }

  @Override
  public String toString() {
    return "b" + num;
  }
}
