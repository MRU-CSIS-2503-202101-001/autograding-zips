package test;

import static com.github.stefanbirkner.systemlambda.SystemLambda.*;
import static org.assertj.core.api.Assertions.assertThat;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import main.Main;

public class MainTests {

  private List<String> clean(String rawConsoleOutput) {
    String[] split = rawConsoleOutput.split("\n");
    return Arrays.stream(split)
        .filter(s -> !s.isEmpty())
        .map(String::trim)
        .collect(Collectors.toList());
  }

  @Test
  @DisplayName("empty list case")
  void run_two_ends_right_away() throws Exception {

    withTextFromSystemIn("")
        .execute(
            () -> {
              List<String> expectedOutputParts =
                  List.of(
                      "Hi! I'm the Two-Ended List app!",
                      "Every word you enter on a line will be added to me in alternating head/tail order.",
                      "I will turn each word to lowercase before it is added.",
                      "I will show you my contents after every word.",
                      "I will stop when you enter an empty line.",
                      "Ready? Start entering words!",
                      "> Done now! Thanks!");

              String rawConsoleOutput =
                  tapSystemOutNormalized(() -> Main.main(new String[0])).trim();
              List<String> cleanedOutput = clean(rawConsoleOutput);

              assertThat(cleanedOutput).isEqualTo(expectedOutputParts);
            });
  }

  @Test
  @DisplayName("1 word list case")
  void run_one() throws Exception {

    withTextFromSystemIn("omAe", "")
        .execute(
            () -> {
              List<String> expectedOutputParts =
                  List.of(
                      "Hi! I'm the Two-Ended List app!",
                      "Every word you enter on a line will be added to me in alternating head/tail order.",
                      "I will turn each word to lowercase before it is added.",
                      "I will show you my contents after every word.",
                      "I will stop when you enter an empty line.",
                      "Ready? Start entering words!",
                      "> contents: [omae]",
                      "> Done now! Thanks!");

              String rawConsoleOutput =
                  tapSystemOutNormalized(() -> Main.main(new String[0])).trim();
              List<String> cleanedOutput = clean(rawConsoleOutput);

              assertThat(cleanedOutput).isEqualTo(expectedOutputParts);
            });
  }

  @Test
  @DisplayName("multiple word list case")
  void fill_that_sucker_up() throws Exception {

    withTextFromSystemIn("BIPPITY", "boPPiTTY", "BOOM", "baby!", "")
        .execute(
            () -> {
              List<String> expectedOutputParts =
                  List.of(
                      "Hi! I'm the Two-Ended List app!",
                      "Every word you enter on a line will be added to me in alternating head/tail order.",
                      "I will turn each word to lowercase before it is added.",
                      "I will show you my contents after every word.",
                      "I will stop when you enter an empty line.",
                      "Ready? Start entering words!",
                      "> contents: [bippity]",
                      "> contents: [bippity, boppitty]",
                      "> contents: [boom, bippity, boppitty]",
                      "> contents: [boom, bippity, boppitty, baby!]",
                      "> Done now! Thanks!");

              String rawConsoleOutput =
                  tapSystemOutNormalized(() -> Main.main(new String[0])).trim();
              List<String> cleanedOutput = clean(rawConsoleOutput);

              assertThat(cleanedOutput).isEqualTo(expectedOutputParts);
            });
  }
}
