package test;

import static org.assertj.core.api.Assertions.*;

import java.util.List;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import main.TwoEndedSll;

@DisplayName("TwoEndedSLL Remove From Head Non-Empty Tests")
public class TwoEndedSLL_Remove_From_Head_Non_Empty_Tests {

  private static final Kitty TEDDY = new Kitty("Teddy");
  private static final Kitty RUFUS = new Kitty("Rufus");
  private static final Kitty LITA = new Kitty("Lita");

  @Test
  @DisplayName(
      "when you remove the not-last thing from the head, you get that thing and the list is now 1 smaller")
  void
      when_you_remove_the_not_last_thing_from_the_head_you_get_that_thing_and_the_list_is_now_1_smaller() {

    TwoEndedSll<Kitty> list = new TwoEndedSll<>();

    list.addTail(TEDDY);
    list.addTail(RUFUS);
    list.addTail(LITA);

    Kitty removed = list.removeHead();

    assertThat(removed).isEqualTo(TEDDY);
    assertThat(list.size()).isEqualTo(2);
    assertThat(list.isEmpty()).isFalse();
  }

  @Test
  @DisplayName(
      "as you remove not-last things from the head, the list has its previous contents minus the removed one")
  void
      as_you_remove_not_last_things_from_the_head_the_list_has_its_previous_contents_minus_the_removed_one() {

    TwoEndedSll<Kitty> list = new TwoEndedSll<>();

    list.addTail(TEDDY);
    list.addTail(RUFUS);
    list.addTail(LITA);

    List<Kitty> remaining = list.contents();
    assertThat(list.toString()).isEqualTo("H->[Teddy, Rufus, Lita]<-T");
    assertThat(remaining).containsExactly(TEDDY, RUFUS, LITA);

    list.removeHead();
    remaining = list.contents();
    assertThat(list.toString()).isEqualTo("H->[Rufus, Lita]<-T");
    assertThat(remaining).containsExactly(RUFUS, LITA);

    list.removeHead();
    remaining = list.contents();
    assertThat(list.toString()).isEqualTo("H->[Lita]<-T");
    assertThat(remaining).containsExactly(LITA);
  }

  @Test
  @DisplayName(
      "when you remove the last thing from the head, you get that thing and the list is now empty")
  void when_you_remove_the_last_thing_from_the_head_you_get_that_thing_and_the_list_is_now_empty() {

    TwoEndedSll<Kitty> list = new TwoEndedSll<>();

    list.addTail(TEDDY);

    Kitty removed = list.removeHead();

    assertThat(removed).isEqualTo(TEDDY);
    assertThat(list.size()).isZero();
    assertThat(list.isEmpty()).isTrue();
  }

  @Test
  @DisplayName("when you remove the last thing from the head, the list has no contents")
  void when_you_remove_the_last_thing_from_the_head_the_list_has_no_contents() {

    TwoEndedSll<Kitty> list = new TwoEndedSll<>();

    list.addTail(TEDDY);
    list.addTail(RUFUS);
    list.addTail(LITA);

    list.removeHead();
    list.removeHead();
    list.removeHead();

    List<Kitty> remaining = list.contents();

    assertThat(list.toString()).isEqualTo("H->[]<-T");
    assertThat(remaining).isEmpty();
  }
}

class Kitty {
  String name;

  public Kitty(String name) {
    this.name = name;
  }

  @Override
  public String toString() {
    return name;
  }
}
