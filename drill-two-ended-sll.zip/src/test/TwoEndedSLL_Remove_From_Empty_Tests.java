package test;

import static org.assertj.core.api.Assertions.*;

import java.util.NoSuchElementException;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import main.TwoEndedSll;

@DisplayName("TwoEndedSLL Remove From Empty Tests")
public class TwoEndedSLL_Remove_From_Empty_Tests {

  @Test
  @DisplayName(
      "attempting to remove something at the head from an empty OESLL throws a NoSuchElementException")
  void
      attempting_to_remove_something_at_the_head_from_an_empty_OESLL_throws_a_NoSuchElementException() {

    TwoEndedSll<String> list = new TwoEndedSll<>();

    assertThatExceptionOfType(NoSuchElementException.class)
        .isThrownBy(() -> list.removeHead())
        .withMessage("No element to remove - the list is empty.");
  }

  @Test
  @DisplayName(
      "when you remove the last thing from the head, and then do it again, you get a NoSuchElementException")
  void
      when_you_remove_the_last_thing_from_the_head_and_then_do_it_again_you_get_a_NoSuchElementException() {

    TwoEndedSll<Integer> list = new TwoEndedSll<>();

    list.addHead(43);

    list.removeHead(); // OK here...

    assertThatExceptionOfType(NoSuchElementException.class)
        .isThrownBy(() -> list.removeHead()) // ...but not here!
        .withMessage("No element to remove - the list is empty.");
  }

  @Test
  @DisplayName(
      "attempting to remove something at the tail from an empty OESLL throws a NoSuchElementException")
  void
      attempting_to_remove_something_at_the_tail_from_an_empty_OESLL_throws_a_NoSuchElementException() {

    TwoEndedSll<String> list = new TwoEndedSll<>();

    assertThatExceptionOfType(NoSuchElementException.class)
        .isThrownBy(() -> list.removeTail())
        .withMessage("No element to remove - the list is empty.");
  }

  @Test
  @DisplayName(
      "when you remove the last thing from the tail, and then do it again, you get a NoSuchElementException")
  void
      when_you_remove_the_last_thing_from_the_tail_and_then_do_it_again_you_get_a_NoSuchElementException() {

    TwoEndedSll<Integer> list = new TwoEndedSll<>();

    list.addTail(43);

    list.removeTail(); // OK here...

    assertThatExceptionOfType(NoSuchElementException.class)
        .isThrownBy(() -> list.removeTail()) // ...but not here!
        .withMessage("No element to remove - the list is empty.");
  }
}
