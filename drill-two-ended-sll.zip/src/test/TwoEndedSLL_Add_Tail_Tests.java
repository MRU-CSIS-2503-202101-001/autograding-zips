package test;

import static org.assertj.core.api.Assertions.*;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import main.TwoEndedSll;

@DisplayName("TwoEndedSLL Add Tail Tests")
public class TwoEndedSLL_Add_Tail_Tests {

  @Test
  @DisplayName("adding to an empty TESLL at the tail gives you one with that thing in it")
  void dding_to_an_empty_TESLL_at_the_tail_gives_you_one_with_that_thing_in_it() {

    TwoEndedSll<String> list = new TwoEndedSll<>();

    list.addTail("woot");

    assertThat(list.size()).isEqualTo(1);
    assertThat(list.isEmpty()).isFalse();
    assertThat(list.toString()).isEqualTo("H->[woot]<-T");
    assertThat(list.contents()).containsExactly("woot");
  }

  @Test
  @DisplayName(
      "adding to a non-empty TESLL at the tail gives you one that's got the new thing in it at the tail")
  void
      adding_to_a_non_empty_TESLL_at_the_tail_gives_you_one_thats_got_the_new_thing_in_it_at_the_tail() {

    TwoEndedSll<String> list = new TwoEndedSll<>();

    list.addTail("woot");
    list.addTail("fizz");

    assertThat(list.size()).isEqualTo(2);
    assertThat(list.isEmpty()).isFalse();
    assertThat(list.toString()).isEqualTo("H->[woot, fizz]<-T");
    assertThat(list.contents()).containsExactly("woot", "fizz");

    list.addTail("blarg");
    assertThat(list.size()).isEqualTo(3);
    assertThat(list.isEmpty()).isFalse();
    assertThat(list.toString()).isEqualTo("H->[woot, fizz, blarg]<-T");
    assertThat(list.contents()).containsExactly("woot", "fizz", "blarg");
  }
}
