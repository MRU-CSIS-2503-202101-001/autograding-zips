package test;

import static org.assertj.core.api.Assertions.*;

import java.util.List;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import main.TwoEndedSll;

@DisplayName("TwoEndedSLL Remove From Tail Non-Empty Tests")
public class TwoEndedSLL_Remove_From_Tail_Non_Empty_Tests {

  private static final Puppy TEDDY = new Puppy("Teddy");
  private static final Puppy RUFUS = new Puppy("Rufus");
  private static final Puppy LITA = new Puppy("Lita");

  @Test
  @DisplayName(
      "when you remove the not-last thing from the tail, you get that thing and the list is now 1 smaller")
  void
      when_you_remove_the_not_last_thing_from_the_tail_you_get_that_thing_and_the_list_is_now_1_smaller() {

    TwoEndedSll<Puppy> list = new TwoEndedSll<>();

    list.addTail(TEDDY);
    list.addTail(RUFUS);
    list.addTail(LITA);

    Puppy removed = list.removeTail();

    assertThat(removed).isEqualTo(LITA);
    assertThat(list.size()).isEqualTo(2);
    assertThat(list.isEmpty()).isFalse();
  }

  @Test
  @DisplayName(
      "as you remove not-last things from the tail, the list has its previous contents minus the removed one")
  void
      as_you_remove_not_last_things_from_the_tail_the_list_has_its_previous_contents_minus_the_removed_one() {

    TwoEndedSll<Puppy> list = new TwoEndedSll<>();

    list.addTail(TEDDY);
    list.addTail(RUFUS);
    list.addTail(LITA);

    List<Puppy> remaining = list.contents();
    assertThat(list.toString()).isEqualTo("H->[Teddy, Rufus, Lita]<-T");
    assertThat(remaining).containsExactly(TEDDY, RUFUS, LITA);

    list.removeTail();
    remaining = list.contents();
    assertThat(list.toString()).isEqualTo("H->[Teddy, Rufus]<-T");
    assertThat(remaining).containsExactly(TEDDY, RUFUS);

    list.removeTail();
    remaining = list.contents();
    assertThat(list.toString()).isEqualTo("H->[Teddy]<-T");
    assertThat(remaining).containsExactly(TEDDY);
  }

  @Test
  @DisplayName(
      "when you remove the last thing from the tail, you get that thing and the list is now empty")
  void when_you_remove_the_last_thing_from_the_tail_you_get_that_thing_and_the_list_is_now_empty() {

    TwoEndedSll<Puppy> list = new TwoEndedSll<>();

    list.addTail(TEDDY);

    Puppy removed = list.removeTail();

    assertThat(removed).isEqualTo(TEDDY);
    assertThat(list.size()).isZero();
    assertThat(list.isEmpty()).isTrue();
  }

  @Test
  @DisplayName("when you remove the last thing from the Tail, the list has no contents")
  void when_you_remove_the_last_thing_from_the_tail_the_list_has_no_contents() {

    TwoEndedSll<Puppy> list = new TwoEndedSll<>();

    list.addTail(TEDDY);
    list.addTail(RUFUS);
    list.addTail(LITA);

    list.removeTail();
    list.removeTail();
    list.removeTail();

    List<Puppy> remaining = list.contents();

    assertThat(list.toString()).isEqualTo("H->[]<-T");
    assertThat(remaining).isEmpty();
  }
}

class Puppy {
  String name;

  public Puppy(String name) {
    this.name = name;
  }

  @Override
  public String toString() {
    return name;
  }
}
