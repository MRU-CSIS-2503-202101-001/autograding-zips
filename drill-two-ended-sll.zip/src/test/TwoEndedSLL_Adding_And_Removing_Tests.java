package test;

import static org.assertj.core.api.Assertions.*;

import java.util.ArrayList;
import java.util.List;
import java.util.NoSuchElementException;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import main.TwoEndedSll;

@DisplayName("TwoEndedSLL Adding and Removing Tests")
public class TwoEndedSLL_Adding_And_Removing_Tests {

  @Test
  @DisplayName("add head -> remove tail")
  void add_head_remove_tail() {

    TwoEndedSll<Integer> list = new TwoEndedSll<>();

    list.addHead(17);
    int removed = list.removeTail();

    assertThat(removed).isEqualTo(17);
    assertThat(list.size()).isEqualTo(0);
    assertThat(list.isEmpty()).isTrue();
    assertThat(list.toString()).isEqualTo("H->[]<-T");
    assertThat(list.contents()).isEmpty();
  }

  @Test
  @DisplayName("add tail -> remove head")
  void add_tail_remove_head() {

    TwoEndedSll<Integer> list = new TwoEndedSll<>();

    list.addTail(55);
    int removed = list.removeHead();

    assertThat(removed).isEqualTo(55);
    assertThat(list.size()).isEqualTo(0);
    assertThat(list.isEmpty()).isTrue();
    assertThat(list.toString()).isEqualTo("H->[]<-T");
    assertThat(list.contents()).isEmpty();
  }

  @Test
  @DisplayName("add tail -> add head -> add tail")
  void add_tail_add_head_add_tail() {

    TwoEndedSll<Integer> list = new TwoEndedSll<>();

    list.addTail(55);
    list.addHead(11);
    list.addTail(100);

    assertThat(list.size()).isEqualTo(3);
    assertThat(list.isEmpty()).isFalse();
    assertThat(list.toString()).isEqualTo("H->[11, 55, 100]<-T");
    assertThat(list.contents()).containsExactly(11, 55, 100);
  }

  @Test
  @DisplayName("add head -> add tail -> add head")
  void add_head_add_tail_add_head() {

    TwoEndedSll<Integer> list = new TwoEndedSll<>();

    list.addHead(55);
    list.addTail(11);
    list.addHead(100);

    assertThat(list.size()).isEqualTo(3);
    assertThat(list.isEmpty()).isFalse();
    assertThat(list.toString()).isEqualTo("H->[100, 55, 11]<-T");
    assertThat(list.contents()).containsExactly(100, 55, 11);
  }

  @Test
  @DisplayName("and a hot mess because JP's tired")
  void and_a_hot_mess_because_JPs_tired() {

    TwoEndedSll<Integer> list = new TwoEndedSll<>();

    list.addHead(4);
    list.addTail(5);
    list.addHead(9);
    list.addHead(0);
    list.addHead(11);
    list.addTail(59);
    list.addTail(14);
    list.addHead(222);

    assertThat(list.size()).isEqualTo(8);
    assertThat(list.isEmpty()).isFalse();
    assertThat(list.toString()).isEqualTo("H->[222, 11, 0, 9, 4, 5, 59, 14]<-T");
    assertThat(list.contents()).containsExactly(222, 11, 0, 9, 4, 5, 59, 14);

    List<Integer> removals = new ArrayList<>();
    removals.add(list.removeHead());
    removals.add(list.removeTail());
    removals.add(list.removeHead());
    removals.add(list.removeHead());
    removals.add(list.removeTail());
    removals.add(list.removeTail());
    removals.add(list.removeHead());
    removals.add(list.removeHead());

    assertThat(removals.toString()).isEqualTo("[222, 14, 11, 0, 59, 5, 9, 4]");

    assertThat(list.size()).isZero();
    assertThat(list.isEmpty()).isTrue();
    assertThat(list.toString()).isEqualTo("H->[]<-T");
    assertThat(list.contents()).isEmpty();

    assertThatExceptionOfType(NoSuchElementException.class)
        .isThrownBy(() -> list.removeTail()) // ...but not here!
        .withMessage("No element to remove - the list is empty.");

    assertThatExceptionOfType(NoSuchElementException.class)
        .isThrownBy(() -> list.removeHead()) // ...but not here!
        .withMessage("No element to remove - the list is empty.");

    assertThatExceptionOfType(NoSuchElementException.class)
        .isThrownBy(() -> list.removeTail()) // ...but not here!
        .withMessage("No element to remove - the list is empty.");

    assertThatExceptionOfType(NoSuchElementException.class)
        .isThrownBy(() -> list.removeHead()) // ...but not here!
        .withMessage("No element to remove - the list is empty.");
  }
}
