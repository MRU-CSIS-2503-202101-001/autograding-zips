package test;

import static org.assertj.core.api.Assertions.*;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import main.TwoEndedSll;

@DisplayName("TwoEndedSLL Creation Tests")
public class TwoEndedSLL_Creation_Tests {

  @Test
  @DisplayName("a new OESLL is empty")
  void a_new_OESLL_is_empty() {

    TwoEndedSll<String> list = new TwoEndedSll<>();

    assertThat(list.size()).isZero();
    assertThat(list.isEmpty()).isTrue();
    assertThat(list.contents()).isEmpty();
  }
}
