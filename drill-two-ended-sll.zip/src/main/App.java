package main;

public class App {

  public void run() {

    // TODO: code this run so that it works as shown in the example
    //       output in the instructions - and so that all the tests in MainTests pass as well

  }

  private void displayInstructions() {
    System.out.println("Hi! I'm the Two-Ended List app!");
    System.out.println(
        "Every word you enter on a line will be added to me in alternating head/tail order.");
    System.out.println("I will turn each word to lowercase before it is added.");

    System.out.println();

    System.out.println("I will show you my contents after every word.");
    System.out.println("I will stop when you enter an empty line.");

    System.out.println("Ready? Start entering words!");
  }
}
