package main;

public class Main {

  public static void main(String[] args) {

    // TODO: create a Scanner that can do the keyboard input for you

    // TODO: prompt for and get a name

    System.out.println();

    // TODO: prompt for and get an integer age

    System.out.println();

    // TODO: calculate and print out the "If I were half that age..." message
    //       Careful with the number of decimal places...

    System.out.println();

    // TODO: prompt for and get 2 or more words separated by whitespace

    System.out.println();

    // TODO: calculate and print out "The first word that you gave me...." message

  }
}
