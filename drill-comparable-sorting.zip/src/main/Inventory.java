package main;

import java.util.ArrayList;
import java.util.List;

/**
 * Represents the Items carried by a character in a video game.
 *
 * <p>For simplicity, this inventory is implemented using an array of Items of fixed size 10.
 *
 * @author jpratt
 */
public class Inventory {

  private static final int DEFAULT_SIZE = 10;

  private int numItems;
  private Item[] items;

  /**
   * Creates an Inventory that has no items in it.
   *
   * <p>Don't forget to initialize your fields!
   */
  public Inventory() {
    // TODO: complete this constructor
  }

  /**
   * Returns the number of items in this Inventory.
   *
   * @return the number of items in this Inventory
   */
  // TODO: create a numItems method

  /**
   * Add an item to this Inventory.
   *
   * <p>Assumption: if adding the item would overfill the inventory, the item is NOT added, but no
   * indication of failure is given.
   *
   * @param item the item to add to this Inventory
   */
  // TODO: create an add method

  /**
   * Adds a number of items to this Inventory.
   *
   * <p>Assumption: any attempt to overfill the inventory will fail silently.
   *
   * @param items the items to add to this Inventory
   */
  // TODO: create an addAll method
  // hint: if you've done add(), then this method is easy-peasy

  /**
   * Return a list of all the Items in this Inventory in the order they appear in the backing array.
   *
   * <p>Any nulls in the array are not included.
   *
   * @return a list of all non-null Items in this Inventory in order of array appearance
   */
  // TODO: create a get method
  //
  // hint: there are some nice ways to copy an array - or part of an array - in the Arrays
  // library. Look into copyOf.
  //
  // hint: you can use List.of to make a list from an array

  /**
   * Return a list of all the Items in this Inventory in their natural order.
   *
   * <p>Any nulls in the array are not included.
   *
   * @return a list of all non-null Items in this Inventory in natural order
   */
  public List<Item> getSorted() {

    ArrayList<Item> result = new ArrayList<>(get());

    // TODO: complete getSorted
    // hint: you can use Collections.sort to sort the result and return it

  }
}
