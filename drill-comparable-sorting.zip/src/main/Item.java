package main;

import java.time.LocalDateTime;

/**
 * Represents something you can pick up and carry around with you in a game.
 *
 * <p>We'll consider two Items equal if all their fields are equal.
 *
 * <p>The natural ordering of Items should be descending value; that is, more valuable items come
 * before less valuable one.
 *
 * @author jpratt
 */
public final class Item {

  private static final double DEFAULT_POTION_WEIGHT = 0.25;

  private enum ItemType {
    WEAPON,
    FOOD,
    POTION
  }

  private String name;
  private LocalDateTime pickedUp;
  private int value;
  private double weight;
  private int durability;
  private ItemType itemType;

  /**
   * Copy constructor for Items.
   *
   * @param other the Item being copied
   */
  public Item(Item other) {
    // TODO: complete this copy constructor

  }

  /**
   * Simple factory for weapon Items.
   *
   * @param name the name of this weapon
   * @param value the value of this weapon
   * @param weight the weight of this weapon
   * @param durability the durability of this weapon
   * @return the Item (which is a weapon)
   */
  public static Item createWeapon(String name, int value, double weight, int durability) {
    Item item = new Item();
    item.name = name;
    item.pickedUp = LocalDateTime.now();
    item.value = value;
    item.weight = weight;
    item.durability = durability;
    item.itemType = ItemType.WEAPON;

    return item;
  }

  /**
   * Simple factory for food Items.
   *
   * <p>It's assumed that food has a durability of 0.
   *
   * @param name the name of this food
   * @param value the value of this food
   * @param weight the weight of this food
   * @return the Item (which is a food)
   */
  public static Item createFood(String name, int value, double weight) {
    Item item = new Item();
    item.name = name;
    item.pickedUp = LocalDateTime.now();
    item.value = value;
    item.weight = weight;
    item.durability = 0;
    item.itemType = ItemType.FOOD;

    return item;
  }

  /**
   * Simple factory for potion Items.
   *
   * <p>It's assumed that potions have a default weight and durability.
   *
   * @param name the name of this potion
   * @param value the value of this potion
   * @return the Item (which is a potion)
   */
  public static Item createPotion(String name, int value) {
    Item item = new Item();
    item.name = name;
    item.pickedUp = LocalDateTime.now();
    item.value = value;
    item.weight = DEFAULT_POTION_WEIGHT;
    item.durability = 1;
    item.itemType = ItemType.POTION;

    return item;
  }

  /** We only want to create Items using the "createBlah" methods. */
  private Item() {}

  public String getName() {
    return name;
  }

  public LocalDateTime getPickedUp() {
    return pickedUp;
  }

  public int getValue() {
    return value;
  }

  public double getWeight() {
    return weight;
  }

  public int getDurability() {
    return durability;
  }

  public boolean isWeapon() {
    return itemType == ItemType.WEAPON;
  }

  public boolean isFood() {
    return itemType == ItemType.FOOD;
  }

  public boolean isPotion() {
    return itemType == ItemType.POTION;
  }

  @Override
  public String toString() {
    return String.format("%s(value:%d)", name, value);
  }
}
