package main;

public class Fighter implements Comparable<Fighter> {
  @Override
  public int compareTo(Fighter o) {
    return 0;
  }
}
