package main;

public class PrintJob implements Comparable<PrintJob> {

  @Override
  public int compareTo(PrintJob o) {
    return 0;
  }
}
