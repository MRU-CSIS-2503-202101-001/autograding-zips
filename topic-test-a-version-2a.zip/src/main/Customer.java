package main;

/**
 * Represents a Customer at a coffee shop.
 *
 * @author jpratt
 */
public class Customer {

  private String customerName;
  private int recognitionRating;
  private int drinkDifficultyRating;

  /**
   * Creates a Customer with a given name, recognition rating, and difficulty level of drink
   * creation.
   *
   * @param customerName name of this Customer
   * @param recognitionRating how well this customer is known by staff
   * @param drinkDifficultyRating how hard it is to make the drink for this customer
   */
  public Customer(String customerName, int recognitionRating, int drinkDifficultyRating) {
    this.customerName = customerName;
    this.recognitionRating = recognitionRating;
    this.drinkDifficultyRating = drinkDifficultyRating;
  }

  public String getCustomerName() {
    return customerName;
  }

  public int getRecognitionRating() {
    return recognitionRating;
  }

  public int getDrinkDifficultyRating() {
    return drinkDifficultyRating;
  }

  /**
   * Returns a "[name] (who is [recognition description]" kinda String.
   *
   * @return a String in the above format
   */
  @Override
  public String toString() {
    return String.format("%s (who is %s)", customerName, recognitionAsText(recognitionRating));
  }

  private String recognitionAsText(int rating) {
    final int newFaceCutoff = 0;
    final int familiarCutoff = 2;
    final int sometimesCutoff = 1;

    if (rating <= newFaceCutoff) {
      return "a new face";
    } else if (rating <= sometimesCutoff) {
      return "seen every now and then";
    } else if (rating <= familiarCutoff) {
      return "really familiar";
    } else {
      return "a regular";
    }
  }
}
