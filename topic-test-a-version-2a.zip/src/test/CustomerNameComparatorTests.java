package test;

import java.util.Comparator;

import static org.assertj.core.api.Assertions.*;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import main.Customer;
import main.CustomerNameComparator;

public class CustomerNameComparatorTests {

  @Test
  @DisplayName("same customer name and drink difficulty returns 0")
  void same_customer_name_and_drink_difficulty_returns_0() {
    Customer customerOne = new Customer("A", 4, 1);
    Customer customerTwo = new Customer("A", 1, 1);

    Comparator<Customer> customerNameComparator = new CustomerNameComparator();

    int compareResult = customerNameComparator.compare(customerOne, customerTwo);
    assertThat(compareResult).isEqualTo(0);

    compareResult = customerNameComparator.compare(customerTwo, customerOne);
    assertThat(compareResult).isEqualTo(0);
  }

  @Test
  @DisplayName("same customer name, case insensitive, and same drink difficulty returns 0")
  void same_customer_name_case_insensitive_and_same_drink_difficulty_returns_0() {
    Customer customerOne = new Customer("A", 4, 3);
    Customer customerTwo = new Customer("a", 2, 3);

    Comparator<Customer> customerNameComparator = new CustomerNameComparator();

    int compareResult = customerNameComparator.compare(customerOne, customerTwo);
    assertThat(compareResult).isEqualTo(0);

    compareResult = customerNameComparator.compare(customerTwo, customerOne);
    assertThat(compareResult).isEqualTo(0);
  }

  @Test
  @DisplayName(
      "same customer name, case insensitive, different drink difficulty orders ascending by difficulty")
  void
      same_customer_name_case_insensitive_different_drink_difficulty_orders_ascending_by_difficulty() {
    Customer customerOne = new Customer("r", 2, 5);
    Customer customerTwo = new Customer("R", 1, 2);

    Comparator<Customer> customerNameComparator = new CustomerNameComparator();

    int compareResult = customerNameComparator.compare(customerOne, customerTwo);
    assertThat(compareResult).isGreaterThan(0);

    compareResult = customerNameComparator.compare(customerTwo, customerOne);
    assertThat(compareResult).isLessThan(0);
  }

  @Test
  @DisplayName("customer recognition doesn't have effect")
  void customer_recognition_doesnt_have_effect() {
    Customer customerOne = new Customer("A", 100, 12);
    Customer customerTwo = new Customer("B", 0, 12);

    Comparator<Customer> customerNameComparator = new CustomerNameComparator();

    int compareResult = customerNameComparator.compare(customerOne, customerTwo);
    assertThat(compareResult).isLessThan(0);

    compareResult = customerNameComparator.compare(customerTwo, customerOne);
    assertThat(compareResult).isGreaterThan(0);
  }
}
