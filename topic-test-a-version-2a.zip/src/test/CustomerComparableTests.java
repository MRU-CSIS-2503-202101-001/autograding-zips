package test;

import java.util.List;
import java.time.LocalDateTime;

import static org.assertj.core.api.Assertions.*;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import org.junit.jupiter.api.Test;

import main.Customer;

class CustomerComparableTests {

  @Test
  @DisplayName("same customer recognition rating returns 0")
  void same_customer_customer_recognition_rating_returns_0() {
    Customer customerOne = new Customer("A", 3, 1);
    Customer customerTwo = new Customer("A", 3, 2);

    int compareToResult = customerOne.compareTo(customerTwo);
    assertThat(compareToResult).isEqualTo(0);

    compareToResult = customerTwo.compareTo(customerOne);
    assertThat(compareToResult).isEqualTo(0);
  }

  @Test
  @DisplayName("different customer recognition ratings, returns descending numeric ordering")
  void different_customer_recognition_ratings_returns_ascending_numeric_ordering() {
    Customer customerOne = new Customer("A", 4, 1);
    Customer customerTwo = new Customer("B", 1, 2);

    int compareToResult = customerOne.compareTo(customerTwo);
    assertThat(compareToResult).isLessThan(0);

    compareToResult = customerTwo.compareTo(customerOne);
    assertThat(compareToResult).isGreaterThan(0);
  }

  @Test
  @DisplayName("even if everything else same, only customer recognition rating matters")
  void even_if_everything_else_same_only_customer_recognition_rating_matters() {
    Customer customerOne = new Customer("X", 2, 4);
    Customer customerTwo = new Customer("X", 0, 4);
    Customer customerThree = new Customer("X", 0, 4);

    assertThat(customerOne.compareTo(customerTwo)).isLessThan(0);
    assertThat(customerTwo.compareTo(customerOne)).isGreaterThan(0);

    assertThat(customerOne.compareTo(customerThree)).isLessThan(0);
    assertThat(customerThree.compareTo(customerOne)).isGreaterThan(0);

    assertThat(customerTwo.compareTo(customerThree)).isEqualTo(0);
    assertThat(customerThree.compareTo(customerTwo)).isEqualTo(0);
  }
}
