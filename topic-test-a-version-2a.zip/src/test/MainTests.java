package test;

import static com.github.stefanbirkner.systemlambda.SystemLambda.*;
import static org.assertj.core.api.Assertions.assertThat;

import java.util.List;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import main.Main;

class MainTests {

  @Test
  @DisplayName("Lucia serves Yuko")
  void lucia_serves_yuko() throws Exception {

    withTextFromSystemIn("Lucia the Barista", "Yuko", "5", "11")
        .execute(
            () -> {
              List<String> expectedOutputParts =
                  List.of(
                      "Lucia the Barista is serving:",
                      "Istvan (who is a new face)",
                      "Dipuo (who is a regular)",
                      "Yuko (who is a regular)",
                      "After sorting by natural order...",
                      "Lucia the Barista is serving:",
                      "Yuko (who is a regular)",
                      "Dipuo (who is a regular)",
                      "Istvan (who is a new face)");

              String whatIsOutput = tapSystemOutNormalized(() -> Main.main(new String[0])).trim();

              assertThat(whatIsOutput).containsSubsequence(expectedOutputParts);
            });
  }

  @Test
  @DisplayName("Piero serves Asli")
  void piero_serves_asli() throws Exception {

    withTextFromSystemIn("Piero the Barista", "Asli", "2", "1")
        .execute(
            () -> {
              List<String> expectedOutputParts =
                  List.of(
                      "Piero the Barista is serving:",
                      "Istvan (who is a new face)",
                      "Dipuo (who is a regular)",
                      "Asli (who is really familiar)",
                      "After sorting by natural order...",
                      "Piero the Barista is serving:",
                      "Dipuo (who is a regular)",
                      "Asli (who is really familiar)",
                      "Istvan (who is a new face)");

              String whatIsOutput = tapSystemOutNormalized(() -> Main.main(new String[0])).trim();

              assertThat(whatIsOutput).containsSubsequence(expectedOutputParts);
            });
  }
}
