package main;

public class App {

  public void run() {

    // TODO: code this run so that it works as shown in the example
    //       output in the instructions - and so that all the tests in MainTests pass as well

  }

  private void displayDemInstructions() {
    System.out.println("Enter a list of words separated by spaces.");
    System.out.println("If the word has a + in front of it, I'll add it.");
    System.out.println("If the word has a - in front of it, I'll remove it.");
    System.out.println("Otherwise, I'll ignore it.");
    System.out.println("I'll stop when you enter a # for the word.");
    System.out.println("Let's begin!");
    System.out.println();
  }
}
