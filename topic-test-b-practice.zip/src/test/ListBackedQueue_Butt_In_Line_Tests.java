package test;

import static org.assertj.core.api.Assertions.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import main.ListBackedQueue;
import main.SimpleQueue;
import main.QueueUtils;

@DisplayName("ListBackedQueue Butt In Line Tests")
public class ListBackedQueue_Butt_In_Line_Tests {

  private <T> java.util.List<T> emptyTheQueue(SimpleQueue<T> queueToEmpty) {
    java.util.List<T> contents = new ArrayList<>();
    while (!queueToEmpty.isEmpty()) {
      contents.add(queueToEmpty.dequeue());
    }
    return contents;
  }

  @Test
  @DisplayName("butting in line with a null placeholder throws an IllegalArgumentException")
  void butting_in_line_with_a_null_placeholder_throws_an_IllegalArgumentException() {

    SimpleQueue<String> queue = new ListBackedQueue<>();

    assertThatExceptionOfType(IllegalArgumentException.class)
        .isThrownBy(
            () -> {
              QueueUtils.buttInLine(queue, null, List.of());
            })
        .withMessage("Can't use a null placeholder.");
  }

  @Test
  @DisplayName("butting in line with a null new element list throws an IllegalArgumentException")
  void butting_in_line_with_a_null_new_element_list_throws_an_IllegalArgumentException() {

    SimpleQueue<String> queue = new ListBackedQueue<>();

    assertThatExceptionOfType(IllegalArgumentException.class)
        .isThrownBy(
            () -> {
              QueueUtils.buttInLine(queue, "foo", null);
            })
        .withMessage("Can't use a null element list.");
  }

  @Test
  @DisplayName("when the queue is empty, nothing happens")
  void when_the_queue_is_empty_nothing_happens() {

    SimpleQueue<String> queue = new ListBackedQueue<>();

    QueueUtils.buttInLine(queue, "foo", List.of("bar"));

    assertThat(queue.isEmpty()).isTrue();
  }

  @Test
  @DisplayName("when the placeholder's not there, the queue doesn't change")
  void when_the_placeholders_not_there_the_queue_doesnt_change() {

    SimpleQueue<Integer> queue = new ListBackedQueue<>();
    queue.enqueue(3);
    queue.enqueue(5);
    queue.enqueue(9);

    QueueUtils.buttInLine(queue, 88, List.of(44));

    List<Integer> expectedQueueContents = List.of(3, 5, 9);
    List<Integer> actualQueueContents = emptyTheQueue(queue);

    assertThat(actualQueueContents).containsExactlyElementsOf(expectedQueueContents);
  }

  @Test
  @DisplayName("butting in when the placeholder is at the front")
  void butting_in_when_the_placeholder_is_at_the_front() {

    SimpleQueue<String> queue = new ListBackedQueue<>();
    queue.enqueue("my");
    queue.enqueue("dog");
    queue.enqueue("has");
    queue.enqueue("fleas");

    QueueUtils.buttInLine(queue, "my", List.of("big", "old", "scary"));

    List<String> expectedQueueContents =
        List.of("my", "big", "old", "scary", "dog", "has", "fleas");
    List<String> actualQueueContents = emptyTheQueue(queue);

    assertThat(actualQueueContents).containsExactlyElementsOf(expectedQueueContents);
  }

  @Test
  @DisplayName("butting in when the placeholder is at the tail")
  void butting_in_when_the_placeholder_is_at_the_tail() {

    SimpleQueue<Blorb> queue = new ListBackedQueue<>();
    queue.enqueue(new Blorb(15));
    queue.enqueue(new Blorb(45));
    queue.enqueue(new Blorb(0));
    queue.enqueue(new Blorb(91));
    queue.enqueue(new Blorb(100));

    QueueUtils.buttInLine(queue, new Blorb(100), List.of(new Blorb(91919)));

    List<Blorb> expectedQueueContents =
        List.of(
            new Blorb(15),
            new Blorb(45),
            new Blorb(0),
            new Blorb(91),
            new Blorb(100),
            new Blorb(91919));
    List<Blorb> actualQueueContents = emptyTheQueue(queue);

    assertThat(actualQueueContents).containsExactlyElementsOf(expectedQueueContents);
  }

  @Test
  @DisplayName("butting in when the placeholder is in the middle")
  void butting_in_when_the_placeholder_is_in_the_middle() {

    SimpleQueue<Blorb> queue = new ListBackedQueue<>();
    queue.enqueue(new Blorb(15));
    queue.enqueue(new Blorb(45));
    queue.enqueue(new Blorb(0));
    queue.enqueue(new Blorb(91));
    queue.enqueue(new Blorb(100));

    QueueUtils.buttInLine(queue, new Blorb(0), List.of(new Blorb(1), new Blorb(11)));

    List<Blorb> expectedQueueContents =
        List.of(
            new Blorb(15),
            new Blorb(45),
            new Blorb(0),
            new Blorb(1),
            new Blorb(11),
            new Blorb(91),
            new Blorb(100));
    List<Blorb> actualQueueContents = emptyTheQueue(queue);

    assertThat(actualQueueContents).containsExactlyElementsOf(expectedQueueContents);
  }

  @Test
  @DisplayName("butting in when there's just one thing")
  void filtering_out_everything_in_a_queue_when_theres_just_one_thing() {

    SimpleQueue<Integer> queue = new ListBackedQueue<>();
    queue.enqueue(3);

    QueueUtils.buttInLine(queue, 3, List.of(333, 33, 3333));

    List<Integer> expectedQueueContents = List.of(3, 333, 33, 3333);
    List<Integer> actualQueueContents = emptyTheQueue(queue);

    assertThat(actualQueueContents).containsExactlyElementsOf(expectedQueueContents);
  }

  @Test
  @DisplayName(
      "butting in line when there are multiple equal placeholders only butts in for the first one from the front")
  void
      butting_in_line_when_there_are_multiple_equal_placeholders_only_butts_in_for_the_first_one_from_the_front() {

    SimpleQueue<Integer> queue = new ListBackedQueue<>();
    queue.enqueue(97);
    queue.enqueue(98);
    queue.enqueue(98);
    queue.enqueue(98);
    queue.enqueue(98);

    QueueUtils.buttInLine(queue, 98, List.of(-12, -13, -14));

    List<Integer> expectedQueueContents = List.of(97, 98, -12, -13, -14, 98, 98, 98);
    List<Integer> actualQueueContents = emptyTheQueue(queue);

    assertThat(actualQueueContents).containsExactlyElementsOf(expectedQueueContents);
  }

  @Test
  @DisplayName("butting in when your new element list is empty")
  void butting_in_when_your_new_element_list_is_empty() {

    Blorb blorbA = new Blorb(17);
    Blorb blorbB = new Blorb(2);
    Blorb blorbC = new Blorb(91);
    Blorb blorbD = new Blorb(-4);

    SimpleQueue<Blorb> queue = new ListBackedQueue<>();
    queue.enqueue(blorbA);
    queue.enqueue(blorbB);
    queue.enqueue(blorbC);
    queue.enqueue(blorbD);

    QueueUtils.buttInLine(queue, new Blorb(2), List.of());

    List<Blorb> expectedQueueContents = List.of(blorbA, blorbB, blorbC, blorbD);
    List<Blorb> actualQueueContents = emptyTheQueue(queue);

    assertThat(actualQueueContents).containsExactlyElementsOf(expectedQueueContents);
  }

  private static class Blorb {
    private int blorbosity;

    Blorb(int blorbosity) {
      this.blorbosity = blorbosity;
    }

    @Override
    public String toString() {
      return String.format("b%d", blorbosity);
    }

    @Override
    public int hashCode() {
      final int prime = 31;
      int result = 1;
      result = prime * result + blorbosity;
      return result;
    }

    @Override
    public boolean equals(Object obj) {
      if (this == obj) {
        return true;
      }
      if (obj == null) {
        return false;
      }
      if (getClass() != obj.getClass()) {
        return false;
      }
      Blorb other = (Blorb) obj;
      if (blorbosity != other.blorbosity) {
        return false;
      }
      return true;
    }
  }
}
