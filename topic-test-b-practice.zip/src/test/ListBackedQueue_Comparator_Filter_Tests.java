package test;

import static org.assertj.core.api.Assertions.*;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import main.ListBackedQueue;
import main.SimpleQueue;
import main.QueueUtils;

@DisplayName("ListBackedQueue Comparator Filter Tests")
public class ListBackedQueue_Comparator_Filter_Tests {

  private <T> List<T> emptyThe(SimpleQueue<T> queueToEmpty) {
    List<T> contents = new ArrayList<>();
    while (!queueToEmpty.isEmpty()) {
      contents.add(queueToEmpty.dequeue());
    }
    return contents;
  }

  @Test
  @DisplayName("filtering a queue with a null filter throws an IllegalArgumentException")
  void filtering_a_queue_with_a_null_filter_throws_an_IllegalArgumentException() {

    SimpleQueue<String> queue = new ListBackedQueue<>();

    assertThatExceptionOfType(IllegalArgumentException.class)
        .isThrownBy(
            () -> {
              QueueUtils.filter(queue, null, Comparator.naturalOrder());
            })
        .withMessage("Filter can't be null.");
  }

  @Test
  @DisplayName("filtering a queue with a null comparator throws an IllegalArgumentException")
  void filtering_a_queue_with_a_null_comparator_throws_an_IllegalArgumentException() {

    SimpleQueue<String> queue = new ListBackedQueue<>();

    assertThatExceptionOfType(IllegalArgumentException.class)
        .isThrownBy(
            () -> {
              QueueUtils.filter(queue, "foo", null);
            })
        .withMessage("Filter comparator can't be null.");
  }

  @Test
  @DisplayName("filtering an empty queue gives you an empty queue")
  void filtering_an_empty_queue_gives_you_an_empty_queue() {

    SimpleQueue<String> queue = new ListBackedQueue<>();
    QueueUtils.filter(queue, "foo", Comparator.naturalOrder());

    assertThat(queue.isEmpty()).isTrue();
  }

  @Test
  @DisplayName("filtering a queue with all items less than the filter doesn't change the queue")
  void filtering_a_queue_with_all_items_less_than_the_filter_doesnt_change_the_queue() {

    SimpleQueue<Integer> queue = new ListBackedQueue<>();
    queue.enqueue(3);
    queue.enqueue(5);
    queue.enqueue(9);

    QueueUtils.filter(queue, 10, Comparator.naturalOrder());

    List<Integer> expectedQueueContents = List.of(3, 5, 9);
    List<Integer> actualQueueContents = emptyThe(queue);

    assertThat(actualQueueContents).containsExactlyElementsOf(expectedQueueContents);
  }

  @Test
  @DisplayName("filtering a single element from the tail")
  void filtering_a_single_element_from_the_tail() {

    SimpleQueue<String> queue = new ListBackedQueue<>();
    queue.enqueue("f");
    queue.enqueue("g");
    queue.enqueue("h");
    queue.enqueue("i");

    QueueUtils.filter(queue, "i", Comparator.naturalOrder());

    List<String> expectedQueueContents = List.of("f", "g", "h");
    List<String> actualQueueContents = emptyThe(queue);

    assertThat(actualQueueContents).containsExactlyElementsOf(expectedQueueContents);
  }

  @Test
  @DisplayName("filtering a single element from the head")
  void filtering_a_single_element_from_the_head() {

    SimpleQueue<Blorb> queue = new ListBackedQueue<>();
    queue.enqueue(new Blorb(18));
    queue.enqueue(new Blorb(7));
    queue.enqueue(new Blorb(6));
    queue.enqueue(new Blorb(5));
    queue.enqueue(new Blorb(4));

    QueueUtils.filter(queue, new Blorb(8), Comparator.comparing(Blorb::getBlorbosity));

    List<Blorb> expectedQueueContents =
        List.of(new Blorb(7), new Blorb(6), new Blorb(5), new Blorb(4));
    List<Blorb> actualQueueContents = emptyThe(queue);

    assertThat(actualQueueContents).containsExactlyElementsOf(expectedQueueContents);
  }

  @Test
  @DisplayName("filtering a single element from the middle")
  void filtering_a_single_element_from_the_middle() {

    SimpleQueue<Blorb> queue = new ListBackedQueue<>();
    queue.enqueue(new Blorb(3));
    queue.enqueue(new Blorb(5));
    queue.enqueue(new Blorb(10));
    queue.enqueue(new Blorb(8));
    queue.enqueue(new Blorb(6));

    QueueUtils.filter(queue, new Blorb(10), Comparator.comparing(Blorb::getBlorbosity));

    List<Blorb> expectedQueueContents =
        List.of(new Blorb(3), new Blorb(5), new Blorb(8), new Blorb(6));
    List<Blorb> actualQueueContents = emptyThe(queue);

    assertThat(actualQueueContents).containsExactlyElementsOf(expectedQueueContents);
  }

  @Test
  @DisplayName("filtering out everything in a queue when there's just one thing")
  void filtering_out_everything_in_a_queue_when_theres_just_one_thing() {

    SimpleQueue<Integer> queue = new ListBackedQueue<>();
    queue.enqueue(3);

    QueueUtils.filter(queue, 1, Comparator.naturalOrder());

    List<Integer> expectedQueueContents = List.of();
    List<Integer> actualQueueContents = emptyThe(queue);

    assertThat(actualQueueContents).containsExactlyElementsOf(expectedQueueContents);
  }

  @Test
  @DisplayName("filtering out everything in a queue when there's multiple things")
  void filtering_out_everything_in_a_queue_when_theres_multiple_things() {

    SimpleQueue<Integer> queue = new ListBackedQueue<>();
    queue.enqueue(98);
    queue.enqueue(99);
    queue.enqueue(58);
    queue.enqueue(38);
    queue.enqueue(18);

    QueueUtils.filter(queue, 1, Comparator.naturalOrder());

    List<Integer> expectedQueueContents = List.of();
    List<Integer> actualQueueContents = emptyThe(queue);

    assertThat(actualQueueContents).containsExactlyElementsOf(expectedQueueContents);
  }

  private static class Blorb {
    private int blorbosity;

    Blorb(int blorbosity) {
      this.blorbosity = blorbosity;
    }

    int getBlorbosity() {
      return blorbosity;
    }

    @Override
    public String toString() {
      return String.format("b%d", blorbosity);
    }

    @Override
    public int hashCode() {
      final int prime = 31;
      int result = 1;
      result = prime * result + blorbosity;
      return result;
    }

    @Override
    public boolean equals(Object obj) {
      if (this == obj) {
        return true;
      }
      if (obj == null) {
        return false;
      }
      if (getClass() != obj.getClass()) {
        return false;
      }
      Blorb other = (Blorb) obj;
      if (blorbosity != other.blorbosity) {
        return false;
      }
      return true;
    }
  }
}
