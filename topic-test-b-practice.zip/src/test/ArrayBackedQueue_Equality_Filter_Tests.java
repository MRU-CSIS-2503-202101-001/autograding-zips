package test;

import static org.assertj.core.api.Assertions.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import main.ArrayBackedQueue;
import main.SimpleQueue;
import main.QueueUtils;

@DisplayName("ArrayBackedQueue Equality Filter Tests")
public class ArrayBackedQueue_Equality_Filter_Tests {

  private <T> List<T> emptyTheQueue(SimpleQueue<T> queueToEmpty) {
    List<T> contents = new ArrayList<>();
    while (!queueToEmpty.isEmpty()) {
      contents.add(queueToEmpty.dequeue());
    }
    return contents;
  }

  @Test
  @DisplayName("filtering a queue with a null filter throws an IllegalArgumentException")
  void filtering_a_queue_with_a_null_filter_throws_an_IllegalArgumentException() {

    SimpleQueue<String> queue = new ArrayBackedQueue<>();

    assertThatExceptionOfType(IllegalArgumentException.class)
        .isThrownBy(
            () -> {
              QueueUtils.filter(queue, null);
            })
        .withMessage("Filter can't be null.");
  }

  @Test
  @DisplayName("filtering an empty queue gives you an empty queue")
  void filtering_an_empty_queue_gives_you_an_empty_queue() {

    SimpleQueue<String> queue = new ArrayBackedQueue<>();
    QueueUtils.filter(queue, "foo");

    assertThat(queue.isEmpty()).isTrue();
  }

  @Test
  @DisplayName("filtering a queue with something not present doesn't change the queue")
  void filtering_a_queue_with_something_not_present_doesnt_change_the_queue() {

    SimpleQueue<Integer> queue = new ArrayBackedQueue<>();
    queue.enqueue(3);
    queue.enqueue(5);
    queue.enqueue(9);

    QueueUtils.filter(queue, 15);

    List<Integer> expectedQueueContents = List.of(3, 5, 9);
    List<Integer> actualQueueContents = emptyTheQueue(queue);

    assertThat(actualQueueContents).containsExactlyElementsOf(expectedQueueContents);
  }

  @Test
  @DisplayName("filtering a single element from the tail")
  void filtering_a_single_element_from_the_tail() {

    SimpleQueue<String> queue = new ArrayBackedQueue<>();
    queue.enqueue("my");
    queue.enqueue("dog");
    queue.enqueue("has");
    queue.enqueue("fleas");

    QueueUtils.filter(queue, "fleas");

    List<String> expectedQueueContents = List.of("my", "dog", "has");
    List<String> actualQueueContents = emptyTheQueue(queue);

    assertThat(actualQueueContents).containsExactlyElementsOf(expectedQueueContents);
  }

  @Test
  @DisplayName("filtering a single element from the head")
  void filtering_a_single_element_from_the_head() {

    SimpleQueue<Blorb> queue = new ArrayBackedQueue<>();
    queue.enqueue(new Blorb(15));
    queue.enqueue(new Blorb(45));
    queue.enqueue(new Blorb(0));
    queue.enqueue(new Blorb(91));
    queue.enqueue(new Blorb(100));

    QueueUtils.filter(queue, new Blorb(15));

    List<Blorb> expectedQueueContents =
        List.of(new Blorb(45), new Blorb(0), new Blorb(91), new Blorb(100));
    List<Blorb> actualQueueContents = emptyTheQueue(queue);

    assertThat(actualQueueContents).containsExactlyElementsOf(expectedQueueContents);
  }

  @Test
  @DisplayName("filtering a single element from the middle")
  void filtering_a_single_element_from_the_middle() {

    SimpleQueue<Blorb> queue = new ArrayBackedQueue<>();
    queue.enqueue(new Blorb(15));
    queue.enqueue(new Blorb(45));
    queue.enqueue(new Blorb(0));
    queue.enqueue(new Blorb(91));
    queue.enqueue(new Blorb(100));

    QueueUtils.filter(queue, new Blorb(0));

    List<Blorb> expectedQueueContents =
        List.of(new Blorb(15), new Blorb(45), new Blorb(91), new Blorb(100));
    List<Blorb> actualQueueContents = emptyTheQueue(queue);

    assertThat(actualQueueContents).containsExactlyElementsOf(expectedQueueContents);
  }

  @Test
  @DisplayName("filtering out everything in a queue when there's just one thing")
  void filtering_out_everything_in_a_queue_when_theres_just_one_thing() {

    SimpleQueue<Integer> queue = new ArrayBackedQueue<>();
    queue.enqueue(3);

    QueueUtils.filter(queue, 3);

    List<Integer> expectedQueueContents = List.of();
    List<Integer> actualQueueContents = emptyTheQueue(queue);

    assertThat(actualQueueContents).containsExactlyElementsOf(expectedQueueContents);
  }

  @Test
  @DisplayName("filtering out everything in a queue when there's multiple things")
  void filtering_out_everything_in_a_queue_when_theres_multiple_things() {

    SimpleQueue<Integer> queue = new ArrayBackedQueue<>();
    queue.enqueue(98);
    queue.enqueue(98);
    queue.enqueue(98);
    queue.enqueue(98);
    queue.enqueue(98);

    QueueUtils.filter(queue, 98);

    List<Integer> expectedQueueContents = List.of();
    List<Integer> actualQueueContents = emptyTheQueue(queue);

    assertThat(actualQueueContents).containsExactlyElementsOf(expectedQueueContents);
  }

  private static class Blorb {
    private int blorbosity;

    Blorb(int blorbosity) {
      this.blorbosity = blorbosity;
    }

    @Override
    public String toString() {
      return String.format("b%d", blorbosity);
    }

    @Override
    public int hashCode() {
      final int prime = 31;
      int result = 1;
      result = prime * result + blorbosity;
      return result;
    }

    @Override
    public boolean equals(Object obj) {
      if (this == obj) {
        return true;
      }
      if (obj == null) {
        return false;
      }
      if (getClass() != obj.getClass()) {
        return false;
      }
      Blorb other = (Blorb) obj;
      if (blorbosity != other.blorbosity) {
        return false;
      }
      return true;
    }
  }
}
