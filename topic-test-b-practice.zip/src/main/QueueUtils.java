package main;

import java.util.Comparator;
import java.util.List;

public class QueueUtils {

  /**
   * Removes all elements from a given Queue that equal the given filter. To be clear, this means
   * that any object obj in the Queue where obj.equals(filter) is true will be removed. The relative
   * order of the remaining elements is not changed.
   *
   * @param <T> the type of the elements in queue
   * @param queue the queue to filter
   * @param filter the object used to determine whether an element is filtered out of the queue
   * @throws IllegalArgumentException when filter is null
   */
  public static <T> void filter(SimpleQueue<T> queue, T filter) {
    // TODO: complete this method so that it follows the spec in the
    //       method docs and so that it passes all tests.
    //
    //       REMEMBER: The only collections you can use to build your
    //       solution are those in the prereqs!
  }

  /**
   * Removes all elements from a given Queue using a given comparator; each element such that
   * comparator.compare(filter, element) >= 0 is removed, while keeping the relative order of the
   * remaining elements.
   *
   * <p>Put another way, this method alters the given queue so that every element "bigger than or
   * equal to" the filter is taken away without changing the order of elements in the queue.
   *
   * @param <T> the type of the elements in queue
   * @param queue the queue to filter
   * @param filter the object used to determine whether an element is filtered out of the queue
   * @param comparator the comparator to use for filtering
   * @throws IllegalArgumentException when filter or comparator is null
   */
  public static <T> void filter(SimpleQueue<T> queue, T filter, Comparator<T> comparator) {
      // TODO: complete this method so that it follows the spec in the
      //       method docs and so that it passes all tests.
      //
      //       REMEMBER: The only collections you can use to build your
      //       solution are those in the prereqs!
  }

  /**
   * Given an element (called the placeholder) and a List of additional elements, find the first
   * element (starting from the front of the queue) that equals the placeholder and add the
   * additional elements into the queue behind the placeholder, ahead of any elements that were
   * already there.
   *
   * <p>This basically mimics the real-life situation where you have a group of people waiting in
   * line and suddenly a group of people come along and get in line behind their friend who was
   * waiting in line. I *hate* that! :)
   *
   * <p>If the placeholder doesn't exist, the queue will not change.
   *
   * <p>If multiple elements matching the placeholder exist in the queue, only the first one
   * (starting from the front of the queue) will be affected - the others are ignored.
   *
   * @param <T> the type of elements in the queue
   * @param queue the queue being altered
   * @param placeholder the element additional elements will be added behind
   * @param additionalElements the additional elements to add behind the placeholder
   */
  public static <T> void buttInLine(
      SimpleQueue<T> queue, T placeholder, List<T> additionalElements) {
      // TODO: complete this method so that it follows the spec in the
      //       method docs and so that it passes all tests.
      //
      //       REMEMBER: The only collections you can use to build your
      //       solution are those in the prereqs! (You are allowed to
      //       access the additionalElements List - but don't try and make
      //       a new List!)
}
