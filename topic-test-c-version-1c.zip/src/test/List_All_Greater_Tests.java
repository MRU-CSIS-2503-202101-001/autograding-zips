package test;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.List;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import main.SuperSimpleLinkedList;

@DisplayName("List All Greater Tests")
public class List_All_Greater_Tests {

  @Test
  @DisplayName("an empty list returns true")
  void an_empty_list() {

    SuperSimpleLinkedList<Integer> list = new SuperSimpleLinkedList<>();

    int someCutoff = 14;

    assertThat(list.allGreaterThan(someCutoff)).isTrue();
  }

  @Test
  @DisplayName("a one-item list but item is not greater than the cutoff returns false")
  void a_one_item_list_but_item_is_not_greater_than_the_cutoff_returns_false() {

    SuperSimpleLinkedList<String> list = new SuperSimpleLinkedList<>();
    list.append("A");

    String cutoff = "A";

    assertThat(list.allGreaterThan(cutoff)).isFalse();
  }

  @Test
  @DisplayName("a one-item list and item is greater than the cutoff returns true")
  void a_one_item_list_and_item_is_greater_than_the_cutoff_returns_true() {

    SuperSimpleLinkedList<String> list = new SuperSimpleLinkedList<>();
    list.append("B");

    String cutoff = "A";

    assertThat(list.allGreaterThan(cutoff)).isTrue();
  }

  @Test
  @DisplayName("a two-item list but neither item is greater than returns false")
  void a_two_item_list_but_neither_item_is_greater_than_the_cutoff_returns_false() {

    SuperSimpleLinkedList<Integer> list = new SuperSimpleLinkedList<>();
    list.append(7);
    list.append(5);

    int cutoff = 7;

    assertThat(list.allGreaterThan(cutoff)).isFalse();
  }

  @Test
  @DisplayName("a two-item list and only first item is greater than the cutoff returns false")
  void a_two_item_list_and_only_first_item_is_greater_than_the_cutoff_returns_false() {

    SuperSimpleLinkedList<Integer> list = new SuperSimpleLinkedList<>();
    list.append(7);
    list.append(5);

    int cutoff = 6;

    assertThat(list.allGreaterThan(cutoff)).isFalse();
  }

  @Test
  @DisplayName("a two-item list and only last item is greater than the cutoff returns false")
  void a_two_item_list_and_only_last_item_is_greater_than_the_cutoff_returns_false() {

    SuperSimpleLinkedList<Integer> list = new SuperSimpleLinkedList<>();
    list.append(3);
    list.append(5);

    int cutoff = 4;

    assertThat(list.allGreaterThan(cutoff)).isFalse();
  }

  @Test
  @DisplayName("a two-item list and both items are greater than the cutoff_returns true")
  void a_two_item_list_and_both_items_are_greater_than_the_cutoff_returns_true() {

    SuperSimpleLinkedList<Integer> list = new SuperSimpleLinkedList<>();
    list.append(3);
    list.append(5);

    int cutoff = 2;

    assertThat(list.allGreaterThan(cutoff)).isTrue();
  }

  @Test
  @DisplayName(
      "a multi-item list where all but the first are greater than the cutoff returns false")
  void a_multi_item_list_where_all_but_the_first_are_greater_than_the_cutoff_returns_false() {

    SuperSimpleLinkedList<Integer> list = new SuperSimpleLinkedList<>();
    List.of(1, 33, 55, 22, 44).forEach(list::append);

    int cutoff = 2;

    assertThat(list.allGreaterThan(cutoff)).isFalse();
  }

  @Test
  @DisplayName("a multi-item list where all but the last are greater than the cutoff returns false")
  void a_multi_item_list_where_all_but_the_last_are_greater_than_the_cutoff_returns_false() {

    SuperSimpleLinkedList<Integer> list = new SuperSimpleLinkedList<>();
    List.of(11, 3, 55, 22, 1).forEach(list::append);

    int cutoff = 2;

    assertThat(list.allGreaterThan(cutoff)).isFalse();
  }

  @Test
  @DisplayName("a multi-item list where all are greater than the cutoff returns true")
  void a_multi_item_list_where_all_are_greater_than_returns_true() {

    SuperSimpleLinkedList<Integer> list = new SuperSimpleLinkedList<>();
    List.of(11, 3, 55, 22, 11).forEach(list::append);

    int cutoff = 2;

    assertThat(list.allGreaterThan(cutoff)).isTrue();
  }
}
