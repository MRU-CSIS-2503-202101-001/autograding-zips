package test;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import main.StringUtil;

@DisplayName("String Has Odd Consonants Tests")
public class String_Has_Odd_Consonants_Tests {

  @Test
  @DisplayName("an empty String")
  void an_empty_string() {

    assertThat(StringUtil.hasOddConsonants("")).isFalse();
  }

  @Test
  @DisplayName("a blank String")
  void an_blank_string() {

    assertThat(StringUtil.hasOddConsonants("   \t\t  \n")).isFalse();
  }

  @Test
  @DisplayName("a single character string with no consonant")
  void a_single_character_string_with_no_consonant() {

    assertThat(StringUtil.hasOddConsonants("i")).isFalse();
  }

  @Test
  @DisplayName("a single character string that's a consonant")
  void a_single_character_string_thats_a_consonant() {

    assertThat(StringUtil.hasOddConsonants("x")).isTrue();
  }

  @Test
  @DisplayName("two character, no consonants")
  void two_character_no_consonants() {

    assertThat(StringUtil.hasOddConsonants("Uo")).isFalse();
  }

  @Test
  @DisplayName("two character, one consonant")
  void two_character_one_consonant() {

    assertThat(StringUtil.hasOddConsonants("bi")).isTrue();
    assertThat(StringUtil.hasOddConsonants("aF")).isTrue();
  }

  @Test
  @DisplayName("two character, two consonants")
  void two_character_two_consonants() {

    assertThat(StringUtil.hasOddConsonants("fY")).isFalse();
  }

  @Test
  @DisplayName("three character cases")
  void three_character_cases() {

    // 0 consonant cases
    assertThat(StringUtil.hasOddConsonants("uIa")).isFalse();

    // 1 consonant cases
    assertThat(StringUtil.hasOddConsonants("xAe")).isTrue();
    assertThat(StringUtil.hasOddConsonants("Afe")).isTrue();
    assertThat(StringUtil.hasOddConsonants("iUr")).isTrue();

    // 2 consonant cases
    assertThat(StringUtil.hasOddConsonants("fba")).isFalse();
    assertThat(StringUtil.hasOddConsonants("eNm")).isFalse();
    assertThat(StringUtil.hasOddConsonants("ciR")).isFalse();

    // 3 consonant cases
    assertThat(StringUtil.hasOddConsonants("gbL")).isTrue();
  }

  @Test
  @DisplayName("four character cases")
  void four_character_cases() {

    // 0 consonant cases
    assertThat(StringUtil.hasOddConsonants("IieO")).isFalse();

    // 1 consonant cases
    assertThat(StringUtil.hasOddConsonants("xAeO")).isTrue();
    assertThat(StringUtil.hasOddConsonants("exii")).isTrue();
    assertThat(StringUtil.hasOddConsonants("iUrA")).isTrue();
    assertThat(StringUtil.hasOddConsonants("iUOn")).isTrue();

    // 2 consonant cases
    assertThat(StringUtil.hasOddConsonants("fbae")).isFalse();
    assertThat(StringUtil.hasOddConsonants("eNmi")).isFalse();
    assertThat(StringUtil.hasOddConsonants("aiRx")).isFalse();
    assertThat(StringUtil.hasOddConsonants("fOba")).isFalse();
    assertThat(StringUtil.hasOddConsonants("eNum")).isFalse();
    assertThat(StringUtil.hasOddConsonants("ciiR")).isFalse();

    // 3 consonant cases
    assertThat(StringUtil.hasOddConsonants("tgHi")).isTrue();
    assertThat(StringUtil.hasOddConsonants("uFYR")).isTrue();
    assertThat(StringUtil.hasOddConsonants("waXN")).isTrue();
    assertThat(StringUtil.hasOddConsonants("vzip")).isTrue();

    // 4 consonant cases
    assertThat(StringUtil.hasOddConsonants("gbLR")).isFalse();
  }
}
