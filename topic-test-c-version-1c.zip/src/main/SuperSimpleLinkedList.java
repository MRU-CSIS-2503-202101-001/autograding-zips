package main;

public class SuperSimpleLinkedList<T extends Comparable<T>> {

  private Node<T> head;
  private Node<T> tail;
  private int size;

  public SuperSimpleLinkedList() {
    head = null;
    tail = null;
    size = 0;
  }

  // TODO: put your allGreaterThan method in here
  //
  // allGreaterThan takes in a cutoff of type T and returns true if
  // every element in this linked list comes after the cutoff. You may
  // notice that T implements Comparable....
  //
  // If you're wondering what to do if the list is empty, there's a test for that!

  public void prepend(T data) {

    Node<T> newGuy = new Node<T>(data);
    if (isEmpty()) {
      tail = newGuy;
    } else {
      newGuy.next = head.next;
    }
    head = newGuy;
    size++;
  }

  public void append(T data) {

    Node<T> newGuy = new Node<T>(data);

    if (isEmpty()) {
      head = newGuy;
    } else {
      tail.next = newGuy;
    }
    tail = newGuy;
    size++;
  }

  public int size() {
    return size;
  }

  public boolean isEmpty() {
    return head == null;
  }

  private static class Node<T> {

    private T data;
    private Node<T> next;

    public Node(T data) {
      this.data = data;
      this.next = null;
    }

    @Override
    public String toString() {
      return String.format("%s", data.toString());
    }
  }
}
