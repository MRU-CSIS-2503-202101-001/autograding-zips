package main;

public class StringUtil {

  // TODO: your hasOddConsonants method should go in here
  //
  // hasOddConsonants should return true if the given string has an odd number
  // of consonants in it. Just in case you were wondering - and I reckon you
  // should be - zero is an EVEN number.

  /**
   * A potentially useful helper method.
   *
   * @param c a character to examine
   * @return true if c is a vowel, false otherwise
   */
  private static boolean isVowel(char c) {
    return ("" + c).toUpperCase().matches("[AEIOU]");
  }
}
