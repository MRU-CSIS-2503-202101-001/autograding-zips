package main;

public class StringUtil {

  // TODO: your hasEvenVowels method should go in here
  //
  // hasEvenVowels should return true if the given string has an even number
  // of vowels in it. Just in case you were wondering - and I reckon you
  // should be - zero is an EVEN number.

  /**
   * A potentially useful helper method.
   *
   * @param c a character to examine
   * @return true if c is a vowel, false otherwise
   */
  private static boolean isVowel(char c) {
    return ("" + c).toUpperCase().matches("[AEIOU]");
  }
}
