package test;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import main.StringUtil;

@DisplayName("String Has Even Vowels Tests")
public class String_Has_Even_Vowels_Tests {

  @Test
  @DisplayName("an empty String")
  void an_empty_string() {

    assertThat(StringUtil.hasEvenVowels("")).isTrue();
  }

  @Test
  @DisplayName("a blank String")
  void an_blank_string() {

    assertThat(StringUtil.hasEvenVowels("   \t\t  \n")).isTrue();
  }

  @Test
  @DisplayName("a single character string with no vowel")
  void a_single_character_string_with_no_vowel() {

    assertThat(StringUtil.hasEvenVowels("c")).isTrue();
  }

  @Test
  @DisplayName("a single character string that's a vowel")
  void a_single_character_string_thats_a_vowel() {

    assertThat(StringUtil.hasEvenVowels("I")).isFalse();
  }

  @Test
  @DisplayName("two character, no vowels")
  void two_character_no_vowels() {

    assertThat(StringUtil.hasEvenVowels("bb")).isTrue();
  }

  @Test
  @DisplayName("two character, one vowel")
  void two_character_one_vowel() {

    assertThat(StringUtil.hasEvenVowels("xU")).isFalse();
    assertThat(StringUtil.hasEvenVowels("er")).isFalse();
  }

  @Test
  @DisplayName("two character, two vowels")
  void two_character_two_vowels() {

    assertThat(StringUtil.hasEvenVowels("eE")).isTrue();
  }

  @Test
  @DisplayName("three character cases")
  void three_character_cases() {

    // 0 vowel cases
    assertThat(StringUtil.hasEvenVowels("xnP")).isTrue();

    // 1 vowel cases
    assertThat(StringUtil.hasEvenVowels("fba")).isFalse();
    assertThat(StringUtil.hasEvenVowels("eNm")).isFalse();
    assertThat(StringUtil.hasEvenVowels("ciR")).isFalse();

    // 2 vowel cases
    assertThat(StringUtil.hasEvenVowels("xAe")).isTrue();
    assertThat(StringUtil.hasEvenVowels("Afe")).isTrue();
    assertThat(StringUtil.hasEvenVowels("iUr")).isTrue();

    // 3 vowel cases
    assertThat(StringUtil.hasEvenVowels("aie")).isFalse();
  }

  @Test
  @DisplayName("four character cases")
  void four_character_cases() {

    // 0 vowel cases
    assertThat(StringUtil.hasEvenVowels("gbLR")).isTrue();

    // 1 vowel cases
    assertThat(StringUtil.hasEvenVowels("tgHi")).isFalse();
    assertThat(StringUtil.hasEvenVowels("uFYR")).isFalse();
    assertThat(StringUtil.hasEvenVowels("waXN")).isFalse();
    assertThat(StringUtil.hasEvenVowels("vzip")).isFalse();

    // 2 vowel cases
    assertThat(StringUtil.hasEvenVowels("fbae")).isTrue();
    assertThat(StringUtil.hasEvenVowels("eNmi")).isTrue();
    assertThat(StringUtil.hasEvenVowels("aiRx")).isTrue();
    assertThat(StringUtil.hasEvenVowels("fOba")).isTrue();
    assertThat(StringUtil.hasEvenVowels("eNum")).isTrue();
    assertThat(StringUtil.hasEvenVowels("ciiR")).isTrue();

    // 3 vowel cases
    assertThat(StringUtil.hasEvenVowels("xAeO")).isFalse();
    assertThat(StringUtil.hasEvenVowels("exii")).isFalse();
    assertThat(StringUtil.hasEvenVowels("iUrA")).isFalse();
    assertThat(StringUtil.hasEvenVowels("iUOn")).isFalse();

    // 4 vowel cases
    assertThat(StringUtil.hasEvenVowels("IieO")).isTrue();
  }
}
