package main;

/**
 * Bit of a playground to try out generics.
 *
 * @author jpratt
 */
public class Main {

  public static void main(String[] args) {

    App app = new App();
    app.run();
  }
}
