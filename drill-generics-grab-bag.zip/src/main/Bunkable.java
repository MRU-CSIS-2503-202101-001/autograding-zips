package main;

/**
 * Just an interface for the sake of having one.
 *
 * @author jpratt
 */
public interface Bunkable {
  void bunk();
}
