package main;

/**
 * We've seen Chickens before. These ones have a name and an age in weeks.
 *
 * <p>Two chickens are equal if they have the same name and age.
 *
 * @author jpratt
 */
public class Chicken {

  private String name;
  private int ageInWeeks;

  public Chicken(String name, int ageInWeeks) {
    this.name = name;
    this.ageInWeeks = ageInWeeks;
  }

  @Override
  public String toString() {
    return String.format("%s (%d)", name, ageInWeeks);
  }
}
