package main;

/**
 * A Kid with a name.
 *
 * @author jpratt
 */
public class Kid {

  private String name;

  public Kid(String name) {
    this.name = name;
  }

  @Override
  public String toString() {
    return name;
  }
}
