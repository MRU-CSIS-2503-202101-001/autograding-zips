package main;

import java.util.Optional;

/**
 * A generic Queue interface. Tres humdrum.
 *
 * @author jpratt
 * @param <T> the type of things in the Stack
 */
public interface PlainOldQueue<T> {

  /**
   * Returns true iff there is nothing in this PlainOldQueue.
   *
   * @return true iff there is nothing in this PlainOldQueue
   */
  boolean isEmpty();

  /**
   * Returns true iff the number of items in this PlainOldQueue equals its capacity.
   *
   * @return true iff this PlainOldQueue holds a number of items equal to its capacity
   */
  boolean isFull();

  /**
   * Adds a new member to the end of this PlainOldQueue.
   *
   * @param t the thing to add to the end of this PlainOldQueue
   */
  void enqueue(T t);

  /**
   * Removes the element from the head of this PlainOldQueue. If the PlainOldQueue is empty, an
   * empty Optional is returned instead.
   *
   * @return either an Optional holding the element at the head of this POQ, or an empty Optional
   */
  Optional<T> dequeue();

  /**
   * Returns the number of elements in this PlainOldQueue.
   *
   * @return the number of elements in this PlainOldQueue
   */
  int size();
}
