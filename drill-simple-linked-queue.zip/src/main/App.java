package main;

public class App {

  public void run() {

    // TODO: code this run so that it works as shown in the example
    //       output in the instructions - and so that all the tests in MainTests pass as well

  }

  private void displayInstructions() {
    System.out.println("Hi! I'm the Simple Linked Queue app!");
    System.out.println(
        "If you enter a + followed by an integer, I will add that number to the queue.");
    System.out.println("If you enter a -, I will remove a number from the head of the queue.");
    System.out.println();

    System.out.println("I will show you the contents of the queue after every operation.");
    System.out.println("I will stop when you enter an empty line.");

    System.out.println("Ready? Start entering numbers!");
  }
}
