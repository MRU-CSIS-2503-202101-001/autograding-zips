package test;

import static org.assertj.core.api.Assertions.*;

import java.util.Optional;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import main.PlainOldQueue;
import main.SimpleLinkedQueue;

@DisplayName("SimpleLinkedQueue Dequeue When Empty Tests")
public class SimpleLinkedQueue_Dequeue_When_Empty_Tests {

  @Test
  @DisplayName("attempting to dequeue from an empty returns an empty Optional")
  void attempting_to_dequeue_from_an_empty_SLQ_returns_an_empty_optional() {

    PlainOldQueue<String> queue = new SimpleLinkedQueue<>();

    Optional<String> dequeued = queue.dequeue();

    assertThat(dequeued).isEmpty();
    assertThat(queue.isEmpty()).isTrue();
    assertThat(queue.size()).isZero();
  }

  @Test
  @DisplayName(
      "when you dequeue the last thing from the SLQ, and then do it again, you still get an empty Optional")
  void
      when_you_dequeue_the_last_thing_from_the_SLQ_and_then_do_it_again_you_still_get_an_empty_Optional() {

    PlainOldQueue<Integer> queue = new SimpleLinkedQueue<>();

    queue.enqueue(43);

    queue.dequeue(); // now we're empty

    Optional<Integer> dequeued = queue.dequeue();

    assertThat(dequeued).isEmpty();

    dequeued = queue.dequeue(); // still empty!

    assertThat(dequeued).isEmpty();
    assertThat(queue.isEmpty()).isTrue();
    assertThat(queue.size()).isZero();
  }
}
