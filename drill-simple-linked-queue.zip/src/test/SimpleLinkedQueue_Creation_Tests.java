package test;

import static org.assertj.core.api.Assertions.*;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import main.PlainOldQueue;
import main.SimpleLinkedQueue;

@DisplayName("SimpleLinkedQueue Creation Tests")
public class SimpleLinkedQueue_Creation_Tests {

  @Test
  @DisplayName("a new SLQ is empty")
  void a_new_SLQ_is_empty() {

    PlainOldQueue<String> queue = new SimpleLinkedQueue<>();

    assertThat(queue.isEmpty()).isTrue();
    assertThat(queue.isFull()).isFalse();
    assertThat(queue.size()).isZero();
  }
}
