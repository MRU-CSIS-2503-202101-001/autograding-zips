package test;

import static org.assertj.core.api.Assertions.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import main.PlainOldQueue;
import main.SimpleLinkedQueue;

@DisplayName("SimpleLinkedQueue Kicking The Tires Tests")
public class SimpleLinkedQueue_Kicking_The_Tires_Tests {

  @Test
  @DisplayName("fill up, then drain")
  void fill_up_then_drain() {

    PlainOldQueue<Integer> queue = new SimpleLinkedQueue<>();

    queue.enqueue(7);
    queue.enqueue(17);
    queue.enqueue(27);

    assertThat(queue.toString()).isEqualTo("H->[7, 17, 27]<-T");
    assertThat(queue.isEmpty()).isFalse();
    assertThat(queue.size()).isEqualTo(3);
    assertThat(queue.isFull()).isFalse();

    List<Integer> dequeued = new ArrayList<>();
    dequeued.add(queue.dequeue().get());
    dequeued.add(queue.dequeue().get());
    dequeued.add(queue.dequeue().get());

    assertThat(queue.toString()).isEqualTo("H->[]<-T");
    assertThat(dequeued).containsExactly(7, 17, 27);
    assertThat(queue.isEmpty()).isTrue();
    assertThat(queue.size()).isZero();
    assertThat(queue.isFull()).isFalse();
  }

  @Test
  @DisplayName("constant stream of ins and outs")
  void constant_stream_of_ins_and_outs() {

    PlainOldQueue<Integer> queue = new SimpleLinkedQueue<>();
    List<Integer> dequeued = new ArrayList<>();

    queue.enqueue(83);
    queue.enqueue(33);

    assertThat(queue.toString()).isEqualTo("H->[83, 33]<-T");

    queue.enqueue(209);
    dequeued.add(queue.dequeue().get());
    assertThat(queue.toString()).isEqualTo("H->[33, 209]<-T");

    queue.enqueue(52);
    dequeued.add(queue.dequeue().get());
    assertThat(queue.toString()).isEqualTo("H->[209, 52]<-T");

    queue.enqueue(66);
    dequeued.add(queue.dequeue().get());
    assertThat(queue.toString()).isEqualTo("H->[52, 66]<-T");

    queue.enqueue(0);
    dequeued.add(queue.dequeue().get());
    assertThat(queue.toString()).isEqualTo("H->[66, 0]<-T");

    assertThat(dequeued).containsExactly(83, 33, 209, 52);

    assertThat(queue.isEmpty()).isFalse();
    assertThat(queue.size()).isEqualTo(2);
    assertThat(queue.isFull()).isFalse();
  }
}
