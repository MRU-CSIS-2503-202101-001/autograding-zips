package test;

import static org.assertj.core.api.Assertions.*;

import java.util.Optional;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import main.PlainOldQueue;
import main.SimpleLinkedQueue;

@DisplayName("SimpleLinkedQueue Dequeue When Not Empty Tests")
public class SimpleLinkedQueue_Dequeue_When_Not_Empty_Tests {

  @Test
  @DisplayName("dequeuing a one-item queue gives you the thing and the queue is now empty")
  void dequeuing_a_one_item_queue_gives_you_the_thing_and_the_queue_is_now_empty() {

    PlainOldQueue<String> queue = new SimpleLinkedQueue<>();

    queue.enqueue("mort!");

    Optional<String> dequeued = queue.dequeue();

    assertThat(dequeued).hasValue("mort!");
    assertThat(queue.isEmpty()).isTrue();
    assertThat(queue.size()).isZero();
    assertThat(queue.isFull()).isFalse();
  }

  @Test
  @DisplayName(
      "dequeuing a two-item queue gives you the thing at the head and the queue is now one smaller")
  void
      dequeuing_a_two_item_queue_gives_you_the_thing_at_the_head_and_the_queue_is_now_one_smaller() {

    PlainOldQueue<String> queue = new SimpleLinkedQueue<>();

    queue.enqueue("mort!");
    queue.enqueue("bort?");

    Optional<String> dequeued = queue.dequeue();

    assertThat(dequeued).hasValue("mort!");
    assertThat(queue.isEmpty()).isFalse();
    assertThat(queue.size()).isEqualTo(1);
    assertThat(queue.isFull()).isFalse();
  }
}
