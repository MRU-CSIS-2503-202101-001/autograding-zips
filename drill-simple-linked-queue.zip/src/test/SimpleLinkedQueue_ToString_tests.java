package test;

import static org.assertj.core.api.Assertions.*;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import main.PlainOldQueue;
import main.SimpleLinkedQueue;

@DisplayName("SimpleLinkedQueue ToString Tests")
public class SimpleLinkedQueue_ToString_tests {

  @Test
  @DisplayName("toString for an empty SLQ")
  void toString_for_an_empty_SLQ() {

    PlainOldQueue<String> queue = new SimpleLinkedQueue<>();

    assertThat(queue.toString()).isEqualTo("H->[]<-T");
  }

  @Test
  @DisplayName("toString for a one-element SLQ")
  void toString_for_a_one_element_SLQ() {

    PlainOldQueue<Integer> queue = new SimpleLinkedQueue<>();

    queue.enqueue(14);

    assertThat(queue.toString()).isEqualTo("H->[14]<-T");
  }

  @Test
  @DisplayName("toString for a three-element SLQ")
  void toString_for_a_three_element_SLQ() {

    PlainOldQueue<Integer> queue = new SimpleLinkedQueue<>();

    queue.enqueue(21);
    queue.enqueue(17);
    queue.enqueue(99);

    assertThat(queue.toString()).isEqualTo("H->[21, 17, 99]<-T");
  }
}
